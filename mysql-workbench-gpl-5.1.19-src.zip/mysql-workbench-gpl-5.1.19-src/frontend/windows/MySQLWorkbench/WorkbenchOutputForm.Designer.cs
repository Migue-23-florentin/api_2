namespace MySQL.GUI.Workbench
{
  partial class WorkbenchOutputForm
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      this.splitContainer1 = new System.Windows.Forms.SplitContainer();
      this.messageTreeView = new Aga.Controls.Tree.TreeViewAdv();
      this.iconColumn = new Aga.Controls.Tree.TreeColumn();
      this.messageColumn = new Aga.Controls.Tree.TreeColumn();
      this.timeColumn = new Aga.Controls.Tree.TreeColumn();
      this.messagesContextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
      this.copyMessagesToClipboardToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.clearOutputWindowsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.nodeIcon = new Aga.Controls.Tree.NodeControls.NodeIcon();
      this.messageText = new Aga.Controls.Tree.NodeControls.NodeTextBox();
      this.timeText = new Aga.Controls.Tree.NodeControls.NodeTextBox();
      this.outputTextBox = new System.Windows.Forms.TextBox();
      this.outputMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
      this.selectAllItem = new System.Windows.Forms.ToolStripMenuItem();
      this.copyItem = new System.Windows.Forms.ToolStripMenuItem();
      this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
      this.clearItem = new System.Windows.Forms.ToolStripMenuItem();
      this.splitContainer1.Panel1.SuspendLayout();
      this.splitContainer1.Panel2.SuspendLayout();
      this.splitContainer1.SuspendLayout();
      this.messagesContextMenuStrip.SuspendLayout();
      this.outputMenuStrip.SuspendLayout();
      this.SuspendLayout();
      // 
      // splitContainer1
      // 
      this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.splitContainer1.Location = new System.Drawing.Point(0, 0);
      this.splitContainer1.Name = "splitContainer1";
      // 
      // splitContainer1.Panel1
      // 
      this.splitContainer1.Panel1.Controls.Add(this.messageTreeView);
      // 
      // splitContainer1.Panel2
      // 
      this.splitContainer1.Panel2.Controls.Add(this.outputTextBox);
      this.splitContainer1.Size = new System.Drawing.Size(729, 150);
      this.splitContainer1.SplitterDistance = 355;
      this.splitContainer1.TabIndex = 0;
      // 
      // messageTreeView
      // 
      this.messageTreeView.BackColor = System.Drawing.SystemColors.Window;
      this.messageTreeView.Columns.Add(this.iconColumn);
      this.messageTreeView.Columns.Add(this.messageColumn);
      this.messageTreeView.Columns.Add(this.timeColumn);
      this.messageTreeView.ContextMenuStrip = this.messagesContextMenuStrip;
      this.messageTreeView.DefaultToolTipProvider = null;
      this.messageTreeView.Dock = System.Windows.Forms.DockStyle.Fill;
      this.messageTreeView.DragDropMarkColor = System.Drawing.Color.Black;
      this.messageTreeView.ForeColor = System.Drawing.SystemColors.ControlText;
      this.messageTreeView.FullRowSelect = true;
      this.messageTreeView.LineColor = System.Drawing.SystemColors.ControlDark;
      this.messageTreeView.LoadOnDemand = true;
      this.messageTreeView.Location = new System.Drawing.Point(0, 0);
      this.messageTreeView.Model = null;
      this.messageTreeView.Name = "messageTreeView";
      this.messageTreeView.NodeControls.Add(this.nodeIcon);
      this.messageTreeView.NodeControls.Add(this.messageText);
      this.messageTreeView.NodeControls.Add(this.timeText);
      this.messageTreeView.SelectedNode = null;
      this.messageTreeView.SelectionMode = Aga.Controls.Tree.TreeSelectionMode.MultiSameParent;
      this.messageTreeView.ShowLines = false;
      this.messageTreeView.ShowNodeToolTips = true;
      this.messageTreeView.ShowPlusMinus = false;
      this.messageTreeView.Size = new System.Drawing.Size(355, 150);
      this.messageTreeView.TabIndex = 0;
      this.messageTreeView.UseColumns = true;
      // 
      // iconColumn
      // 
      this.iconColumn.Header = "";
      this.iconColumn.MaxColumnWidth = 32;
      this.iconColumn.MinColumnWidth = 20;
      this.iconColumn.SortOrder = System.Windows.Forms.SortOrder.None;
      this.iconColumn.TooltipText = null;
      this.iconColumn.Width = 32;
      // 
      // messageColumn
      // 
      this.messageColumn.Header = "Message";
      this.messageColumn.SortOrder = System.Windows.Forms.SortOrder.None;
      this.messageColumn.TooltipText = null;
      this.messageColumn.Width = 280;
      // 
      // timeColumn
      // 
      this.timeColumn.Header = "Time";
      this.timeColumn.SortOrder = System.Windows.Forms.SortOrder.None;
      this.timeColumn.TooltipText = null;
      this.timeColumn.Width = 70;
      // 
      // messagesContextMenuStrip
      // 
      this.messagesContextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.copyMessagesToClipboardToolStripMenuItem,
            this.clearOutputWindowsToolStripMenuItem});
      this.messagesContextMenuStrip.Name = "messagesContextMenuStrip";
      this.messagesContextMenuStrip.Size = new System.Drawing.Size(266, 48);
      // 
      // copyMessagesToClipboardToolStripMenuItem
      // 
      this.copyMessagesToClipboardToolStripMenuItem.Name = "copyMessagesToClipboardToolStripMenuItem";
      this.copyMessagesToClipboardToolStripMenuItem.Size = new System.Drawing.Size(265, 22);
      this.copyMessagesToClipboardToolStripMenuItem.Text = "Copy Selected Messages to Clipboard";
      this.copyMessagesToClipboardToolStripMenuItem.Click += new System.EventHandler(this.copyMessagesToClipboardToolStripMenuItem_Click);
      // 
      // clearOutputWindowsToolStripMenuItem
      // 
      this.clearOutputWindowsToolStripMenuItem.Name = "clearOutputWindowsToolStripMenuItem";
      this.clearOutputWindowsToolStripMenuItem.Size = new System.Drawing.Size(265, 22);
      this.clearOutputWindowsToolStripMenuItem.Text = "Clear Output Windows";
      this.clearOutputWindowsToolStripMenuItem.Click += new System.EventHandler(this.clearOutputWindowsToolStripMenuItem_Click);
      // 
      // nodeIcon
      // 
      this.nodeIcon.DataPropertyName = "Icon";
      this.nodeIcon.LeftMargin = 1;
      this.nodeIcon.ParentColumn = this.iconColumn;
      this.nodeIcon.VirtualMode = true;
      // 
      // messageText
      // 
      this.messageText.DataPropertyName = "Text";
      this.messageText.EditEnabled = false;
      this.messageText.IncrementalSearchEnabled = true;
      this.messageText.LeftMargin = 3;
      this.messageText.ParentColumn = this.messageColumn;
      this.messageText.Trimming = System.Drawing.StringTrimming.EllipsisCharacter;
      // 
      // timeText
      // 
      this.timeText.DataPropertyName = "Text";
      this.timeText.EditEnabled = false;
      this.timeText.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.timeText.IncrementalSearchEnabled = true;
      this.timeText.LeftMargin = 3;
      this.timeText.ParentColumn = this.timeColumn;
      this.timeText.VirtualMode = true;
      // 
      // outputTextBox
      // 
      this.outputTextBox.BackColor = System.Drawing.Color.White;
      this.outputTextBox.ContextMenuStrip = this.outputMenuStrip;
      this.outputTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
      this.outputTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.outputTextBox.Location = new System.Drawing.Point(0, 0);
      this.outputTextBox.Multiline = true;
      this.outputTextBox.Name = "outputTextBox";
      this.outputTextBox.ReadOnly = true;
      this.outputTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
      this.outputTextBox.Size = new System.Drawing.Size(370, 150);
      this.outputTextBox.TabIndex = 0;
      this.outputTextBox.WordWrap = false;
      // 
      // outputMenuStrip
      // 
      this.outputMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.selectAllItem,
            this.copyItem,
            this.toolStripSeparator1,
            this.clearItem});
      this.outputMenuStrip.Name = "contextMenuStrip1";
      this.outputMenuStrip.Size = new System.Drawing.Size(280, 98);
      // 
      // selectAllItem
      // 
      this.selectAllItem.Name = "selectAllItem";
      this.selectAllItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.A)));
      this.selectAllItem.Size = new System.Drawing.Size(279, 22);
      this.selectAllItem.Text = "Select All Text";
      this.selectAllItem.Click += new System.EventHandler(this.selectAllItem_Click);
      // 
      // copyItem
      // 
      this.copyItem.Name = "copyItem";
      this.copyItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
      this.copyItem.Size = new System.Drawing.Size(279, 22);
      this.copyItem.Text = "Copy Selected Text to Clipboard";
      this.copyItem.Click += new System.EventHandler(this.copyItem_Click);
      // 
      // toolStripSeparator1
      // 
      this.toolStripSeparator1.Name = "toolStripSeparator1";
      this.toolStripSeparator1.Size = new System.Drawing.Size(276, 6);
      // 
      // clearItem
      // 
      this.clearItem.Name = "clearItem";
      this.clearItem.Size = new System.Drawing.Size(279, 22);
      this.clearItem.Text = "Clear Output Windows";
      this.clearItem.Click += new System.EventHandler(this.clearOutputWindowsToolStripMenuItem_Click);
      // 
      // WorkbenchOutputForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(729, 150);
      this.Controls.Add(this.splitContainer1);
      this.DoubleBuffered = true;
      this.HideOnClose = true;
      this.Name = "WorkbenchOutputForm";
      this.TabText = "Output";
      this.Text = "Workbench Output";
      this.splitContainer1.Panel1.ResumeLayout(false);
      this.splitContainer1.Panel2.ResumeLayout(false);
      this.splitContainer1.Panel2.PerformLayout();
      this.splitContainer1.ResumeLayout(false);
      this.messagesContextMenuStrip.ResumeLayout(false);
      this.outputMenuStrip.ResumeLayout(false);
      this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.SplitContainer splitContainer1;
    private Aga.Controls.Tree.TreeViewAdv messageTreeView;
    private Aga.Controls.Tree.TreeColumn timeColumn;
    private Aga.Controls.Tree.TreeColumn messageColumn;
    private System.Windows.Forms.TextBox outputTextBox;
    private Aga.Controls.Tree.TreeColumn iconColumn;
    private Aga.Controls.Tree.NodeControls.NodeIcon nodeIcon;
    private Aga.Controls.Tree.NodeControls.NodeTextBox timeText;
    private Aga.Controls.Tree.NodeControls.NodeTextBox messageText;
    private System.Windows.Forms.ContextMenuStrip messagesContextMenuStrip;
    private System.Windows.Forms.ToolStripMenuItem copyMessagesToClipboardToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem clearOutputWindowsToolStripMenuItem;
    private System.Windows.Forms.ContextMenuStrip outputMenuStrip;
    private System.Windows.Forms.ToolStripMenuItem clearItem;
    private System.Windows.Forms.ToolStripMenuItem copyItem;
    private System.Windows.Forms.ToolStripMenuItem selectAllItem;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
  }
}