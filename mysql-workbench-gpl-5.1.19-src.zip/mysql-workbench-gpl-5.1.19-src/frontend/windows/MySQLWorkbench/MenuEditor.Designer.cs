namespace MySQL.GUI.Workbench
{
  partial class MenuEditor
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.menuTreeView = new Aga.Controls.Tree.TreeViewAdv();
      this.captionNodeText = new Aga.Controls.Tree.NodeControls.NodeTextBox();
      this.shortcutNodeText = new Aga.Controls.Tree.NodeControls.NodeTextBox();
      this.closeButton = new System.Windows.Forms.Button();
      this.label1 = new System.Windows.Forms.Label();
      this.addItemButton = new System.Windows.Forms.Button();
      this.resetButton = new System.Windows.Forms.Button();
      this.menuComboBox = new System.Windows.Forms.ComboBox();
      this.addSeparatorButton = new System.Windows.Forms.Button();
      this.deleteButton = new System.Windows.Forms.Button();
      this.moveUpButton = new System.Windows.Forms.Button();
      this.moveDownButton = new System.Windows.Forms.Button();
      this.addSubmenuButton = new System.Windows.Forms.Button();
      this.label2 = new System.Windows.Forms.Label();
      this.shortcutText = new System.Windows.Forms.TextBox();
      this.SuspendLayout();
      // 
      // menuTreeView
      // 
      this.menuTreeView.BackColor = System.Drawing.SystemColors.MenuBar;
      this.menuTreeView.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.menuTreeView.DefaultToolTipProvider = null;
      this.menuTreeView.DragDropMarkColor = System.Drawing.Color.Black;
      this.menuTreeView.LineColor = System.Drawing.SystemColors.ControlDark;
      this.menuTreeView.Location = new System.Drawing.Point(12, 46);
      this.menuTreeView.Model = null;
      this.menuTreeView.Name = "menuTreeView";
      this.menuTreeView.NodeControls.Add(this.captionNodeText);
      this.menuTreeView.NodeControls.Add(this.shortcutNodeText);
      this.menuTreeView.RowHeight = 20;
      this.menuTreeView.SelectedNode = null;
      this.menuTreeView.Size = new System.Drawing.Size(252, 303);
      this.menuTreeView.TabIndex = 0;
      // 
      // captionNodeText
      // 
      this.captionNodeText.DataPropertyName = "Text";
      this.captionNodeText.IncrementalSearchEnabled = true;
      this.captionNodeText.LeftMargin = 3;
      this.captionNodeText.ParentColumn = null;
      this.captionNodeText.Trimming = System.Drawing.StringTrimming.EllipsisCharacter;
      // 
      // shortcutNodeText
      // 
      this.shortcutNodeText.EditEnabled = false;
      this.shortcutNodeText.IncrementalSearchEnabled = true;
      this.shortcutNodeText.LeftMargin = 3;
      this.shortcutNodeText.ParentColumn = null;
      this.shortcutNodeText.Trimming = System.Drawing.StringTrimming.Character;
      this.shortcutNodeText.VirtualMode = true;
      // 
      // closeButton
      // 
      this.closeButton.Location = new System.Drawing.Point(273, 355);
      this.closeButton.Name = "closeButton";
      this.closeButton.Size = new System.Drawing.Size(92, 23);
      this.closeButton.TabIndex = 2;
      this.closeButton.Text = "&Close";
      this.closeButton.UseVisualStyleBackColor = true;
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Location = new System.Drawing.Point(14, 15);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(37, 13);
      this.label1.TabIndex = 3;
      this.label1.Text = "Menu:";
      // 
      // addItemButton
      // 
      this.addItemButton.Location = new System.Drawing.Point(270, 46);
      this.addItemButton.Name = "addItemButton";
      this.addItemButton.Size = new System.Drawing.Size(95, 23);
      this.addItemButton.TabIndex = 5;
      this.addItemButton.Text = "&Add Item...";
      this.addItemButton.UseVisualStyleBackColor = true;
      // 
      // resetButton
      // 
      this.resetButton.Location = new System.Drawing.Point(14, 355);
      this.resetButton.Name = "resetButton";
      this.resetButton.Size = new System.Drawing.Size(132, 23);
      this.resetButton.TabIndex = 1;
      this.resetButton.Text = "&Reset Changes";
      this.resetButton.UseVisualStyleBackColor = true;
      // 
      // menuComboBox
      // 
      this.menuComboBox.FormattingEnabled = true;
      this.menuComboBox.Location = new System.Drawing.Point(57, 12);
      this.menuComboBox.Name = "menuComboBox";
      this.menuComboBox.Size = new System.Drawing.Size(207, 21);
      this.menuComboBox.TabIndex = 6;
      // 
      // addSeparatorButton
      // 
      this.addSeparatorButton.Location = new System.Drawing.Point(270, 75);
      this.addSeparatorButton.Name = "addSeparatorButton";
      this.addSeparatorButton.Size = new System.Drawing.Size(95, 23);
      this.addSeparatorButton.TabIndex = 5;
      this.addSeparatorButton.Text = "Add Separator";
      this.addSeparatorButton.UseVisualStyleBackColor = true;
      // 
      // deleteButton
      // 
      this.deleteButton.Location = new System.Drawing.Point(270, 133);
      this.deleteButton.Name = "deleteButton";
      this.deleteButton.Size = new System.Drawing.Size(95, 23);
      this.deleteButton.TabIndex = 7;
      this.deleteButton.Text = "&Delete";
      this.deleteButton.UseVisualStyleBackColor = true;
      // 
      // moveUpButton
      // 
      this.moveUpButton.Location = new System.Drawing.Point(270, 268);
      this.moveUpButton.Name = "moveUpButton";
      this.moveUpButton.Size = new System.Drawing.Size(95, 23);
      this.moveUpButton.TabIndex = 8;
      this.moveUpButton.Text = "Move &Up";
      this.moveUpButton.UseVisualStyleBackColor = true;
      // 
      // moveDownButton
      // 
      this.moveDownButton.Location = new System.Drawing.Point(270, 297);
      this.moveDownButton.Name = "moveDownButton";
      this.moveDownButton.Size = new System.Drawing.Size(95, 23);
      this.moveDownButton.TabIndex = 8;
      this.moveDownButton.Text = "Move &Down";
      this.moveDownButton.UseVisualStyleBackColor = true;
      // 
      // addSubmenuButton
      // 
      this.addSubmenuButton.Location = new System.Drawing.Point(270, 104);
      this.addSubmenuButton.Name = "addSubmenuButton";
      this.addSubmenuButton.Size = new System.Drawing.Size(95, 23);
      this.addSubmenuButton.TabIndex = 9;
      this.addSubmenuButton.Text = "Add Submenu";
      this.addSubmenuButton.UseVisualStyleBackColor = true;
      // 
      // label2
      // 
      this.label2.AutoSize = true;
      this.label2.Location = new System.Drawing.Point(270, 178);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(50, 13);
      this.label2.TabIndex = 10;
      this.label2.Text = "Shortcut:";
      // 
      // shortcutText
      // 
      this.shortcutText.Location = new System.Drawing.Point(270, 194);
      this.shortcutText.Name = "shortcutText";
      this.shortcutText.Size = new System.Drawing.Size(95, 20);
      this.shortcutText.TabIndex = 11;
      // 
      // MenuEditor
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(377, 390);
      this.Controls.Add(this.shortcutText);
      this.Controls.Add(this.label2);
      this.Controls.Add(this.addSubmenuButton);
      this.Controls.Add(this.moveDownButton);
      this.Controls.Add(this.moveUpButton);
      this.Controls.Add(this.deleteButton);
      this.Controls.Add(this.menuComboBox);
      this.Controls.Add(this.addSeparatorButton);
      this.Controls.Add(this.addItemButton);
      this.Controls.Add(this.label1);
      this.Controls.Add(this.closeButton);
      this.Controls.Add(this.resetButton);
      this.Controls.Add(this.menuTreeView);
      this.Name = "MenuEditor";
      this.Text = "Customize Menu";
      this.Load += new System.EventHandler(this.MenuEditor_Load);
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private Aga.Controls.Tree.TreeViewAdv menuTreeView;
    private System.Windows.Forms.Button closeButton;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.Button addItemButton;
    private System.Windows.Forms.Button resetButton;
    private System.Windows.Forms.ComboBox menuComboBox;
    private System.Windows.Forms.Button addSeparatorButton;
    private System.Windows.Forms.Button deleteButton;
    private System.Windows.Forms.Button moveUpButton;
    private System.Windows.Forms.Button moveDownButton;
    private System.Windows.Forms.Button addSubmenuButton;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.TextBox shortcutText;
    private Aga.Controls.Tree.NodeControls.NodeTextBox captionNodeText;
    private Aga.Controls.Tree.NodeControls.NodeTextBox shortcutNodeText;
  }
}