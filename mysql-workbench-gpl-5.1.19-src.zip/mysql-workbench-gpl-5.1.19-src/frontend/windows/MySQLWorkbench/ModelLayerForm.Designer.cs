namespace MySQL.GUI.Workbench
{
    partial class ModelLayerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
          this.components = new System.ComponentModel.Container();
          System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ModelLayerForm));
          this.panel1 = new System.Windows.Forms.Panel();
          this.comboBox1 = new System.Windows.Forms.ComboBox();
          this.layerTreeView = new Aga.Controls.Tree.TreeViewAdv();
          this.layersTreeColumn = new Aga.Controls.Tree.TreeColumn();
          this.selectionTreeColumn = new Aga.Controls.Tree.TreeColumn();
          this.nodeStateIcon = new Aga.Controls.Tree.NodeControls.NodeStateIcon();
          this.nameNodeControl = new Aga.Controls.Tree.NodeControls.NodeTextBox();
          this.selectedNodeControl = new Aga.Controls.Tree.NodeControls.NodeTextBox();
          this.layerMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
          this.panel1.SuspendLayout();
          this.SuspendLayout();
          // 
          // panel1
          // 
          this.panel1.BackColor = System.Drawing.SystemColors.Window;
          this.panel1.Controls.Add(this.comboBox1);
          this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
          this.panel1.Location = new System.Drawing.Point(4, 3);
          this.panel1.Name = "panel1";
          this.panel1.Size = new System.Drawing.Size(279, 24);
          this.panel1.TabIndex = 3;
          this.panel1.Visible = false;
          // 
          // comboBox1
          // 
          this.comboBox1.Dock = System.Windows.Forms.DockStyle.Top;
          this.comboBox1.FormattingEnabled = true;
          this.comboBox1.Location = new System.Drawing.Point(0, 0);
          this.comboBox1.Name = "comboBox1";
          this.comboBox1.Size = new System.Drawing.Size(279, 21);
          this.comboBox1.TabIndex = 1;
          // 
          // layerTreeView
          // 
          this.layerTreeView.BackColor = System.Drawing.SystemColors.Window;
          this.layerTreeView.Columns.Add(this.layersTreeColumn);
          this.layerTreeView.Columns.Add(this.selectionTreeColumn);
          this.layerTreeView.ContextMenuStrip = this.layerMenuStrip;
          this.layerTreeView.DefaultToolTipProvider = null;
          this.layerTreeView.Dock = System.Windows.Forms.DockStyle.Fill;
          this.layerTreeView.DragDropMarkColor = System.Drawing.Color.Black;
          this.layerTreeView.FullRowSelect = true;
          this.layerTreeView.GridLineStyle = Aga.Controls.Tree.GridLineStyle.Horizontal;
          this.layerTreeView.Indent = 16;
          this.layerTreeView.LineColor = System.Drawing.SystemColors.ControlDark;
          this.layerTreeView.LoadOnDemand = true;
          this.layerTreeView.Location = new System.Drawing.Point(4, 27);
          this.layerTreeView.Model = null;
          this.layerTreeView.Name = "layerTreeView";
          this.layerTreeView.NodeControls.Add(this.nodeStateIcon);
          this.layerTreeView.NodeControls.Add(this.nameNodeControl);
          this.layerTreeView.NodeControls.Add(this.selectedNodeControl);
          this.layerTreeView.SelectedNode = null;
          this.layerTreeView.SelectionMode = Aga.Controls.Tree.TreeSelectionMode.Multi;
          this.layerTreeView.ShowLines = false;
          this.layerTreeView.Size = new System.Drawing.Size(279, 313);
          this.layerTreeView.TabIndex = 0;
          this.layerTreeView.Text = "columnTreeView";
          this.layerTreeView.UseColumns = true;
          this.layerTreeView.DoubleClick += new System.EventHandler(this.layerTreeView_DoubleClick);
          // 
          // layersTreeColumn
          // 
          this.layersTreeColumn.Header = "Layers && Figures";
          this.layersTreeColumn.SortOrder = System.Windows.Forms.SortOrder.None;
          this.layersTreeColumn.TooltipText = null;
          this.layersTreeColumn.Width = 150;
          // 
          // selectionTreeColumn
          // 
          this.selectionTreeColumn.Header = "";
          this.selectionTreeColumn.SortOrder = System.Windows.Forms.SortOrder.None;
          this.selectionTreeColumn.TooltipText = null;
          this.selectionTreeColumn.Width = 20;
          // 
          // nodeStateIcon
          // 
          this.nodeStateIcon.LeftMargin = 1;
          this.nodeStateIcon.ParentColumn = this.layersTreeColumn;
          // 
          // nameNodeControl
          // 
          this.nameNodeControl.DataPropertyName = "Text";
          this.nameNodeControl.IncrementalSearchEnabled = true;
          this.nameNodeControl.LeftMargin = 3;
          this.nameNodeControl.ParentColumn = this.layersTreeColumn;
          this.nameNodeControl.Trimming = System.Drawing.StringTrimming.EllipsisCharacter;
          // 
          // selectedNodeControl
          // 
          this.selectedNodeControl.DataPropertyName = "Text";
          this.selectedNodeControl.IncrementalSearchEnabled = true;
          this.selectedNodeControl.LeftMargin = 0;
          this.selectedNodeControl.ParentColumn = this.selectionTreeColumn;
          // 
          // layerMenuStrip
          // 
          this.layerMenuStrip.Name = "layerMenuStrip";
          this.layerMenuStrip.Size = new System.Drawing.Size(61, 4);
          this.layerMenuStrip.Opening += new System.ComponentModel.CancelEventHandler(this.layerMenuStrip_Opening);
          // 
          // ModelLayerForm
          // 
          this.AllowEndUserDocking = false;
          this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
          this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
          this.BackColor = System.Drawing.SystemColors.Window;
          this.ClientSize = new System.Drawing.Size(287, 343);
          this.CloseButton = false;
          this.Controls.Add(this.layerTreeView);
          this.Controls.Add(this.panel1);
          this.DockAreas = ((WeifenLuo.WinFormsUI.Docking.DockAreas)(((((WeifenLuo.WinFormsUI.Docking.DockAreas.DockLeft | WeifenLuo.WinFormsUI.Docking.DockAreas.DockRight)
                      | WeifenLuo.WinFormsUI.Docking.DockAreas.DockTop)
                      | WeifenLuo.WinFormsUI.Docking.DockAreas.DockBottom)
                      | WeifenLuo.WinFormsUI.Docking.DockAreas.Document)));
          this.HideOnClose = true;
          this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
          this.Name = "ModelLayerForm";
          this.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
          this.TabText = "Layers";
          this.Text = "Layers";
          this.panel1.ResumeLayout(false);
          this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox comboBox1;

        private Aga.Controls.Tree.TreeViewAdv layerTreeView;
        private Aga.Controls.Tree.NodeControls.NodeStateIcon nodeStateIcon;
      private Aga.Controls.Tree.NodeControls.NodeTextBox nameNodeControl;
      private Aga.Controls.Tree.NodeControls.NodeTextBox selectedNodeControl;
      private Aga.Controls.Tree.TreeColumn layersTreeColumn;
      private Aga.Controls.Tree.TreeColumn selectionTreeColumn;
      private System.Windows.Forms.ContextMenuStrip layerMenuStrip;

    }
}