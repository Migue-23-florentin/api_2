namespace MySQL.GUI.Workbench
{
    partial class ModelDiagramForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
          this.openGlCanvasViewer = new MySQL.Utilities.WindowsCanvasViewer();
          this.SuspendLayout();
          // 
          // openGlCanvasViewer
          // 
          this.openGlCanvasViewer.AllowDrop = true;
          this.openGlCanvasViewer.AutoScroll = true;
          this.openGlCanvasViewer.BackColor = System.Drawing.Color.White;
          this.openGlCanvasViewer.Dock = System.Windows.Forms.DockStyle.Fill;
          this.openGlCanvasViewer.Location = new System.Drawing.Point(0, 0);
          this.openGlCanvasViewer.Name = "openGlCanvasViewer";
          this.openGlCanvasViewer.OwnerForm = null;
          this.openGlCanvasViewer.Size = new System.Drawing.Size(541, 432);
          this.openGlCanvasViewer.TabIndex = 0;
          this.openGlCanvasViewer.DragDrop += new System.Windows.Forms.DragEventHandler(this.openGlCanvasViewer_DragDrop);
          this.openGlCanvasViewer.DragEnter += new System.Windows.Forms.DragEventHandler(this.openGlCanvasViewer_DragEnter);
          // 
          // ModelViewForm
          // 
          this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
          this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
          this.ClientSize = new System.Drawing.Size(541, 432);
          this.Controls.Add(this.openGlCanvasViewer);
          this.Name = "ModelViewForm";
          this.TabText = "ModelView";
          this.Text = "ModelView";
          this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ModelViewForm_FormClosing);
          this.ResumeLayout(false);

        }

        #endregion

      private MySQL.Utilities.WindowsCanvasViewer openGlCanvasViewer;

			}
}