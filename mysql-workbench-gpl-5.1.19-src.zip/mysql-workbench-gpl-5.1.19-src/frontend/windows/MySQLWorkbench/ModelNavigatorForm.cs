using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using MySQL.Workbench;
using WeifenLuo.WinFormsUI.Docking;
using MySQL.Utilities;
using MySQL.GUI.Mdc;

namespace MySQL.GUI.Workbench
{
  public partial class ModelNavigatorForm : DockContent
  {
    WbContext wbContext;
    MySQL.GUI.Mdc.WindowsGDICanvasView canvas;
    Timer zoomTimer;

    public ModelNavigatorForm()
    {
      InitializeComponent();
    }


    public ModelNavigatorForm(WbContext wbContext)
    {
      InitializeComponent();
      this.wbContext = wbContext;

      // The zoom timer consolidates frequent zoom changes (as they might happen using the zoom slider)
      // into a single invalidation event, which will not only repaint the canvas but also
      // trigger recreation of cached elements if they need that.
      zoomTimer = new Timer();
      zoomTimer.Interval = 500;
      zoomTimer.Tick += new EventHandler(zoomTimer_Tick);
    }

    void zoomTimer_Tick(object sender, EventArgs e)
    {
      zoomTimer.Enabled = false;
      wbContext.set_needs_repaint_all_items();
    }

    public void UpdateZoom()
    {
      UpdateNavigatorImage();
    }

    public void UpdateNavigatorImage()
    {
      if (!Visible)
        return;

      if (canvas == null)
      {
        canvas = new MySQL.GUI.Mdc.WindowsGDICanvasView(navImagePanel.Handle, navImagePanel.Width, navImagePanel.Height, true);

        canvas.set_on_queue_repaint(canvasNeedsRepaint);

        wbContext.setup_mini_view(canvas);

        // tell the panel that it now is fully drawn by user code
        navImagePanel.CustomBackground = true;
      }

      if (wbContext.get_zoom() > 0)
      {
        zoomComboBox.Enabled = true;
        zoomSlider.Enabled = true;
        zoomComboBox.Text = System.Math.Round(wbContext.get_zoom() * 100).ToString();
        zoomSlider.Value = (int)System.Math.Round(wbContext.get_zoom() * 100);
      }
      else
      {
        zoomComboBox.Text = "";
        zoomComboBox.Enabled = false;
        zoomSlider.Value = zoomSlider.Minimum;
        zoomSlider.Enabled = false;
      }
      canvas.repaint();
    }

    protected void canvasNeedsRepaint(int x, int y, int w, int h)
    {
      navImagePanel.Invalidate(new System.Drawing.Rectangle(x, y, w, h));
    }

    private void navImagePanel_Paint(object sender, PaintEventArgs e)
    {
      UpdateNavigatorImage();
    }

    private void navImagePanel_MouseDown(object sender, MouseEventArgs e)
    {
      canvas.OnMouseDown(e, ModifierKeys, MouseButtons);
    }

    private void navImagePanel_MouseMove(object sender, MouseEventArgs e)
    {
      if ((MouseButtons & MouseButtons.Left) == MouseButtons.Left)
      {
        canvas.OnMouseMove(e, ModifierKeys, MouseButtons);
      }
    }

    private void navImagePanel_MouseUp(object sender, MouseEventArgs e)
    {
      canvas.OnMouseUp(e, ModifierKeys, MouseButtons);
    }

    private void navImagePanel_SizeChanged(object sender, EventArgs e)
    {
      if (canvas != null)
      {
        wbContext.update_mini_view_size(navImagePanel.Width, navImagePanel.Height);
        navImagePanel.Invalidate();
      }
    }

    private void zoomSlider_Scroll(object sender, EventArgs e)
    {
      double zoom = zoomSlider.Value;

      wbContext.set_zoom(zoom / 100.0);
      zoomTimer.Stop();
      zoomTimer.Start();

      zoomComboBox.Text = System.Math.Round(wbContext.get_zoom() * 100).ToString();
      zoomSlider.Value = (int)System.Math.Round(wbContext.get_zoom() * 100);
    }

    private void ModelNavigatorForm_Shown(object sender, EventArgs e)
    {
      UpdateNavigatorImage();
      wbContext.update_mini_view_size(navImagePanel.Width, navImagePanel.Height);
    }

    private void zoomInPictureBox_Click(object sender, EventArgs e)
    {
      wbContext.set_zoom(wbContext.get_zoom() + 0.25);
    }

    private void zoomOutPictureBox_Click(object sender, EventArgs e)
    {
      wbContext.set_zoom(wbContext.get_zoom() - 0.25);
    }

    private void zoomComboBox_KeyDown(object sender, KeyEventArgs e)
    {
      if(e.KeyCode == Keys.Enter)
      {
        String zoomstr = zoomComboBox.Text;
        double zoom;
        double zoom_max;
        double zoom_min;

        if (zoomstr == "")
          return;
        try
        {
          zoom = double.Parse(zoomstr);
          zoom_max = double.Parse(zoomComboBox.Items[0].ToString());
          zoom_min = double.Parse(zoomComboBox.Items[zoomComboBox.Items.Count - 1].ToString());
        }
        catch
        {
          return;
        }
        
        // check boundaries 
        if (zoom > zoom_max) zoom = zoom_max;
        if (zoom < zoom_min) zoom = zoom_min;

        wbContext.set_zoom(zoom / 100.0);
        zoomComboBox.Text = System.Math.Round(wbContext.get_zoom() * 100).ToString();
        zoomSlider.Value = (int)System.Math.Round(wbContext.get_zoom() * 100);
      }
    }

    private void zoomComboBox_SelectedIndexChanged(object sender, EventArgs e)
    {
      zoomComboBox_KeyDown(sender, new KeyEventArgs(Keys.Enter));
    }

  }
}