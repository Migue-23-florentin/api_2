using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Aga.Controls.Tree;
using Aga.Controls.Tree.NodeControls;

namespace MySQL.GUI.Workbench
{
  public partial class MenuEditor : Form
  {
    public MenuEditor()
    {
      InitializeComponent();
    }

    private void MenuEditor_Load(object sender, EventArgs e)
    {

    }
  }
}