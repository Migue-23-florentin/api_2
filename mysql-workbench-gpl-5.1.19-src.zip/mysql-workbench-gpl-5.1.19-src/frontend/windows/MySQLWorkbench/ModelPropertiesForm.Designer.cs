namespace MySQL.GUI.Workbench
{
	partial class ModelPropertiesForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ModelPropertiesForm));
      this.objSelComboBox = new System.Windows.Forms.ComboBox();
      this.objSelPanel = new System.Windows.Forms.Panel();
      this.propertiesTreeView = new Aga.Controls.Tree.TreeViewAdv();
      this.nameTreeColumn = new Aga.Controls.Tree.TreeColumn();
      this.valueTreeColumn = new Aga.Controls.Tree.TreeColumn();
      this.nameNodeControl = new Aga.Controls.Tree.NodeControls.NodeTextBox();
      this.objSelPanel.SuspendLayout();
      this.SuspendLayout();
      // 
      // objSelComboBox
      // 
      this.objSelComboBox.Dock = System.Windows.Forms.DockStyle.Top;
      this.objSelComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.objSelComboBox.FormattingEnabled = true;
      this.objSelComboBox.Location = new System.Drawing.Point(0, 0);
      this.objSelComboBox.Name = "objSelComboBox";
      this.objSelComboBox.Size = new System.Drawing.Size(224, 21);
      this.objSelComboBox.TabIndex = 0;
      this.objSelComboBox.SelectedIndexChanged += new System.EventHandler(this.objSelComboBox_SelectedIndexChanged);
      // 
      // objSelPanel
      // 
      this.objSelPanel.BackColor = System.Drawing.SystemColors.Window;
      this.objSelPanel.Controls.Add(this.objSelComboBox);
      this.objSelPanel.Dock = System.Windows.Forms.DockStyle.Top;
      this.objSelPanel.Location = new System.Drawing.Point(4, 3);
      this.objSelPanel.Name = "objSelPanel";
      this.objSelPanel.Size = new System.Drawing.Size(224, 25);
      this.objSelPanel.TabIndex = 1;
      // 
      // propertiesTreeView
      // 
      this.propertiesTreeView.BackColor = System.Drawing.SystemColors.Window;
      this.propertiesTreeView.Columns.Add(this.nameTreeColumn);
      this.propertiesTreeView.Columns.Add(this.valueTreeColumn);
      this.propertiesTreeView.DefaultToolTipProvider = null;
      this.propertiesTreeView.Dock = System.Windows.Forms.DockStyle.Fill;
      this.propertiesTreeView.DragDropMarkColor = System.Drawing.Color.Black;
      this.propertiesTreeView.FullRowSelect = true;
      this.propertiesTreeView.GridLineStyle = Aga.Controls.Tree.GridLineStyle.Horizontal;
      this.propertiesTreeView.Indent = 16;
      this.propertiesTreeView.LineColor = System.Drawing.SystemColors.ControlDark;
      this.propertiesTreeView.LoadOnDemand = true;
      this.propertiesTreeView.Location = new System.Drawing.Point(4, 28);
      this.propertiesTreeView.Model = null;
      this.propertiesTreeView.Name = "propertiesTreeView";
      this.propertiesTreeView.NodeControls.Add(this.nameNodeControl);
      this.propertiesTreeView.SelectedNode = null;
      this.propertiesTreeView.SelectionMode = Aga.Controls.Tree.TreeSelectionMode.Multi;
      this.propertiesTreeView.ShowLines = false;
      this.propertiesTreeView.ShowNodeToolTips = true;
      this.propertiesTreeView.ShowPlusMinus = false;
      this.propertiesTreeView.Size = new System.Drawing.Size(224, 235);
      this.propertiesTreeView.TabIndex = 0;
      this.propertiesTreeView.UseColumns = true;
      // 
      // nameTreeColumn
      // 
      this.nameTreeColumn.Header = "Name";
      this.nameTreeColumn.SortOrder = System.Windows.Forms.SortOrder.None;
      this.nameTreeColumn.TooltipText = null;
      this.nameTreeColumn.Width = 108;
      // 
      // valueTreeColumn
      // 
      this.valueTreeColumn.Header = "Value";
      this.valueTreeColumn.SortOrder = System.Windows.Forms.SortOrder.None;
      this.valueTreeColumn.TooltipText = null;
      this.valueTreeColumn.Width = 90;
      // 
      // nameNodeControl
      // 
      this.nameNodeControl.DataPropertyName = "Text";
      this.nameNodeControl.EditEnabled = false;
      this.nameNodeControl.IncrementalSearchEnabled = true;
      this.nameNodeControl.LeftMargin = 3;
      this.nameNodeControl.ParentColumn = this.nameTreeColumn;
      this.nameNodeControl.Trimming = System.Drawing.StringTrimming.EllipsisCharacter;
      this.nameNodeControl.VirtualMode = true;
      // 
      // ModelPropertiesForm
      // 
      this.AllowEndUserDocking = false;
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.BackColor = System.Drawing.SystemColors.Window;
      this.ClientSize = new System.Drawing.Size(232, 266);
      this.CloseButton = false;
      this.Controls.Add(this.propertiesTreeView);
      this.Controls.Add(this.objSelPanel);
      this.DockAreas = ((WeifenLuo.WinFormsUI.Docking.DockAreas)(((((WeifenLuo.WinFormsUI.Docking.DockAreas.DockLeft | WeifenLuo.WinFormsUI.Docking.DockAreas.DockRight)
                  | WeifenLuo.WinFormsUI.Docking.DockAreas.DockTop)
                  | WeifenLuo.WinFormsUI.Docking.DockAreas.DockBottom)
                  | WeifenLuo.WinFormsUI.Docking.DockAreas.Document)));
      this.HideOnClose = true;
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "ModelPropertiesForm";
      this.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
      this.TabText = "Properties";
      this.Text = "Properties";
      this.objSelPanel.ResumeLayout(false);
      this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Panel objSelPanel;
		private System.Windows.Forms.ComboBox objSelComboBox;
		private Aga.Controls.Tree.TreeViewAdv propertiesTreeView;
		private Aga.Controls.Tree.TreeColumn nameTreeColumn;
		private Aga.Controls.Tree.TreeColumn valueTreeColumn;
    private Aga.Controls.Tree.NodeControls.NodeTextBox nameNodeControl;
	}
}