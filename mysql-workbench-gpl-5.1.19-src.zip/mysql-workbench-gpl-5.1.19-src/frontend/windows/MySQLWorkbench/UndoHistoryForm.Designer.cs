namespace MySQL.GUI.Workbench
{
    partial class UndoHistoryForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
          this.components = new System.ComponentModel.Container();
          System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UndoHistoryForm));
          this.historyTreeView = new Aga.Controls.Tree.TreeViewAdv();
          this.historyContextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
          this.copyHistoryEntriesToClipboardToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
          this.nodeStateIcon = new Aga.Controls.Tree.NodeControls.NodeStateIcon();
          this.nameNodeControl = new Aga.Controls.Tree.NodeControls.NodeTextBox();
          this.historyContextMenuStrip.SuspendLayout();
          this.SuspendLayout();
          // 
          // historyTreeView
          // 
          this.historyTreeView.BackColor = System.Drawing.SystemColors.Window;
          this.historyTreeView.ContextMenuStrip = this.historyContextMenuStrip;
          this.historyTreeView.DefaultToolTipProvider = null;
          this.historyTreeView.Dock = System.Windows.Forms.DockStyle.Fill;
          this.historyTreeView.DragDropMarkColor = System.Drawing.Color.Black;
          this.historyTreeView.FullRowSelect = true;
          this.historyTreeView.GridLineStyle = Aga.Controls.Tree.GridLineStyle.Horizontal;
          this.historyTreeView.Indent = 12;
          this.historyTreeView.LineColor = System.Drawing.SystemColors.ControlDark;
          this.historyTreeView.LoadOnDemand = true;
          this.historyTreeView.Location = new System.Drawing.Point(4, 3);
          this.historyTreeView.Model = null;
          this.historyTreeView.Name = "historyTreeView";
          this.historyTreeView.NodeControls.Add(this.nodeStateIcon);
          this.historyTreeView.NodeControls.Add(this.nameNodeControl);
          this.historyTreeView.SelectedNode = null;
          this.historyTreeView.SelectionMode = Aga.Controls.Tree.TreeSelectionMode.Multi;
          this.historyTreeView.ShowLines = false;
          this.historyTreeView.ShowNodeToolTips = true;
          this.historyTreeView.ShowPlusMinus = false;
          this.historyTreeView.Size = new System.Drawing.Size(279, 337);
          this.historyTreeView.TabIndex = 0;
          this.historyTreeView.Text = "columnTreeView";
          this.historyTreeView.DoubleClick += new System.EventHandler(this.historyTreeView_DoubleClick);
          // 
          // historyContextMenuStrip
          // 
          this.historyContextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.copyHistoryEntriesToClipboardToolStripMenuItem});
          this.historyContextMenuStrip.Name = "historyContextMenuStrip";
          this.historyContextMenuStrip.Size = new System.Drawing.Size(245, 26);
          // 
          // copyHistoryEntriesToClipboardToolStripMenuItem
          // 
          this.copyHistoryEntriesToClipboardToolStripMenuItem.Name = "copyHistoryEntriesToClipboardToolStripMenuItem";
          this.copyHistoryEntriesToClipboardToolStripMenuItem.Size = new System.Drawing.Size(244, 22);
          this.copyHistoryEntriesToClipboardToolStripMenuItem.Text = "Copy History Entries to Clipboard";
          this.copyHistoryEntriesToClipboardToolStripMenuItem.Click += new System.EventHandler(this.copyHistoryEntriesToClipboardToolStripMenuItem_Click);
          // 
          // nodeStateIcon
          // 
          this.nodeStateIcon.LeftMargin = 1;
          this.nodeStateIcon.ParentColumn = null;
          // 
          // nameNodeControl
          // 
          this.nameNodeControl.DataPropertyName = "Text";
          this.nameNodeControl.EditEnabled = false;
          this.nameNodeControl.IncrementalSearchEnabled = true;
          this.nameNodeControl.LeftMargin = 3;
          this.nameNodeControl.ParentColumn = null;
          // 
          // UndoHistoryForm
          // 
          this.AllowEndUserDocking = false;
          this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
          this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
          this.BackColor = System.Drawing.SystemColors.Window;
          this.ClientSize = new System.Drawing.Size(287, 343);
          this.CloseButton = false;
          this.Controls.Add(this.historyTreeView);
          this.DockAreas = ((WeifenLuo.WinFormsUI.Docking.DockAreas)(((((WeifenLuo.WinFormsUI.Docking.DockAreas.DockLeft | WeifenLuo.WinFormsUI.Docking.DockAreas.DockRight)
                      | WeifenLuo.WinFormsUI.Docking.DockAreas.DockTop)
                      | WeifenLuo.WinFormsUI.Docking.DockAreas.DockBottom)
                      | WeifenLuo.WinFormsUI.Docking.DockAreas.Document)));
          this.HideOnClose = true;
          this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
          this.Name = "UndoHistoryForm";
          this.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
          this.TabText = "History";
          this.Text = "History";
          this.historyContextMenuStrip.ResumeLayout(false);
          this.ResumeLayout(false);

        }

        #endregion


        private Aga.Controls.Tree.TreeViewAdv historyTreeView;
        private Aga.Controls.Tree.NodeControls.NodeStateIcon nodeStateIcon;
      private Aga.Controls.Tree.NodeControls.NodeTextBox nameNodeControl;
      private System.Windows.Forms.ContextMenuStrip historyContextMenuStrip;
      private System.Windows.Forms.ToolStripMenuItem copyHistoryEntriesToClipboardToolStripMenuItem;

    }
}