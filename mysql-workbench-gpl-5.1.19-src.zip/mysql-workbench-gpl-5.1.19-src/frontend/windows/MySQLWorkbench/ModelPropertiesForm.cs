using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;
using MySQL.Workbench;
using MySQL.GUI.Workbench.Properties;
using MySQL.GUI.Mdc;
using MySQL.Grt;
using MySQL.GUI.Shell;


namespace MySQL.GUI.Workbench
{
  public partial class ModelPropertiesForm : DockContent
  {
    WbContext wbContext;
    GrtValueInspector valueInspector;
    SimpleGrtTreeModel valueInspectorModel;
    private NodeMultiTypeBox _valueNodeControl;

    public ModelPropertiesForm()
    {
      InitializeComponent();
      CreateValueNodeControl();
    }

    public ModelPropertiesForm(WbContext WbContext)
    {
      wbContext = WbContext;

      InitializeComponent();
      CreateValueNodeControl();
    }

    void CreateValueNodeControl()
    {
      // 
      // _valueNodeControl
      // 
      _valueNodeControl = new NodeMultiTypeBox();
      propertiesTreeView.NodeControls.Add(_valueNodeControl);
      _valueNodeControl.DataPropertyName = "Text";
      _valueNodeControl.EditEnabled = true;
      _valueNodeControl.EditOnClick = true;
      _valueNodeControl.IncrementalSearchEnabled = true;
      _valueNodeControl.LeftMargin = 3;
      _valueNodeControl.ParentColumn = valueTreeColumn;
      _valueNodeControl.VirtualMode = true;
      _valueNodeControl.Trimming = StringTrimming.EllipsisCharacter;
      _valueNodeControl.ValueColumn = (int)GrtValueInspector.Columns.Value;
      _valueNodeControl.IsReadonlyColumn = (int)GrtValueInspector.Columns.IsReadonly;
      _valueNodeControl.EditMethodColumn = (int)GrtValueInspector.Columns.EditMethod;
    }


    public void UpdateForForm(UIForm form)
    {
      if (valueInspectorModel != null)
        valueInspectorModel.DetachEvents();

      propertiesTreeView.SuspendLayout();
      propertiesTreeView.Model = null;
      valueInspector = null;
      valueInspectorModel = null;
      objSelComboBox.Text = "";
//      TabText = "No Selection";

      if (form != null)
      {
        List<String> items;

        valueInspector = wbContext.get_inspector_for_selection(form, out items);

        if (valueInspector != null)
        {
          objSelComboBox.SuspendLayout();
          objSelComboBox.Items.Clear();
          objSelComboBox.Items.AddRange(items.ToArray());
          objSelComboBox.ResumeLayout();

          objSelComboBox.SelectedIndex = 0;

          valueInspectorModel = new SimpleGrtTreeModel(propertiesTreeView, valueInspector, false);
          valueInspectorModel.AddColumn(nameNodeControl, (int)GrtValueInspector.Columns.Name, false);
          //!valueInspectorModel.AddColumn(_valueNodeControl, (int)GrtValueInspector.Columns.Value, true);
          _valueNodeControl.GrtTreeModel = valueInspectorModel.GrtTree;

          {
            TreeModelTooltipProvider tp = new TreeModelTooltipProvider();
            tp.Model = valueInspectorModel.GrtTree;
            tp.TooltipColumn = (int)GrtValueInspector.Columns.Description;
            nameNodeControl.ToolTipProvider = tp;
            _valueNodeControl.ToolTipProvider = tp;
          }

          propertiesTreeView.Model = valueInspectorModel;

         // TabText = "Selection Properties";
        }
        else
          objSelComboBox.Items.Clear();
      }
      else
        objSelComboBox.Items.Clear();

      propertiesTreeView.ResumeLayout();
    }


    /// <summary>
    /// Prevent the user from selecting a different index than 0
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void objSelComboBox_SelectedIndexChanged(object sender, EventArgs e)
    {
      objSelComboBox.SelectedIndex = 0;
    }


    /*protected override void OnPaint(PaintEventArgs e)
    {
      base.OnPaint(e);

      Graphics g = e.Graphics;
      SolidBrush solid = new SolidBrush(System.Drawing.SystemColors.Window);
      Pen pen = new Pen(System.Drawing.SystemColors.ControlDark);

      g.FillRectangle(solid, 0, 0, Width, Height);

      if (Pane != null && Pane.Contents.Count > 1)
          g.DrawRectangle(pen, 0, -1, Width - 1, Height + 1);
      else
          g.DrawRectangle(pen, 0, -1, Width - 1, Height);
		}*/
  }
}
