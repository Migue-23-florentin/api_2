namespace MySQL.GUI.Workbench
{
  partial class UserDatatypesForm
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UserDatatypesForm));
      this.userTypesTreeView = new Aga.Controls.Tree.TreeViewAdv();
      this.nameColumn = new Aga.Controls.Tree.TreeColumn();
      this.definitionColumn = new Aga.Controls.Tree.TreeColumn();
      this.flagsColumn = new Aga.Controls.Tree.TreeColumn();
      this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
      this.deleteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.nodeStateIcon = new Aga.Controls.Tree.NodeControls.NodeStateIcon();
      this.nameTextBox = new MySQL.Utilities.AdvNodeTextBox();
      this.definitionTextBox = new MySQL.Utilities.AdvNodeTextBox();
      this.flagsTextBox = new Aga.Controls.Tree.NodeControls.NodeTextBox();
      this.contextMenuStrip1.SuspendLayout();
      this.SuspendLayout();
      // 
      // userTypesTreeView
      // 
      this.userTypesTreeView.BackColor = System.Drawing.SystemColors.Window;
      this.userTypesTreeView.Columns.Add(this.nameColumn);
      this.userTypesTreeView.Columns.Add(this.definitionColumn);
      this.userTypesTreeView.Columns.Add(this.flagsColumn);
      this.userTypesTreeView.ContextMenuStrip = this.contextMenuStrip1;
      this.userTypesTreeView.DefaultToolTipProvider = null;
      this.userTypesTreeView.Dock = System.Windows.Forms.DockStyle.Fill;
      this.userTypesTreeView.DragDropMarkColor = System.Drawing.Color.Black;
      this.userTypesTreeView.FullRowSelect = true;
      this.userTypesTreeView.GridLineStyle = Aga.Controls.Tree.GridLineStyle.Horizontal;
      this.userTypesTreeView.Indent = 12;
      this.userTypesTreeView.LineColor = System.Drawing.SystemColors.ControlDark;
      this.userTypesTreeView.LoadOnDemand = true;
      this.userTypesTreeView.Location = new System.Drawing.Point(0, 0);
      this.userTypesTreeView.Model = null;
      this.userTypesTreeView.Name = "userTypesTreeView";
      this.userTypesTreeView.NodeControls.Add(this.nodeStateIcon);
      this.userTypesTreeView.NodeControls.Add(this.nameTextBox);
      this.userTypesTreeView.NodeControls.Add(this.definitionTextBox);
      this.userTypesTreeView.NodeControls.Add(this.flagsTextBox);
      this.userTypesTreeView.SelectedNode = null;
      this.userTypesTreeView.ShowLines = false;
      this.userTypesTreeView.ShowNodeToolTips = true;
      this.userTypesTreeView.ShowPlusMinus = false;
      this.userTypesTreeView.Size = new System.Drawing.Size(242, 266);
      this.userTypesTreeView.TabIndex = 1;
      this.userTypesTreeView.Text = "columnTreeView";
      this.userTypesTreeView.UseColumns = true;
      this.userTypesTreeView.SelectionChanged += new System.EventHandler(this.userTypesTreeView_SelectionChanged);
      this.userTypesTreeView.ItemDrag += new System.Windows.Forms.ItemDragEventHandler(this.userTypesTreeView_ItemDrag);
      // 
      // nameColumn
      // 
      this.nameColumn.Header = "Name";
      this.nameColumn.SortOrder = System.Windows.Forms.SortOrder.None;
      this.nameColumn.TooltipText = null;
      this.nameColumn.Width = 75;
      // 
      // definitionColumn
      // 
      this.definitionColumn.Header = "Definition";
      this.definitionColumn.SortOrder = System.Windows.Forms.SortOrder.None;
      this.definitionColumn.TooltipText = null;
      this.definitionColumn.Width = 80;
      // 
      // flagsColumn
      // 
      this.flagsColumn.Header = "Flags";
      this.flagsColumn.SortOrder = System.Windows.Forms.SortOrder.None;
      this.flagsColumn.TooltipText = null;
      this.flagsColumn.Width = 65;
      // 
      // contextMenuStrip1
      // 
      this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.deleteToolStripMenuItem});
      this.contextMenuStrip1.Name = "contextMenuStrip1";
      this.contextMenuStrip1.Size = new System.Drawing.Size(108, 26);
      this.contextMenuStrip1.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStrip1_Opening);
      // 
      // deleteToolStripMenuItem
      // 
      this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
      this.deleteToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
      this.deleteToolStripMenuItem.Text = "Delete";
      this.deleteToolStripMenuItem.Click += new System.EventHandler(this.deleteToolStripMenuItem_Click);
      // 
      // nodeStateIcon
      // 
      this.nodeStateIcon.LeftMargin = 0;
      this.nodeStateIcon.ParentColumn = this.nameColumn;
      // 
      // nameTextBox
      // 
      this.nameTextBox.IncrementalSearchEnabled = true;
      this.nameTextBox.LeftMargin = 3;
      this.nameTextBox.ParentColumn = this.nameColumn;
      this.nameTextBox.Trimming = System.Drawing.StringTrimming.EllipsisCharacter;
      // 
      // definitionTextBox
      // 
      this.definitionTextBox.IncrementalSearchEnabled = true;
      this.definitionTextBox.LeftMargin = 3;
      this.definitionTextBox.ParentColumn = this.definitionColumn;
      this.definitionTextBox.Trimming = System.Drawing.StringTrimming.EllipsisCharacter;
      // 
      // flagsTextBox
      // 
      this.flagsTextBox.IncrementalSearchEnabled = true;
      this.flagsTextBox.LeftMargin = 3;
      this.flagsTextBox.ParentColumn = this.flagsColumn;
      this.flagsTextBox.Trimming = System.Drawing.StringTrimming.EllipsisCharacter;
      // 
      // UserDatatypesForm
      // 
      this.AllowEndUserDocking = false;
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(242, 266);
      this.CloseButton = false;
      this.Controls.Add(this.userTypesTreeView);
      this.DockAreas = ((WeifenLuo.WinFormsUI.Docking.DockAreas)(((((WeifenLuo.WinFormsUI.Docking.DockAreas.DockLeft | WeifenLuo.WinFormsUI.Docking.DockAreas.DockRight)
                  | WeifenLuo.WinFormsUI.Docking.DockAreas.DockTop)
                  | WeifenLuo.WinFormsUI.Docking.DockAreas.DockBottom)
                  | WeifenLuo.WinFormsUI.Docking.DockAreas.Document)));
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "UserDatatypesForm";
      this.TabText = "UserDatatypesForm";
      this.Text = "UserDatatypesForm";
      this.contextMenuStrip1.ResumeLayout(false);
      this.ResumeLayout(false);

    }

    #endregion

    private Aga.Controls.Tree.TreeViewAdv userTypesTreeView;
    private Aga.Controls.Tree.TreeColumn nameColumn;
    private Aga.Controls.Tree.TreeColumn definitionColumn;
    private MySQL.Utilities.AdvNodeTextBox nameTextBox;
    private MySQL.Utilities.AdvNodeTextBox definitionTextBox;
    private Aga.Controls.Tree.NodeControls.NodeStateIcon nodeStateIcon;
    private Aga.Controls.Tree.TreeColumn flagsColumn;
    private Aga.Controls.Tree.NodeControls.NodeTextBox flagsTextBox;
    private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
    private System.Windows.Forms.ToolStripMenuItem deleteToolStripMenuItem;
  }
}