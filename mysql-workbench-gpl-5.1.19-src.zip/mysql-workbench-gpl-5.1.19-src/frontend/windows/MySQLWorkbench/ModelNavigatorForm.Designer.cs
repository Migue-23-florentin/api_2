namespace MySQL.GUI.Workbench
{
    partial class ModelNavigatorForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
          this.zoomComboBox = new System.Windows.Forms.ComboBox();
          this.zoomSlider = new System.Windows.Forms.TrackBar();
          this.splitContainer1 = new System.Windows.Forms.SplitContainer();
          this.navImagePanel = new MySQL.Utilities.DrawablePanel();
          this.splitContainer2 = new System.Windows.Forms.SplitContainer();
          this.zoomInPictureBox = new System.Windows.Forms.PictureBox();
          this.zoomOutPictureBox = new System.Windows.Forms.PictureBox();
          ((System.ComponentModel.ISupportInitialize)(this.zoomSlider)).BeginInit();
          this.splitContainer1.Panel1.SuspendLayout();
          this.splitContainer1.Panel2.SuspendLayout();
          this.splitContainer1.SuspendLayout();
          this.splitContainer2.Panel1.SuspendLayout();
          this.splitContainer2.Panel2.SuspendLayout();
          this.splitContainer2.SuspendLayout();
          ((System.ComponentModel.ISupportInitialize)(this.zoomInPictureBox)).BeginInit();
          ((System.ComponentModel.ISupportInitialize)(this.zoomOutPictureBox)).BeginInit();
          this.SuspendLayout();
          // 
          // zoomComboBox
          // 
          this.zoomComboBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
          this.zoomComboBox.FormatString = "###0";
          this.zoomComboBox.FormattingEnabled = true;
          this.zoomComboBox.Items.AddRange(new object[] {
            "200",
            "150",
            "100",
            "95",
            "90",
            "85",
            "80",
            "75",
            "70",
            "60",
            "50",
            "40",
            "30",
            "20",
            "10"});
          this.zoomComboBox.Location = new System.Drawing.Point(0, 0);
          this.zoomComboBox.Name = "zoomComboBox";
          this.zoomComboBox.Size = new System.Drawing.Size(52, 21);
          this.zoomComboBox.TabIndex = 1;
          this.zoomComboBox.Text = "100";
          this.zoomComboBox.SelectedIndexChanged += new System.EventHandler(this.zoomComboBox_SelectedIndexChanged);
          this.zoomComboBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.zoomComboBox_KeyDown);
          // 
          // zoomSlider
          // 
          this.zoomSlider.AutoSize = false;
          this.zoomSlider.Dock = System.Windows.Forms.DockStyle.Bottom;
          this.zoomSlider.Enabled = false;
          this.zoomSlider.Location = new System.Drawing.Point(19, 3);
          this.zoomSlider.Maximum = 200;
          this.zoomSlider.Minimum = 10;
          this.zoomSlider.Name = "zoomSlider";
          this.zoomSlider.Size = new System.Drawing.Size(94, 20);
          this.zoomSlider.TabIndex = 0;
          this.zoomSlider.TickStyle = System.Windows.Forms.TickStyle.None;
          this.zoomSlider.Value = 100;
          this.zoomSlider.Scroll += new System.EventHandler(this.zoomSlider_Scroll);
          // 
          // splitContainer1
          // 
          this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
          this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel2;
          this.splitContainer1.IsSplitterFixed = true;
          this.splitContainer1.Location = new System.Drawing.Point(4, 4);
          this.splitContainer1.Margin = new System.Windows.Forms.Padding(0);
          this.splitContainer1.Name = "splitContainer1";
          this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
          // 
          // splitContainer1.Panel1
          // 
          this.splitContainer1.Panel1.Controls.Add(this.navImagePanel);
          this.splitContainer1.Panel1.Padding = new System.Windows.Forms.Padding(0, 0, 0, 2);
          // 
          // splitContainer1.Panel2
          // 
          this.splitContainer1.Panel2.Controls.Add(this.splitContainer2);
          this.splitContainer1.Panel2MinSize = 23;
          this.splitContainer1.Size = new System.Drawing.Size(188, 158);
          this.splitContainer1.SplitterDistance = 134;
          this.splitContainer1.SplitterWidth = 1;
          this.splitContainer1.TabIndex = 0;
          this.splitContainer1.TabStop = false;
          // 
          // navImagePanel
          // 
          this.navImagePanel.CustomBackground = false;
          this.navImagePanel.Dock = System.Windows.Forms.DockStyle.Fill;
          this.navImagePanel.Location = new System.Drawing.Point(0, 0);
          this.navImagePanel.MinimumSize = new System.Drawing.Size(100, 100);
          this.navImagePanel.Name = "navImagePanel";
          this.navImagePanel.Size = new System.Drawing.Size(188, 132);
          this.navImagePanel.TabIndex = 0;
          this.navImagePanel.Paint += new System.Windows.Forms.PaintEventHandler(this.navImagePanel_Paint);
          this.navImagePanel.MouseMove += new System.Windows.Forms.MouseEventHandler(this.navImagePanel_MouseMove);
          this.navImagePanel.MouseDown += new System.Windows.Forms.MouseEventHandler(this.navImagePanel_MouseDown);
          this.navImagePanel.MouseUp += new System.Windows.Forms.MouseEventHandler(this.navImagePanel_MouseUp);
          this.navImagePanel.SizeChanged += new System.EventHandler(this.navImagePanel_SizeChanged);
          // 
          // splitContainer2
          // 
          this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
          this.splitContainer2.FixedPanel = System.Windows.Forms.FixedPanel.Panel2;
          this.splitContainer2.IsSplitterFixed = true;
          this.splitContainer2.Location = new System.Drawing.Point(0, 0);
          this.splitContainer2.Margin = new System.Windows.Forms.Padding(0);
          this.splitContainer2.Name = "splitContainer2";
          // 
          // splitContainer2.Panel1
          // 
          this.splitContainer2.Panel1.Controls.Add(this.zoomSlider);
          this.splitContainer2.Panel1.Controls.Add(this.zoomInPictureBox);
          this.splitContainer2.Panel1.Controls.Add(this.zoomOutPictureBox);
          // 
          // splitContainer2.Panel2
          // 
          this.splitContainer2.Panel2.Controls.Add(this.zoomComboBox);
          this.splitContainer2.Size = new System.Drawing.Size(188, 23);
          this.splitContainer2.SplitterDistance = 132;
          this.splitContainer2.TabIndex = 2;
          this.splitContainer2.TabStop = false;
          // 
          // zoomInPictureBox
          // 
          this.zoomInPictureBox.Dock = System.Windows.Forms.DockStyle.Right;
          this.zoomInPictureBox.Image = global::MySQL.GUI.Workbench.Properties.Resources.navigator_zoom_in;
          this.zoomInPictureBox.Location = new System.Drawing.Point(113, 0);
          this.zoomInPictureBox.Name = "zoomInPictureBox";
          this.zoomInPictureBox.Size = new System.Drawing.Size(19, 23);
          this.zoomInPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
          this.zoomInPictureBox.TabIndex = 2;
          this.zoomInPictureBox.TabStop = false;
          this.zoomInPictureBox.Click += new System.EventHandler(this.zoomInPictureBox_Click);
          // 
          // zoomOutPictureBox
          // 
          this.zoomOutPictureBox.Dock = System.Windows.Forms.DockStyle.Left;
          this.zoomOutPictureBox.Image = global::MySQL.GUI.Workbench.Properties.Resources.navigator_zoom_out;
          this.zoomOutPictureBox.Location = new System.Drawing.Point(0, 0);
          this.zoomOutPictureBox.Name = "zoomOutPictureBox";
          this.zoomOutPictureBox.Size = new System.Drawing.Size(19, 23);
          this.zoomOutPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
          this.zoomOutPictureBox.TabIndex = 1;
          this.zoomOutPictureBox.TabStop = false;
          this.zoomOutPictureBox.Click += new System.EventHandler(this.zoomOutPictureBox_Click);
          // 
          // ModelNavigatorForm
          // 
          this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
          this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
          this.BackColor = System.Drawing.SystemColors.Window;
          this.ClientSize = new System.Drawing.Size(196, 166);
          this.Controls.Add(this.splitContainer1);
          this.DockAreas = ((WeifenLuo.WinFormsUI.Docking.DockAreas)(((((WeifenLuo.WinFormsUI.Docking.DockAreas.DockLeft | WeifenLuo.WinFormsUI.Docking.DockAreas.DockRight)
                      | WeifenLuo.WinFormsUI.Docking.DockAreas.DockTop)
                      | WeifenLuo.WinFormsUI.Docking.DockAreas.DockBottom)
                      | WeifenLuo.WinFormsUI.Docking.DockAreas.Document)));
          this.HideOnClose = true;
          this.Name = "ModelNavigatorForm";
          this.Padding = new System.Windows.Forms.Padding(4);
          this.TabText = "Model Navigator";
          this.Text = "Model Navigator";
          this.Shown += new System.EventHandler(this.ModelNavigatorForm_Shown);
          ((System.ComponentModel.ISupportInitialize)(this.zoomSlider)).EndInit();
          this.splitContainer1.Panel1.ResumeLayout(false);
          this.splitContainer1.Panel2.ResumeLayout(false);
          this.splitContainer1.ResumeLayout(false);
          this.splitContainer2.Panel1.ResumeLayout(false);
          this.splitContainer2.Panel2.ResumeLayout(false);
          this.splitContainer2.ResumeLayout(false);
          ((System.ComponentModel.ISupportInitialize)(this.zoomInPictureBox)).EndInit();
          ((System.ComponentModel.ISupportInitialize)(this.zoomOutPictureBox)).EndInit();
          this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TrackBar zoomSlider;
      private System.Windows.Forms.ComboBox zoomComboBox;
      private System.Windows.Forms.SplitContainer splitContainer1;
      private System.Windows.Forms.SplitContainer splitContainer2;
      private MySQL.Utilities.DrawablePanel navImagePanel;
      private System.Windows.Forms.PictureBox zoomInPictureBox;
      private System.Windows.Forms.PictureBox zoomOutPictureBox;
    }
}