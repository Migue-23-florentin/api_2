using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;

namespace MySQL.GUI.Workbench
{
	public partial class TextEditorForm : DockContent
	{
		public TextEditorForm()
		{
			InitializeComponent();
		}

		public RichTextBox RichTextBox
		{
			get { return richTextBox; }
		}

    private void TextEditorForm_KeyDown(object sender, KeyEventArgs e)
    {
      switch (e.KeyCode)
      {
        case Keys.Escape:
          DialogResult = DialogResult.Cancel;
          Close();
          e.Handled = true;
          break;
        case Keys.Enter:
          DialogResult = DialogResult.OK;
          Close();
          e.Handled = true;
          break;
      }
    }
	}
}