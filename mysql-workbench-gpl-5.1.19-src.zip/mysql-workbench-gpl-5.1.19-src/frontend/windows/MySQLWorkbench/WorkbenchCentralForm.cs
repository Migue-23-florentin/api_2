﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

using MySQL.Grt;
using MySQL.Workbench;

namespace MySQL.GUI.Workbench
{
  public partial class WorkbenchCentralForm : UserControl
  {
    public WorkbenchCentralForm(Overview wbOverview)
    {
      InitializeComponent();

      foreach (Control control in Controls)
      {
        String tag = "0."+control.Tag as String;

        if (control is LinkLabel)
        {
          String text;
          wbOverview.get_field(new NodeId(tag), 0, out text);
          control.Text = text;

          // store URL in tag
          wbOverview.get_field(new NodeId(tag), 101, out text);
          control.Tag = text;
        }
        else if (control is Label)
        {
          String text;
          wbOverview.get_field(new NodeId(tag), 100, out text);
          control.Text = text;
        }
        else if (control is Button)
        {
          String text;
          wbOverview.get_field(new NodeId(tag), 0, out text);
          control.Text = text;

          // store URL in tag
          wbOverview.get_field(new NodeId(tag), 101, out text);
          control.Tag = text;
        }
      }
    }

    private void linkLabel_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
    {
      String url = ((Control)sender).Tag as String;

      BrowseToUrl(url);
    }

    private void button_Click(object sender, EventArgs e)
    {
      String url = ((Control)sender).Tag as String;

      BrowseToUrl(url);
    }

    public void BrowseToUrl(string url)
    {
      try
      {
        System.Diagnostics.Process.Start(url);
      }
      catch (Exception e)
      {
        MessageBox.Show(e.Message.ToString(), "Error Opening Browser",
          MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
      }
    }
  }
}
