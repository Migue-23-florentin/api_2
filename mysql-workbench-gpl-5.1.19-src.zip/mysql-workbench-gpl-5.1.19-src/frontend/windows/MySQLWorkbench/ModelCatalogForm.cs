using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;
using Aga.Controls.Tree;
using MySQL.Grt;
using MySQL.Workbench;

namespace MySQL.GUI.Workbench
{
	public partial class ModelCatalogForm : DockContent
	{
		private WbContext wbContext;
		private GrtManager grtManager;
		private ModelCatalogTreeModel catalogTreeModel;
		private Point dragStart;

		private ModelCatalogForm()
		{
			InitializeComponent();
		}

		public ModelCatalogForm(WbContext WbContext)
			: this()
		{
			wbContext = WbContext;
			grtManager = wbContext.get_grt_manager();

      catalogTreeModel = new ModelCatalogTreeModel(catalogTreeView,
                    wbContext.get_catalog_tree(), nodeStateIcon);
      catalogTreeModel.AddColumn(nameNodeControl, 0, true);
      catalogTreeModel.AddColumn(presenceNodeControl, 1, false);
      catalogTreeView.Model = catalogTreeModel;

      UpdateCatalogTree();
		}

    public void RefreshContents()
    {
      catalogTreeView.Refresh();
    }

		public void UpdateCatalogTree()
		{
      catalogTreeView.BeginUpdate();

			if (catalogTreeModel != null)
				catalogTreeModel.RefreshModel();

      expandImportantNodes();

      catalogTreeView.EndUpdate();
		}

    public void updateContextMenu(List<NodeId> nodes)
    {
      catalogMenuStrip.Items.Clear();

      List<MySQL.Grt.MenuItem> items = catalogTreeModel.GrtTree.get_popup_items_for_nodes(nodes);
      foreach (MySQL.Grt.MenuItem grtMenuItem in items)
      {
        ToolStripMenuItem item = new ToolStripMenuItem(grtMenuItem.get_caption());
        item.Enabled = grtMenuItem.get_enabled();
        item.Tag = grtMenuItem.get_name();
        item.Click += new EventHandler(contextMenuClick);
        catalogMenuStrip.Items.Add(item);
      }
    }

    void contextMenuClick(object sender, EventArgs e)
    {
      ToolStripMenuItem menuItem = sender as ToolStripMenuItem;

      List<NodeId> nodes = new List<NodeId>();
      GrtTreeNode treeNode = catalogTreeView.SelectedNode.Tag as GrtTreeNode;
      nodes.Add(treeNode.NodeId);
      string command = menuItem.Tag as string;

      if (!catalogTreeModel.GrtTree.activate_popup_item_for_nodes(command, nodes))
      {
        // The backend could not handle the menu command. See if we can make sense of it here.
        if (command == "refereshCatalog")
          UpdateCatalogTree();
      }
    }

    private void expandImportantNodes()
    {
      catalogTreeView.Root.Expand();
      foreach (TreeNodeAdv node in catalogTreeView.Root.Children)
      {
        node.Expand();

        foreach (TreeNodeAdv node2 in node.Children)
          node2.Expand();
      }
    }

		private void schemataTreeView_MouseDown(object sender, MouseEventArgs e)
		{
			dragStart = new Point(e.X, e.Y);
		}

		private void schemataTreeView_MouseMove(object sender, MouseEventArgs e)
		{
      if (e.Button == MouseButtons.Left && catalogTreeModel != null)
			{
				if (Math.Abs(dragStart.X - e.X) > 3 || Math.Abs(dragStart.Y - e.Y) > 3)
				{
          if (catalogTreeView.SelectedNodes.Count > 1)
          {
            List<GrtValue> list= new List<GrtValue>();
            foreach (TreeNodeAdv node in catalogTreeView.SelectedNodes)
            {
              GrtValue val = catalogTreeModel.GetNodeGrtValue(node);

              if (val != null)
                list.Add(val);
            }
            if (list.Count > 0)
              DoDragDrop(list, DragDropEffects.Copy);
          }
          else
          {
            GrtValue val = catalogTreeModel.GetNodeGrtValue(catalogTreeView.SelectedNode);

            if (val != null)
              DoDragDrop(val, DragDropEffects.Copy);
          }
				}
			}
		}

    private void catalogMenuStrip_Opening(object sender, CancelEventArgs e)
    {
      List<NodeId> nodes = new List<NodeId>();
      foreach (TreeNodeAdv node in catalogTreeView.SelectedNodes)
      {
        GrtTreeNode treeNode = node.Tag as GrtTreeNode;
        nodes.Add(treeNode.NodeId);
      }
      updateContextMenu(nodes);
    }

	}
}