namespace MySQL.GUI.Workbench
{
	partial class WorkbenchOverviewForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(WorkbenchOverviewForm));
      this.pictureBox1 = new System.Windows.Forms.PictureBox();
      this.modelTypeCollapsingPanel = new MySQL.Utilities.CollapsingPanel();
      ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
      this.SuspendLayout();
      // 
      // pictureBox1
      // 
      this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
      this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
      this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Top;
      this.pictureBox1.Location = new System.Drawing.Point(0, 25);
      this.pictureBox1.Name = "pictureBox1";
      this.pictureBox1.Size = new System.Drawing.Size(721, 25);
      this.pictureBox1.TabIndex = 9;
      this.pictureBox1.TabStop = false;
      // 
      // modelTypeCollapsingPanel
      // 
      this.modelTypeCollapsingPanel.DisableExpansion = true;
      this.modelTypeCollapsingPanel.DisplayCustomButtons = false;
      this.modelTypeCollapsingPanel.DisplayMode = MySQL.Utilities.CollapsingPanelDisplayMode.HeaderWithTabs;
      this.modelTypeCollapsingPanel.DisplayTabActionButtons = false;
      this.modelTypeCollapsingPanel.Dock = System.Windows.Forms.DockStyle.Top;
      this.modelTypeCollapsingPanel.Expanded = false;
      this.modelTypeCollapsingPanel.HeaderCaption = "Caption";
      this.modelTypeCollapsingPanel.HeaderFont = new System.Drawing.Font("Trebuchet MS", 11F, System.Drawing.FontStyle.Bold);
      this.modelTypeCollapsingPanel.HeaderSpace = 5;
      this.modelTypeCollapsingPanel.Location = new System.Drawing.Point(0, 0);
      this.modelTypeCollapsingPanel.Name = "modelTypeCollapsingPanel";
      this.modelTypeCollapsingPanel.SelectedTabIndex = 1;
      this.modelTypeCollapsingPanel.Size = new System.Drawing.Size(721, 25);
      this.modelTypeCollapsingPanel.Style = MySQL.Utilities.CollapsingPanelStyle.Flat;
      this.modelTypeCollapsingPanel.TabHeaderCaptionFont = new System.Drawing.Font("Trebuchet MS", 11F, System.Drawing.FontStyle.Bold);
      this.modelTypeCollapsingPanel.TabHeaderDescriptionFont = new System.Drawing.Font("Trebuchet MS", 7F);
      this.modelTypeCollapsingPanel.TabHeaderImageList = null;
      this.modelTypeCollapsingPanel.TabIndex = 10;
      this.modelTypeCollapsingPanel.Visible = false;
      this.modelTypeCollapsingPanel.TabCountNeeded += new MySQL.Utilities.TabCountHandler(this.modelTypeCollapsingPanel_TabCountNeeded);
      this.modelTypeCollapsingPanel.TabInfoNeeded += new MySQL.Utilities.TabInfoHandler(this.modelTypeCollapsingPanel_TabInfoNeeded);
      // 
      // WorkbenchOverviewForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.AutoScroll = true;
      this.BackColor = System.Drawing.SystemColors.Window;
      this.BackgroundImage = global::MySQL.GUI.Workbench.Properties.Resources.background;
      this.ClientSize = new System.Drawing.Size(721, 608);
      this.Controls.Add(this.pictureBox1);
      this.Controls.Add(this.modelTypeCollapsingPanel);
      this.DoubleBuffered = true;
      this.HideOnClose = true;
      this.KeyPreview = true;
      this.Name = "WorkbenchOverviewForm";
      this.TabText = "MySQL Model";
      this.Text = "MySQL Model";
      this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.WorkbenchOverviewForm_FormClosing);
      ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
      this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.PictureBox pictureBox1;
    private MySQL.Utilities.CollapsingPanel modelTypeCollapsingPanel;
	}
}