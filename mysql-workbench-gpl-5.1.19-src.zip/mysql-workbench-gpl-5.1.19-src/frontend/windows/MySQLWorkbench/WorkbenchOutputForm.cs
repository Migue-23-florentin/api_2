using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;
using Aga.Controls.Tree;
using MySQL.Grt;
using MySQL.Workbench;


namespace MySQL.GUI.Workbench
{
  public partial class WorkbenchOutputForm : DockContent
  {
    #region Member Variables

    protected WbContext wbContext;

    private GrtMessageList messageListBE;
    private SimpleGrtListModel messageListModel;

    #endregion

    #region Constructor

    public WorkbenchOutputForm(WbContext WbContext)
    {
      InitializeComponent();

      wbContext = WbContext;

      messageListBE = wbContext.get_grt_manager().get_messages_list();
      messageListModel = new SimpleGrtListModel(messageTreeView, messageListBE, nodeIcon, false);
      messageListModel.AddColumn(timeText, (int)GrtMessageList.Columns.Time, false);
      messageListModel.AddColumn(messageText, (int)GrtMessageList.Columns.Message, false);
      messageTreeView.Model = messageListModel;
    }

    #endregion

    public void PrintOutputText(string OutputText)
    {
      outputTextBox.AppendText(OutputText);
      outputTextBox.SelectionStart = outputTextBox.Text.Length;
      outputTextBox.SelectionLength = 0;
    }

    public void RefreshMessages()
    {
      messageListModel.RefreshModel();

      // Scroll to end
      if (messageTreeView.Root.Children.Count > 0)
        messageTreeView.ScrollTo(messageTreeView.Root.Children[messageTreeView.Root.Children.Count - 1]);
    }

    private void copyMessagesToClipboardToolStripMenuItem_Click(object sender, EventArgs e)
    {
      String messages = "";

      foreach(TreeNodeAdv treeNode in messageTreeView.SelectedNodes) 
      {
        messages += messageListModel.GetRowAsText(treeNode) + Environment.NewLine;
      }

      Clipboard.Clear();
      if (messages.Length > 0)
        Clipboard.SetDataObject(messages, true);
    }

		private void clearOutputWindowsToolStripMenuItem_Click(object sender, EventArgs e)
		{
			outputTextBox.Clear();
			messageListBE.clear();
			messageListModel.RefreshModel();
		}

    private void copyItem_Click(object sender, EventArgs e)
    {
      Clipboard.Clear();
      String text = outputTextBox.SelectedText;
      if (text.Length > 0)
        Clipboard.SetText(text);
    }

    private void selectAllItem_Click(object sender, EventArgs e)
    {
      outputTextBox.SelectAll();
    }

  }
}