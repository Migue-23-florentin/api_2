// SE EE
using System;
using WeifenLuo.WinFormsUI.Docking;
using MySQL.Workbench;

namespace MySQL.GUI.Workbench
{
	partial class MainForm
	{
  }
}

