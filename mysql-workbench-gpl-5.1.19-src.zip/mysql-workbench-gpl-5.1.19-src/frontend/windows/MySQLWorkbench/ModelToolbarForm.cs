using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;

namespace MySQL.GUI.Workbench
{
    public partial class ModelToolbarForm : DockContent
    {
        public ModelToolbarForm()
        {
            InitializeComponent();
        }
    }
}