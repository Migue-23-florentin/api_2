namespace MySQL.GUI.Workbench
{
	partial class MainForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      this.components = new System.ComponentModel.Container();
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
      this.mainStatusStrip = new System.Windows.Forms.StatusStrip();
      this.statusLbl = new System.Windows.Forms.ToolStripStatusLabel();
      this.statusProgress = new System.Windows.Forms.ToolStripProgressBar();
      this.mainMenuStrip = new System.Windows.Forms.MenuStrip();
      this.toolBarStrip = new System.Windows.Forms.ToolStrip();
      this.mainDockPanel = new WeifenLuo.WinFormsUI.Docking.DockPanel();
      this.workToolStrip = new System.Windows.Forms.ToolStrip();
      this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
      this.bevel1 = new MySQL.Utilities.Bevel();
      this.mainFormToolTip = new System.Windows.Forms.ToolTip(this.components);
      this.sidebarFlatTabControl = new MySQL.Utilities.FlatTabControl.FlatTabControl();
      this.modelSidebarTabPage = new System.Windows.Forms.TabPage();
      this.modelSidebarDockPanel = new WeifenLuo.WinFormsUI.Docking.DockPanel();
      this.grtTabPage = new System.Windows.Forms.TabPage();
      this.grtDockPanel = new WeifenLuo.WinFormsUI.Docking.DockPanel();
      this.mainSplitContainer = new System.Windows.Forms.SplitContainer();
      this.spacerPanel = new System.Windows.Forms.Panel();
      this.mainStatusStrip.SuspendLayout();
      this.workToolStrip.SuspendLayout();
      this.sidebarFlatTabControl.SuspendLayout();
      this.modelSidebarTabPage.SuspendLayout();
      this.grtTabPage.SuspendLayout();
      this.mainSplitContainer.Panel1.SuspendLayout();
      this.mainSplitContainer.Panel2.SuspendLayout();
      this.mainSplitContainer.SuspendLayout();
      this.SuspendLayout();
      // 
      // mainStatusStrip
      // 
      this.mainStatusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.statusLbl,
            this.statusProgress});
      this.mainStatusStrip.Location = new System.Drawing.Point(0, 549);
      this.mainStatusStrip.Name = "mainStatusStrip";
      this.mainStatusStrip.Size = new System.Drawing.Size(792, 22);
      this.mainStatusStrip.TabIndex = 0;
      this.mainStatusStrip.Text = "statusStrip1";
      // 
      // statusLbl
      // 
      this.statusLbl.Name = "statusLbl";
      this.statusLbl.Size = new System.Drawing.Size(777, 17);
      this.statusLbl.Spring = true;
      this.statusLbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // statusProgress
      // 
      this.statusProgress.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
      this.statusProgress.Name = "statusProgress";
      this.statusProgress.Size = new System.Drawing.Size(100, 16);
      this.statusProgress.Visible = false;
      // 
      // mainMenuStrip
      // 
      this.mainMenuStrip.BackColor = System.Drawing.SystemColors.MenuBar;
      this.mainMenuStrip.Location = new System.Drawing.Point(0, 0);
      this.mainMenuStrip.Name = "mainMenuStrip";
      this.mainMenuStrip.Size = new System.Drawing.Size(792, 24);
      this.mainMenuStrip.TabIndex = 1;
      this.mainMenuStrip.Text = "mainMenuStrip";
      // 
      // toolBarStrip
      // 
      this.toolBarStrip.BackColor = System.Drawing.SystemColors.ButtonFace;
      this.toolBarStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
      this.toolBarStrip.Location = new System.Drawing.Point(0, 25);
      this.toolBarStrip.MinimumSize = new System.Drawing.Size(0, 30);
      this.toolBarStrip.Name = "toolBarStrip";
      this.toolBarStrip.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
      this.toolBarStrip.Size = new System.Drawing.Size(792, 30);
      this.toolBarStrip.TabIndex = 2;
      this.toolBarStrip.Text = "toolStrip1";
      // 
      // mainDockPanel
      // 
      this.mainDockPanel.ActiveAutoHideContent = null;
      this.mainDockPanel.BackColor = System.Drawing.SystemColors.ButtonFace;
      this.mainDockPanel.Dock = System.Windows.Forms.DockStyle.Fill;
      this.mainDockPanel.DockRightPortion = 0.2;
      this.mainDockPanel.DocumentStyle = WeifenLuo.WinFormsUI.Docking.DocumentStyle.DockingWindow;
      this.mainDockPanel.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.World);
      this.mainDockPanel.Location = new System.Drawing.Point(0, 0);
      this.mainDockPanel.Margin = new System.Windows.Forms.Padding(0);
      this.mainDockPanel.Name = "mainDockPanel";
      this.mainDockPanel.Size = new System.Drawing.Size(535, 492);
      this.mainDockPanel.TabIndex = 0;
      this.mainDockPanel.ContentAdded += new System.EventHandler<WeifenLuo.WinFormsUI.Docking.DockContentEventArgs>(this.mainDockPanel_ContentAdded);
      this.mainDockPanel.ActiveDocumentChanged += new System.EventHandler(this.mainDockPanel_ActiveDocumentChanged);
      this.mainDockPanel.ContentRemoved += new System.EventHandler<WeifenLuo.WinFormsUI.Docking.DockContentEventArgs>(this.mainDockPanel_ContentRemoved);
      // 
      // workToolStrip
      // 
      this.workToolStrip.BackColor = System.Drawing.SystemColors.ButtonFace;
      this.workToolStrip.Dock = System.Windows.Forms.DockStyle.Left;
      this.workToolStrip.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
      this.workToolStrip.ImageScalingSize = new System.Drawing.Size(24, 22);
      this.workToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLabel1});
      this.workToolStrip.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.VerticalStackWithOverflow;
      this.workToolStrip.Location = new System.Drawing.Point(0, 55);
      this.workToolStrip.MinimumSize = new System.Drawing.Size(33, 0);
      this.workToolStrip.Name = "workToolStrip";
      this.workToolStrip.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
      this.workToolStrip.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
      this.workToolStrip.Size = new System.Drawing.Size(33, 494);
      this.workToolStrip.TabIndex = 6;
      this.workToolStrip.Text = "toolStrip1";
      // 
      // toolStripLabel1
      // 
      this.toolStripLabel1.Font = new System.Drawing.Font("Tahoma", 3.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.toolStripLabel1.Margin = new System.Windows.Forms.Padding(0);
      this.toolStripLabel1.MergeIndex = 1000;
      this.toolStripLabel1.Name = "toolStripLabel1";
      this.toolStripLabel1.Size = new System.Drawing.Size(28, 6);
      this.toolStripLabel1.Text = "              ";
      // 
      // bevel1
      // 
      this.bevel1.BevelStyle = MySQL.Utilities.BevelStyleType.White;
      this.bevel1.BorderSide = System.Windows.Forms.Border3DSide.Top;
      this.bevel1.Dock = System.Windows.Forms.DockStyle.Top;
      this.bevel1.Location = new System.Drawing.Point(0, 24);
      this.bevel1.Name = "bevel1";
      this.bevel1.Size = new System.Drawing.Size(792, 1);
      this.bevel1.TabIndex = 16;
      this.bevel1.Text = "bevel1";
      // 
      // sidebarFlatTabControl
      // 
      this.sidebarFlatTabControl.Controls.Add(this.modelSidebarTabPage);
      this.sidebarFlatTabControl.Controls.Add(this.grtTabPage);
      this.sidebarFlatTabControl.Dock = System.Windows.Forms.DockStyle.Fill;
      this.sidebarFlatTabControl.HotTrack = true;
      this.sidebarFlatTabControl.ItemSize = new System.Drawing.Size(50, 16);
      this.sidebarFlatTabControl.Location = new System.Drawing.Point(0, 0);
      this.sidebarFlatTabControl.Margin = new System.Windows.Forms.Padding(0);
      this.sidebarFlatTabControl.myBackColor = System.Drawing.SystemColors.ButtonFace;
      this.sidebarFlatTabControl.Name = "sidebarFlatTabControl";
      this.sidebarFlatTabControl.Padding = new System.Drawing.Point(0, 0);
      this.sidebarFlatTabControl.SelectedIndex = 0;
      this.sidebarFlatTabControl.Size = new System.Drawing.Size(219, 492);
      this.sidebarFlatTabControl.TabIndex = 1;
      // 
      // modelSidebarTabPage
      // 
      this.modelSidebarTabPage.Controls.Add(this.modelSidebarDockPanel);
      this.modelSidebarTabPage.Location = new System.Drawing.Point(4, 20);
      this.modelSidebarTabPage.Margin = new System.Windows.Forms.Padding(0);
      this.modelSidebarTabPage.Name = "modelSidebarTabPage";
      this.modelSidebarTabPage.Size = new System.Drawing.Size(211, 468);
      this.modelSidebarTabPage.TabIndex = 0;
      this.modelSidebarTabPage.Text = "Workbench Model";
      this.modelSidebarTabPage.UseVisualStyleBackColor = true;
      // 
      // modelSidebarDockPanel
      // 
      this.modelSidebarDockPanel.ActiveAutoHideContent = null;
      this.modelSidebarDockPanel.AllowEndUserDocking = false;
      this.modelSidebarDockPanel.AllowEndUserNestedDocking = false;
      this.modelSidebarDockPanel.Dock = System.Windows.Forms.DockStyle.Fill;
      this.modelSidebarDockPanel.DockBottomPortion = 0.8;
      this.modelSidebarDockPanel.DockTopPortion = 0.2;
      this.modelSidebarDockPanel.DocumentStyle = WeifenLuo.WinFormsUI.Docking.DocumentStyle.DockingSdi;
      this.modelSidebarDockPanel.Location = new System.Drawing.Point(0, 0);
      this.modelSidebarDockPanel.Margin = new System.Windows.Forms.Padding(0);
      this.modelSidebarDockPanel.Name = "modelSidebarDockPanel";
      this.modelSidebarDockPanel.Size = new System.Drawing.Size(211, 468);
      this.modelSidebarDockPanel.TabIndex = 0;
      // 
      // grtTabPage
      // 
      this.grtTabPage.Controls.Add(this.grtDockPanel);
      this.grtTabPage.Location = new System.Drawing.Point(4, 20);
      this.grtTabPage.Margin = new System.Windows.Forms.Padding(0);
      this.grtTabPage.Name = "grtTabPage";
      this.grtTabPage.Size = new System.Drawing.Size(211, 468);
      this.grtTabPage.TabIndex = 1;
      this.grtTabPage.Text = "GRT Shell";
      this.grtTabPage.UseVisualStyleBackColor = true;
      // 
      // grtDockPanel
      // 
      this.grtDockPanel.ActiveAutoHideContent = null;
      this.grtDockPanel.Dock = System.Windows.Forms.DockStyle.Fill;
      this.grtDockPanel.DockBottomPortion = 0.7;
      this.grtDockPanel.DocumentStyle = WeifenLuo.WinFormsUI.Docking.DocumentStyle.DockingSdi;
      this.grtDockPanel.Location = new System.Drawing.Point(0, 0);
      this.grtDockPanel.Margin = new System.Windows.Forms.Padding(0);
      this.grtDockPanel.Name = "grtDockPanel";
      this.grtDockPanel.Size = new System.Drawing.Size(211, 468);
      this.grtDockPanel.TabIndex = 0;
      // 
      // mainSplitContainer
      // 
      this.mainSplitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
      this.mainSplitContainer.FixedPanel = System.Windows.Forms.FixedPanel.Panel2;
      this.mainSplitContainer.Location = new System.Drawing.Point(33, 55);
      this.mainSplitContainer.Margin = new System.Windows.Forms.Padding(0);
      this.mainSplitContainer.Name = "mainSplitContainer";
      // 
      // mainSplitContainer.Panel1
      // 
      this.mainSplitContainer.Panel1.Controls.Add(this.mainDockPanel);
      this.mainSplitContainer.Panel1MinSize = 0;
      // 
      // mainSplitContainer.Panel2
      // 
      this.mainSplitContainer.Panel2.Controls.Add(this.sidebarFlatTabControl);
      this.mainSplitContainer.Panel2.Padding = new System.Windows.Forms.Padding(0, 0, 2, 0);
      this.mainSplitContainer.Panel2MinSize = 0;
      this.mainSplitContainer.Size = new System.Drawing.Size(759, 492);
      this.mainSplitContainer.SplitterDistance = 535;
      this.mainSplitContainer.SplitterWidth = 3;
      this.mainSplitContainer.TabIndex = 2;
      this.mainSplitContainer.TabStop = false;
      // 
      // spacerPanel
      // 
      this.spacerPanel.BackColor = System.Drawing.SystemColors.ButtonFace;
      this.spacerPanel.Dock = System.Windows.Forms.DockStyle.Bottom;
      this.spacerPanel.Location = new System.Drawing.Point(33, 547);
      this.spacerPanel.Name = "spacerPanel";
      this.spacerPanel.Size = new System.Drawing.Size(759, 2);
      this.spacerPanel.TabIndex = 1;
      this.spacerPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.spacerPanel_Paint);
      // 
      // MainForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(792, 571);
      this.Controls.Add(this.mainSplitContainer);
      this.Controls.Add(this.spacerPanel);
      this.Controls.Add(this.workToolStrip);
      this.Controls.Add(this.toolBarStrip);
      this.Controls.Add(this.mainStatusStrip);
      this.Controls.Add(this.bevel1);
      this.Controls.Add(this.mainMenuStrip);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.KeyPreview = true;
      this.Location = new System.Drawing.Point(40, 40);
      this.MainMenuStrip = this.mainMenuStrip;
      this.MinimumSize = new System.Drawing.Size(800, 600);
      this.Name = "MainForm";
      this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
      this.Text = "MySQL Workbench";
      this.Load += new System.EventHandler(this.MainForm_Load);
      this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
      this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.MainForm_KeyDown);
      this.mainStatusStrip.ResumeLayout(false);
      this.mainStatusStrip.PerformLayout();
      this.workToolStrip.ResumeLayout(false);
      this.workToolStrip.PerformLayout();
      this.sidebarFlatTabControl.ResumeLayout(false);
      this.modelSidebarTabPage.ResumeLayout(false);
      this.grtTabPage.ResumeLayout(false);
      this.mainSplitContainer.Panel1.ResumeLayout(false);
      this.mainSplitContainer.Panel2.ResumeLayout(false);
      this.mainSplitContainer.ResumeLayout(false);
      this.ResumeLayout(false);
      this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.StatusStrip mainStatusStrip;
    private System.Windows.Forms.MenuStrip mainMenuStrip;
    private System.Windows.Forms.ToolStrip toolBarStrip;
    private System.Windows.Forms.ToolStrip workToolStrip;
		private System.Windows.Forms.ToolStripStatusLabel statusLbl;
		private WeifenLuo.WinFormsUI.Docking.DockPanel mainDockPanel;
    private MySQL.Utilities.Bevel bevel1;
    private System.Windows.Forms.ToolStripLabel toolStripLabel1;
    private System.Windows.Forms.ToolStripProgressBar statusProgress;
    private System.Windows.Forms.ToolTip mainFormToolTip;
    private MySQL.Utilities.FlatTabControl.FlatTabControl sidebarFlatTabControl;
    private System.Windows.Forms.TabPage modelSidebarTabPage;
    private System.Windows.Forms.TabPage grtTabPage;
    private System.Windows.Forms.SplitContainer mainSplitContainer;
    private WeifenLuo.WinFormsUI.Docking.DockPanel modelSidebarDockPanel;
    private WeifenLuo.WinFormsUI.Docking.DockPanel grtDockPanel;
    private System.Windows.Forms.Panel spacerPanel;
	}
}

