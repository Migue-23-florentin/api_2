﻿namespace MySQL.Grt.Db
{
    partial class DbSqlEditor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
          this.queryTabs = new MySQL.Utilities.FlatTabControl.FlatTabControl();
          this.tpMessages = new System.Windows.Forms.TabPage();
          this.tpExplain = new System.Windows.Forms.TabPage();
          this.tpHistory = new System.Windows.Forms.TabPage();
          this.historyTB = new System.Windows.Forms.TextBox();
          this.treeColumn1 = new Aga.Controls.Tree.TreeColumn();
          this.treeColumn2 = new Aga.Controls.Tree.TreeColumn();
          this.nodeTextBox1 = new Aga.Controls.Tree.NodeControls.NodeTextBox();
          this.nodeTextBox2 = new Aga.Controls.Tree.NodeControls.NodeTextBox();
          this.splitter1 = new System.Windows.Forms.Splitter();
          this.execButton = new System.Windows.Forms.Button();
          this.splitContainer = new System.Windows.Forms.SplitContainer();
          this.panel1 = new System.Windows.Forms.Panel();
          this.queryTabs.SuspendLayout();
          this.tpHistory.SuspendLayout();
          this.splitContainer.Panel2.SuspendLayout();
          this.splitContainer.SuspendLayout();
          this.panel1.SuspendLayout();
          this.SuspendLayout();
          // 
          // queryTabs
          // 
          this.queryTabs.Alignment = System.Windows.Forms.TabAlignment.Bottom;
          this.queryTabs.Controls.Add(this.tpMessages);
          this.queryTabs.Controls.Add(this.tpExplain);
          this.queryTabs.Controls.Add(this.tpHistory);
          this.queryTabs.Dock = System.Windows.Forms.DockStyle.Fill;
          this.queryTabs.Location = new System.Drawing.Point(0, 0);
          this.queryTabs.myBackColor = System.Drawing.SystemColors.Control;
          this.queryTabs.Name = "queryTabs";
          this.queryTabs.SelectedIndex = 0;
          this.queryTabs.Size = new System.Drawing.Size(677, 188);
          this.queryTabs.TabIndex = 0;
          // 
          // tpMessages
          // 
          this.tpMessages.Location = new System.Drawing.Point(4, 4);
          this.tpMessages.Name = "tpMessages";
          this.tpMessages.Size = new System.Drawing.Size(669, 159);
          this.tpMessages.TabIndex = 1;
          this.tpMessages.Text = "Messages";
          // 
          // tpExplain
          // 
          this.tpExplain.Location = new System.Drawing.Point(4, 4);
          this.tpExplain.Name = "tpExplain";
          this.tpExplain.Size = new System.Drawing.Size(669, 159);
          this.tpExplain.TabIndex = 2;
          this.tpExplain.Text = "Explain";
          // 
          // tpHistory
          // 
          this.tpHistory.Controls.Add(this.historyTB);
          this.tpHistory.Location = new System.Drawing.Point(4, 4);
          this.tpHistory.Name = "tpHistory";
          this.tpHistory.Size = new System.Drawing.Size(669, 159);
          this.tpHistory.TabIndex = 3;
          this.tpHistory.Text = "History";
          // 
          // historyTB
          // 
          this.historyTB.Dock = System.Windows.Forms.DockStyle.Fill;
          this.historyTB.Location = new System.Drawing.Point(0, 0);
          this.historyTB.Multiline = true;
          this.historyTB.Name = "historyTB";
          this.historyTB.Size = new System.Drawing.Size(669, 159);
          this.historyTB.TabIndex = 0;
          // 
          // treeColumn1
          // 
          this.treeColumn1.Header = "ID";
          this.treeColumn1.SortOrder = System.Windows.Forms.SortOrder.None;
          this.treeColumn1.TooltipText = null;
          // 
          // treeColumn2
          // 
          this.treeColumn2.Header = "NAME";
          this.treeColumn2.SortOrder = System.Windows.Forms.SortOrder.None;
          this.treeColumn2.TooltipText = null;
          this.treeColumn2.Width = 150;
          // 
          // nodeTextBox1
          // 
          this.nodeTextBox1.DataPropertyName = "0";
          this.nodeTextBox1.IncrementalSearchEnabled = true;
          this.nodeTextBox1.LeftMargin = 3;
          this.nodeTextBox1.ParentColumn = this.treeColumn1;
          this.nodeTextBox1.VirtualMode = true;
          // 
          // nodeTextBox2
          // 
          this.nodeTextBox2.DataPropertyName = "1";
          this.nodeTextBox2.IncrementalSearchEnabled = true;
          this.nodeTextBox2.LeftMargin = 3;
          this.nodeTextBox2.ParentColumn = this.treeColumn2;
          this.nodeTextBox2.VirtualMode = true;
          // 
          // splitter1
          // 
          this.splitter1.Dock = System.Windows.Forms.DockStyle.Top;
          this.splitter1.Location = new System.Drawing.Point(0, 22);
          this.splitter1.Name = "splitter1";
          this.splitter1.Size = new System.Drawing.Size(677, 3);
          this.splitter1.TabIndex = 2;
          this.splitter1.TabStop = false;
          // 
          // execButton
          // 
          this.execButton.Location = new System.Drawing.Point(0, 0);
          this.execButton.Name = "execButton";
          this.execButton.Size = new System.Drawing.Size(62, 22);
          this.execButton.TabIndex = 3;
          this.execButton.Text = "Execute";
          this.execButton.UseVisualStyleBackColor = true;
          this.execButton.Click += new System.EventHandler(this.execSql_Click);
          // 
          // splitContainer
          // 
          this.splitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
          this.splitContainer.Location = new System.Drawing.Point(0, 25);
          this.splitContainer.Name = "splitContainer";
          this.splitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
          // 
          // splitContainer.Panel1
          // 
          this.splitContainer.Panel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
          // 
          // splitContainer.Panel2
          // 
          this.splitContainer.Panel2.Controls.Add(this.queryTabs);
          this.splitContainer.Panel2.RightToLeft = System.Windows.Forms.RightToLeft.No;
          this.splitContainer.Size = new System.Drawing.Size(677, 340);
          this.splitContainer.SplitterDistance = 148;
          this.splitContainer.TabIndex = 4;
          // 
          // panel1
          // 
          this.panel1.Controls.Add(this.execButton);
          this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
          this.panel1.Location = new System.Drawing.Point(0, 0);
          this.panel1.Name = "panel1";
          this.panel1.Size = new System.Drawing.Size(677, 22);
          this.panel1.TabIndex = 5;
          // 
          // QueryBrowserForm
          // 
          this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
          this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
          this.ClientSize = new System.Drawing.Size(677, 365);
          this.Controls.Add(this.splitContainer);
          this.Controls.Add(this.splitter1);
          this.Controls.Add(this.panel1);
          this.Name = "QueryBrowserForm";
          this.Text = "Query (webshop)";
          this.queryTabs.ResumeLayout(false);
          this.tpHistory.ResumeLayout(false);
          this.tpHistory.PerformLayout();
          this.splitContainer.Panel2.ResumeLayout(false);
          this.splitContainer.ResumeLayout(false);
          this.panel1.ResumeLayout(false);
          this.ResumeLayout(false);

        }

        #endregion

        private MySQL.Utilities.FlatTabControl.FlatTabControl queryTabs;
        private System.Windows.Forms.TabPage tpMessages;
        private System.Windows.Forms.TabPage tpExplain;
        private System.Windows.Forms.TabPage tpHistory;
        private Aga.Controls.Tree.TreeColumn treeColumn1;
        private Aga.Controls.Tree.TreeColumn treeColumn2;
        private Aga.Controls.Tree.NodeControls.NodeTextBox nodeTextBox1;
        private Aga.Controls.Tree.NodeControls.NodeTextBox nodeTextBox2;
        private System.Windows.Forms.Splitter splitter1;
        private System.Windows.Forms.Button execButton;
        private System.Windows.Forms.SplitContainer splitContainer;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox historyTB;
    }
}