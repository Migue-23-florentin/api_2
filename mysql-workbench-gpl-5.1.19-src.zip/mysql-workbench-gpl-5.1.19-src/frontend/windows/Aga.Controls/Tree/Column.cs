using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Drawing;
using Aga.Controls.Tree.NodeControls;
using System.Collections.ObjectModel;

namespace Aga.Controls.Tree
{
	/*public class Column
	{
		#region Properties

		private Image _image;
		public Image Image
		{
			get { return _image; }
			set { _image = value; }
		}

		private string _text;
		public string Text
		{
			get { return _text; }
			set { _text = value; }
		}

		private HorizontalAlignment _textAlign;
		public HorizontalAlignment TextAlign
		{
			get { return _textAlign; }
			set { _textAlign = value; }
		}

		private int _width;
		public int Width
		{
			get { return _width; }
			set 
			{
				if (value < 0)
					throw new ArgumentOutOfRangeException("value");
				_width = value;
			}
		}

		#endregion

		public Column(): this(string.Empty, 50)
		{
		}

		public Column(string text, int width)
		{
			Text = text;
			Width = width;
		}
	}*/
}
