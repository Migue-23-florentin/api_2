using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MySQL.Utilities
{
  public partial class StringInputForm : Form
  {
    protected StringInputForm()
    {
      InitializeComponent();
    }

    public static DialogResult ShowModal(string Title, string Desc, string Prompt,
      out string InputString)
    {
      StringInputForm stringInputForm = new StringInputForm();

      stringInputForm.Text = Title;
      if (Desc.Length > 0)
        stringInputForm.descLabel.Text = Desc;
      stringInputForm.promptLabel.Text = Prompt;

      DialogResult res = stringInputForm.ShowDialog();

      InputString = stringInputForm.inputTextBox.Text;

      return res;
    }

  }
}