using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Text;
using WeifenLuo.WinFormsUI.Docking;

namespace MySQL.Utilities
{
    public class MySQLDockExtender
    {
        private class GrtDockPaneStripFactory : DockPanelExtender.IDockPaneStripFactory
        {
            public DockPaneStripBase CreateDockPaneStrip(DockPane pane)
            {
                return new MySQLDockPaneStrip(pane);
            }
        }

        private class GrtDockPaneCaptionFactory : DockPanelExtender.IDockPaneCaptionFactory
        {
            public DockPaneCaptionBase CreateDockPaneCaption(DockPane pane)
            {
                return new GrtDockPaneCaption(pane);
            }
        }

        private class GrtDockPaneCaption : DockPaneCaptionBase
        {
            public GrtDockPaneCaption(DockPane pane)
                : base(pane)
            {
            }

            protected override int MeasureHeight()
            {
                return 0;
            }
        }

        public static void SetSchema(DockPanel dockPanel)
        {
            dockPanel.Extender.DockPaneStripFactory = new GrtDockPaneStripFactory();
            //dockPanel.Extender.DockPaneCaptionFactory = new GrtDockPaneCaptionFactory();
        }
    }
}
