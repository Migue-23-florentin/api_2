using System;
using System.Collections.Generic;
using System.Text;

namespace MySQL.Utilities
{
  public interface IMySQLMainForm
  {
    string StatusBarText
    {
      get;
      set;
    }
  }
}
