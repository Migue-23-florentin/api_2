using System;
using System.Collections.Generic;
using System.Text;
using Aga.Controls.Tree;
using MySQL.Grt;

namespace MySQL.Grt
{
	public class GrtListNode : Node
	{
		public GrtListNode(string caption, NodeId nodeId, GrtTreeNode parent, GrtListModel model)
			: base(caption)
		{
			NodeId = nodeId;
			Parent = parent;
			Model = model;
		}

		private GrtListModel model;
		public GrtListModel Model
		{
			get { return model; }
			set { model = value; }
		}

		private NodeId nodeId = null;
		public NodeId NodeId
		{
			get { return nodeId; }
			set { nodeId = value; }
		}
	}
}
