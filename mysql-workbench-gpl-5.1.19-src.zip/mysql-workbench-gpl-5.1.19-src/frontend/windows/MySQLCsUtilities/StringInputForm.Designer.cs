namespace MySQL.Utilities
{
  partial class StringInputForm
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.panel1 = new System.Windows.Forms.Panel();
      this.panel2 = new System.Windows.Forms.Panel();
      this.cancelButton = new System.Windows.Forms.Button();
      this.okButton = new System.Windows.Forms.Button();
      this.panel3 = new System.Windows.Forms.Panel();
      this.panel5 = new System.Windows.Forms.Panel();
      this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
      this.descLabel = new System.Windows.Forms.Label();
      this.inputTextBox = new System.Windows.Forms.TextBox();
      this.promptLabel = new System.Windows.Forms.Label();
      this.pictureBox1 = new System.Windows.Forms.PictureBox();
      this.panel1.SuspendLayout();
      this.panel2.SuspendLayout();
      this.panel3.SuspendLayout();
      this.panel5.SuspendLayout();
      this.tableLayoutPanel1.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
      this.SuspendLayout();
      // 
      // panel1
      // 
      this.panel1.Controls.Add(this.panel2);
      this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
      this.panel1.Location = new System.Drawing.Point(0, 39);
      this.panel1.Name = "panel1";
      this.panel1.Size = new System.Drawing.Size(455, 33);
      this.panel1.TabIndex = 4;
      // 
      // panel2
      // 
      this.panel2.Controls.Add(this.cancelButton);
      this.panel2.Controls.Add(this.okButton);
      this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
      this.panel2.Location = new System.Drawing.Point(286, 0);
      this.panel2.Name = "panel2";
      this.panel2.Size = new System.Drawing.Size(169, 33);
      this.panel2.TabIndex = 0;
      // 
      // cancelButton
      // 
      this.cancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
      this.cancelButton.Location = new System.Drawing.Point(91, 6);
      this.cancelButton.Name = "cancelButton";
      this.cancelButton.Size = new System.Drawing.Size(75, 23);
      this.cancelButton.TabIndex = 1;
      this.cancelButton.Text = "Cancel";
      this.cancelButton.UseVisualStyleBackColor = true;
      // 
      // okButton
      // 
      this.okButton.DialogResult = System.Windows.Forms.DialogResult.OK;
      this.okButton.Location = new System.Drawing.Point(10, 6);
      this.okButton.Name = "okButton";
      this.okButton.Size = new System.Drawing.Size(75, 23);
      this.okButton.TabIndex = 0;
      this.okButton.Text = "OK";
      this.okButton.UseVisualStyleBackColor = true;
      // 
      // panel3
      // 
      this.panel3.AutoSize = true;
      this.panel3.Controls.Add(this.panel5);
      this.panel3.Controls.Add(this.pictureBox1);
      this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
      this.panel3.Location = new System.Drawing.Point(0, 0);
      this.panel3.Name = "panel3";
      this.panel3.Size = new System.Drawing.Size(455, 39);
      this.panel3.TabIndex = 0;
      // 
      // panel5
      // 
      this.panel5.AutoSize = true;
      this.panel5.Controls.Add(this.tableLayoutPanel1);
      this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
      this.panel5.Location = new System.Drawing.Point(48, 0);
      this.panel5.Name = "panel5";
      this.panel5.Size = new System.Drawing.Size(407, 39);
      this.panel5.TabIndex = 6;
      // 
      // tableLayoutPanel1
      // 
      this.tableLayoutPanel1.AutoSize = true;
      this.tableLayoutPanel1.ColumnCount = 2;
      this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
      this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
      this.tableLayoutPanel1.Controls.Add(this.descLabel, 1, 0);
      this.tableLayoutPanel1.Controls.Add(this.inputTextBox, 1, 1);
      this.tableLayoutPanel1.Controls.Add(this.promptLabel, 0, 1);
      this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Top;
      this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
      this.tableLayoutPanel1.Name = "tableLayoutPanel1";
      this.tableLayoutPanel1.RowCount = 2;
      this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
      this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
      this.tableLayoutPanel1.Size = new System.Drawing.Size(407, 39);
      this.tableLayoutPanel1.TabIndex = 3;
      // 
      // descLabel
      // 
      this.descLabel.AutoSize = true;
      this.descLabel.Dock = System.Windows.Forms.DockStyle.Left;
      this.descLabel.Location = new System.Drawing.Point(42, 0);
      this.descLabel.Name = "descLabel";
      this.descLabel.Size = new System.Drawing.Size(282, 13);
      this.descLabel.TabIndex = 7;
      this.descLabel.Text = "Please enter the following data and press [OK] to proceed.";
      // 
      // inputTextBox
      // 
      this.inputTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
      this.inputTextBox.Location = new System.Drawing.Point(42, 16);
      this.inputTextBox.Name = "inputTextBox";
      this.inputTextBox.Size = new System.Drawing.Size(362, 20);
      this.inputTextBox.TabIndex = 0;
      // 
      // promptLabel
      // 
      this.promptLabel.AutoSize = true;
      this.promptLabel.Location = new System.Drawing.Point(3, 13);
      this.promptLabel.Name = "promptLabel";
      this.promptLabel.Padding = new System.Windows.Forms.Padding(0, 5, 0, 0);
      this.promptLabel.Size = new System.Drawing.Size(33, 18);
      this.promptLabel.TabIndex = 3;
      this.promptLabel.Text = "Data:";
      // 
      // pictureBox1
      // 
      this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Left;
      this.pictureBox1.Image = global::MySQL.Utilities.Properties.Resources.dialog_input;
      this.pictureBox1.Location = new System.Drawing.Point(0, 0);
      this.pictureBox1.Name = "pictureBox1";
      this.pictureBox1.Size = new System.Drawing.Size(48, 39);
      this.pictureBox1.TabIndex = 1;
      this.pictureBox1.TabStop = false;
      // 
      // StringInputForm
      // 
      this.AcceptButton = this.okButton;
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.AutoSize = true;
      this.CancelButton = this.cancelButton;
      this.ClientSize = new System.Drawing.Size(455, 67);
      this.Controls.Add(this.panel1);
      this.Controls.Add(this.panel3);
      this.Name = "StringInputForm";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "String Input";
      this.panel1.ResumeLayout(false);
      this.panel2.ResumeLayout(false);
      this.panel3.ResumeLayout(false);
      this.panel3.PerformLayout();
      this.panel5.ResumeLayout(false);
      this.panel5.PerformLayout();
      this.tableLayoutPanel1.ResumeLayout(false);
      this.tableLayoutPanel1.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.Panel panel1;
    private System.Windows.Forms.Panel panel2;
    private System.Windows.Forms.Button cancelButton;
    private System.Windows.Forms.Button okButton;
    private System.Windows.Forms.Panel panel3;
    private System.Windows.Forms.Panel panel5;
    private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
    private System.Windows.Forms.TextBox inputTextBox;
    private System.Windows.Forms.Label promptLabel;
    private System.Windows.Forms.Label descLabel;
    private System.Windows.Forms.PictureBox pictureBox1;
  }
}