namespace MySQL.GUI.Shell
{
    partial class GrtStructsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
          this.components = new System.ComponentModel.Container();
          System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GrtStructsForm));
          this.grtStructsTreeView = new Aga.Controls.Tree.TreeViewAdv();
          this.refreshMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
          this.refreshMenuItem = new System.Windows.Forms.ToolStripMenuItem();
          this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
          this.orderByNameMenuItem = new System.Windows.Forms.ToolStripMenuItem();
          this.orderByHierarchyMenuItem = new System.Windows.Forms.ToolStripMenuItem();
          this.orderByPackageMenuItem = new System.Windows.Forms.ToolStripMenuItem();
          this.nodeStateIcon = new Aga.Controls.Tree.NodeControls.NodeStateIcon();
          this.textNodeTextBox = new Aga.Controls.Tree.NodeControls.NodeTextBox();
          this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
          this.copyStructNameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
          this.refreshMenuStrip.SuspendLayout();
          this.SuspendLayout();
          // 
          // grtStructsTreeView
          // 
          this.grtStructsTreeView.BackColor = System.Drawing.SystemColors.Window;
          this.grtStructsTreeView.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
          this.grtStructsTreeView.ContextMenuStrip = this.refreshMenuStrip;
          this.grtStructsTreeView.DefaultToolTipProvider = null;
          this.grtStructsTreeView.Dock = System.Windows.Forms.DockStyle.Fill;
          this.grtStructsTreeView.DragDropMarkColor = System.Drawing.Color.Black;
          this.grtStructsTreeView.Indent = 8;
          this.grtStructsTreeView.LineColor = System.Drawing.SystemColors.ControlDark;
          this.grtStructsTreeView.LoadOnDemand = true;
          this.grtStructsTreeView.Location = new System.Drawing.Point(0, 0);
          this.grtStructsTreeView.Model = null;
          this.grtStructsTreeView.Name = "grtStructsTreeView";
          this.grtStructsTreeView.NodeControls.Add(this.nodeStateIcon);
          this.grtStructsTreeView.NodeControls.Add(this.textNodeTextBox);
          this.grtStructsTreeView.SelectedNode = null;
          this.grtStructsTreeView.ShowLines = false;
          this.grtStructsTreeView.Size = new System.Drawing.Size(292, 266);
          this.grtStructsTreeView.TabIndex = 0;
          // 
          // refreshMenuStrip
          // 
          this.refreshMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.refreshMenuItem,
            this.toolStripSeparator1,
            this.orderByNameMenuItem,
            this.orderByHierarchyMenuItem,
            this.orderByPackageMenuItem,
            this.toolStripMenuItem1,
            this.copyStructNameToolStripMenuItem});
          this.refreshMenuStrip.Name = "refreshMenuStrip";
          this.refreshMenuStrip.Size = new System.Drawing.Size(178, 148);
          // 
          // refreshMenuItem
          // 
          this.refreshMenuItem.Name = "refreshMenuItem";
          this.refreshMenuItem.Size = new System.Drawing.Size(177, 22);
          this.refreshMenuItem.Text = "Refresh";
          this.refreshMenuItem.Click += new System.EventHandler(this.refreshMenuItem_Click);
          // 
          // toolStripSeparator1
          // 
          this.toolStripSeparator1.Name = "toolStripSeparator1";
          this.toolStripSeparator1.Size = new System.Drawing.Size(174, 6);
          // 
          // orderByNameMenuItem
          // 
          this.orderByNameMenuItem.Checked = true;
          this.orderByNameMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
          this.orderByNameMenuItem.Name = "orderByNameMenuItem";
          this.orderByNameMenuItem.Size = new System.Drawing.Size(177, 22);
          this.orderByNameMenuItem.Tag = "";
          this.orderByNameMenuItem.Text = "Order by Name";
          this.orderByNameMenuItem.Click += new System.EventHandler(this.orderByNameMenuItem_Click);
          // 
          // orderByHierarchyMenuItem
          // 
          this.orderByHierarchyMenuItem.Name = "orderByHierarchyMenuItem";
          this.orderByHierarchyMenuItem.Size = new System.Drawing.Size(177, 22);
          this.orderByHierarchyMenuItem.Text = "Order by Hierarchy";
          this.orderByHierarchyMenuItem.Click += new System.EventHandler(this.orderByNameMenuItem_Click);
          // 
          // orderByPackageMenuItem
          // 
          this.orderByPackageMenuItem.Name = "orderByPackageMenuItem";
          this.orderByPackageMenuItem.Size = new System.Drawing.Size(177, 22);
          this.orderByPackageMenuItem.Text = "Order by Package";
          this.orderByPackageMenuItem.Click += new System.EventHandler(this.orderByNameMenuItem_Click);
          // 
          // nodeStateIcon
          // 
          this.nodeStateIcon.LeftMargin = 1;
          this.nodeStateIcon.ParentColumn = null;
          this.nodeStateIcon.VirtualMode = true;
          // 
          // textNodeTextBox
          // 
          this.textNodeTextBox.DataPropertyName = "Text";
          this.textNodeTextBox.IncrementalSearchEnabled = true;
          this.textNodeTextBox.LeftMargin = 3;
          this.textNodeTextBox.ParentColumn = null;
          // 
          // toolStripMenuItem1
          // 
          this.toolStripMenuItem1.Name = "toolStripMenuItem1";
          this.toolStripMenuItem1.Size = new System.Drawing.Size(174, 6);
          // 
          // copyStructNameToolStripMenuItem
          // 
          this.copyStructNameToolStripMenuItem.Name = "copyStructNameToolStripMenuItem";
          this.copyStructNameToolStripMenuItem.Size = new System.Drawing.Size(177, 22);
          this.copyStructNameToolStripMenuItem.Text = "Copy Struct Name";
          this.copyStructNameToolStripMenuItem.Click += new System.EventHandler(this.copyStructNameToolStripMenuItem_Click);
          // 
          // GrtStructsForm
          // 
          this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
          this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
          this.BackColor = System.Drawing.SystemColors.Window;
          this.ClientSize = new System.Drawing.Size(292, 266);
          this.CloseButton = false;
          this.Controls.Add(this.grtStructsTreeView);
          this.HideOnClose = true;
          this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
          this.Name = "GrtStructsForm";
          this.TabText = "Structs";
          this.Text = "GrtStructsForm";
          this.refreshMenuStrip.ResumeLayout(false);
          this.ResumeLayout(false);

        }

        #endregion

			private Aga.Controls.Tree.TreeViewAdv grtStructsTreeView;
			private Aga.Controls.Tree.NodeControls.NodeTextBox textNodeTextBox;
			private System.Windows.Forms.ContextMenuStrip refreshMenuStrip;
			private System.Windows.Forms.ToolStripMenuItem refreshMenuItem;
			private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
			private System.Windows.Forms.ToolStripMenuItem orderByNameMenuItem;
			private System.Windows.Forms.ToolStripMenuItem orderByPackageMenuItem;
			private System.Windows.Forms.ToolStripMenuItem orderByHierarchyMenuItem;
			private Aga.Controls.Tree.NodeControls.NodeStateIcon nodeStateIcon;
      private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
      private System.Windows.Forms.ToolStripMenuItem copyStructNameToolStripMenuItem;

			}
}