using System;
using System.Collections.Generic;
using System.Text;
using Aga.Controls.Tree;
using Aga.Controls.Tree.NodeControls;
using MySQL.Grt;
using MySQL.GUI.Shell.Properties;

namespace MySQL.GUI.Shell
{
	public class GrtValueTreeModel : GrtTreeModel
	{
		/// <summary>
		/// Constructor that initializes the model with the given objects
		/// </summary>
		/// <param name="TreeView">The TreeViewAdv control this model belongs to</param>
		/// <param name="GrtTree">The GRT tree this model belongs to</param>
		/// <param name="NodeStateIcon">The NodeControl representing the state icon</param>
		public GrtValueTreeModel(TreeViewAdv TreeView, GrtValueTree GrtTree, NodeStateIcon NodeStateIcon)
			: base(TreeView, GrtTree, NodeStateIcon, false)
		{
		}

		/// <summary>
		/// Returns a node list of all child nodes of a given parent node
		/// </summary>
		/// <param name="treePath">The path of the parent node</param>
		/// <returns>The list of child nodes for the given parent path node</returns>
		public override System.Collections.IEnumerable GetChildren(TreePath treePath)
		{
			// d= grtV.newDict(); d.name= "mike"; d.age= 21; grtV.setGlobal("/test", d);

			List<GrtTreeNode> items = null;
			NodeId parentNodeId;
			bool settingTopNode = false;

			if (treePath.IsEmpty())
			{
				settingTopNode = true;
				parentNodeId = model.get_root();
			}
			else
			{
				GrtTreeNode parent = treePath.LastNode as GrtTreeNode;
				if (parent != null)
					parentNodeId = parent.NodeId;
				else
					parentNodeId = null;
			}

			if (parentNodeId != null)
			{
				int childCount = model.count_children(parentNodeId);

				items = new List<GrtTreeNode>();

				for (int i = 0; i < childCount; i++)
				{
					NodeId nodeId = model.get_child(parentNodeId, i);
					GrtTreeNode node;
					string caption;

					model.get_field(nodeId, 0, out caption);

					node = new GrtTreeNode(caption, nodeId, null, this);
					if (settingTopNode)
						topNode = node;

					items.Add(node);
				}
			}
			return items;
		}

		/// <summary>
		/// Function to get the GRT Value the given node represents
		/// </summary>
		/// <param name="node">The tree node</param>
		/// <returns>The GRT Value</returns>
		public GrtValue GetNodeGrtValue(TreeNodeAdv node)
		{
			if (node == null)
				return null;

			GrtTreeNode grtTreeNode = node.Tag as GrtTreeNode;

			return ((GrtValueTree)model).get_node_value(grtTreeNode.NodeId);
		}

    public String GetNodePath(TreeNodeAdv node)
    { 
			if (node == null)
				return null;

      GrtTreeNode grtTreeNode = node.Tag as GrtTreeNode;

      return ((GrtValueTree)model).get_path_for_node(grtTreeNode.NodeId, false);
    }
	}
}
