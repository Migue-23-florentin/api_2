using System;
using System.Collections.Generic;
using System.Text;
using Aga.Controls.Tree;
using MySQL.Grt;

namespace MySQL.GUI.Shell
{
	public class GrtStructsTreeModel : GrtTreeModel
	{
		public enum DisplayMode 
		{ 
			ByName = GrtStructsTree.DisplayMode.ByName,
			ByHierarchy = GrtStructsTree.DisplayMode.ByHierarchy,
			ByPackage = GrtStructsTree.DisplayMode.ByPackage
		};

		/// <summary>
		/// Constructor that initializes the model with the given objects
		/// </summary>
		/// <param name="TreeView">The TreeViewAdv control this model belongs to</param>
		/// <param name="GrtTree">The GRT tree this model belongs to</param>
		/// <param name="NodeStateIcon">The NodeStateIcon NodeControl that displays the icon</param>
		public GrtStructsTreeModel(TreeViewAdv TreeView, GrtStructsTree GrtTree, Aga.Controls.Tree.NodeControls.NodeStateIcon NodeStateIcon)
      : base(TreeView, GrtTree, NodeStateIcon, false)
		{
		}

		/// <summary>
		/// Returns a node list of all child nodes of a given parent node
		/// </summary>
		/// <param name="treePath">The path of the parent node</param>
		/// <returns>The list of child nodes for the given parent path node</returns>
		public override System.Collections.IEnumerable GetChildren(TreePath treePath)
		{
			List<GrtTreeNode> items = null;
			NodeId parentNodeId;
			bool settingTopNode = false;

			if (treePath.IsEmpty())
			{
				settingTopNode = true;
				parentNodeId = model.get_root();
			}
			else
			{
				GrtTreeNode parent = treePath.LastNode as GrtTreeNode;
				if (parent != null)
					parentNodeId = parent.NodeId;
				else
					parentNodeId = null;
			}

			if (parentNodeId != null)
			{
				int childCount = model.count_children(parentNodeId);

				items = new List<GrtTreeNode>();

				for (int i = 0; i < childCount; i++)
				{
					NodeId nodeId = model.get_child(parentNodeId, i);
					GrtTreeNode node;
					string caption;

					model.get_field(nodeId, 0, out caption);

					node = new GrtTreeNode(caption, nodeId, null, this);
					if (settingTopNode)
						topNode = node;

					items.Add(node);
				}
			}
			return items;
		}

		public void SetDisplayMode(DisplayMode DisplayMode)
		{
			((GrtStructsTree)GrtTree).set_display_mode((GrtStructsTree.DisplayMode)DisplayMode);

			RefreshModel();
		}

    public string GetNodeIdentifier(TreeNodeAdv node)
    {
      if (node != null && node.Tag != null)
      {
        GrtTreeNode grtTreeNode = node.Tag as GrtTreeNode;

        return grtTreeNode.Text;
      }
      else
        return "";
    }

	}
}
