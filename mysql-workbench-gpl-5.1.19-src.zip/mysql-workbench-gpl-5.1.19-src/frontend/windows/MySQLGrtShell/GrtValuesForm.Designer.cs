namespace MySQL.GUI.Shell
{
    partial class GrtValuesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
          this.components = new System.ComponentModel.Container();
          System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GrtValuesForm));
          this.objSelComboBox = new System.Windows.Forms.ComboBox();
          this.grtImageList = new System.Windows.Forms.ImageList(this.components);
          this.treeMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
          this.refreshTreeMenuItem = new System.Windows.Forms.ToolStripMenuItem();
          this.copyObjectPathToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
          this.treeSplitContainer = new System.Windows.Forms.SplitContainer();
          this.grtGlobalsTreeView = new Aga.Controls.Tree.TreeViewAdv();
          this.nodeStateIcon = new Aga.Controls.Tree.NodeControls.NodeStateIcon();
          this.valueTreeNodeTextBox = new Aga.Controls.Tree.NodeControls.NodeTextBox();
          this.mainSplitContainer = new System.Windows.Forms.SplitContainer();
          this.valueSplitContainer = new System.Windows.Forms.SplitContainer();
          this.valueComboBox = new System.Windows.Forms.ComboBox();
          this.grtInspectorTreeView = new Aga.Controls.Tree.TreeViewAdv();
          this.memberTreeColumn = new Aga.Controls.Tree.TreeColumn();
          this.valueTreeColumn = new Aga.Controls.Tree.TreeColumn();
          this.nodeStateIconMembers = new Aga.Controls.Tree.NodeControls.NodeStateIcon();
          this.captionNodeTextBox = new Aga.Controls.Tree.NodeControls.NodeTextBox();
          this.valueNodeExpandingIcon = new Aga.Controls.Tree.NodeControls.ExpandingIcon();
          this.treeMenuStrip.SuspendLayout();
          this.treeSplitContainer.Panel1.SuspendLayout();
          this.treeSplitContainer.Panel2.SuspendLayout();
          this.treeSplitContainer.SuspendLayout();
          this.mainSplitContainer.Panel1.SuspendLayout();
          this.mainSplitContainer.Panel2.SuspendLayout();
          this.mainSplitContainer.SuspendLayout();
          this.valueSplitContainer.Panel1.SuspendLayout();
          this.valueSplitContainer.Panel2.SuspendLayout();
          this.valueSplitContainer.SuspendLayout();
          this.SuspendLayout();
          // 
          // objSelComboBox
          // 
          this.objSelComboBox.Dock = System.Windows.Forms.DockStyle.Top;
          this.objSelComboBox.FormattingEnabled = true;
          this.objSelComboBox.Items.AddRange(new object[] {
            "GRT Globals Tree",
            "/wb/doc/physicalModels/"});
          this.objSelComboBox.Location = new System.Drawing.Point(0, 0);
          this.objSelComboBox.Name = "objSelComboBox";
          this.objSelComboBox.Size = new System.Drawing.Size(199, 21);
          this.objSelComboBox.TabIndex = 0;
          this.objSelComboBox.Text = "GRT Globals Tree";
          this.objSelComboBox.DropDownClosed += new System.EventHandler(this.objSelComboBox_DropDownClosed);
          this.objSelComboBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.objSelComboBox_KeyDown);
          // 
          // grtImageList
          // 
          this.grtImageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("grtImageList.ImageStream")));
          this.grtImageList.TransparentColor = System.Drawing.Color.Transparent;
          this.grtImageList.Images.SetKeyName(0, "grt_object.png");
          this.grtImageList.Images.SetKeyName(1, "grt_struct.png");
          this.grtImageList.Images.SetKeyName(2, "grt_dict.png");
          this.grtImageList.Images.SetKeyName(3, "grt_list.png");
          this.grtImageList.Images.SetKeyName(4, "grt_simple_type.png");
          this.grtImageList.Images.SetKeyName(5, "grt_module.png");
          this.grtImageList.Images.SetKeyName(6, "grt_function.png");
          // 
          // treeMenuStrip
          // 
          this.treeMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.refreshTreeMenuItem,
            this.copyObjectPathToolStripMenuItem});
          this.treeMenuStrip.Name = "treeMenuStrip";
          this.treeMenuStrip.Size = new System.Drawing.Size(168, 48);
          // 
          // refreshTreeMenuItem
          // 
          this.refreshTreeMenuItem.Name = "refreshTreeMenuItem";
          this.refreshTreeMenuItem.Size = new System.Drawing.Size(167, 22);
          this.refreshTreeMenuItem.Text = "Refresh";
          this.refreshTreeMenuItem.Click += new System.EventHandler(this.refreshTreeMenuItem_Click);
          // 
          // copyObjectPathToolStripMenuItem
          // 
          this.copyObjectPathToolStripMenuItem.Name = "copyObjectPathToolStripMenuItem";
          this.copyObjectPathToolStripMenuItem.Size = new System.Drawing.Size(167, 22);
          this.copyObjectPathToolStripMenuItem.Text = "Copy Object Path";
          this.copyObjectPathToolStripMenuItem.Click += new System.EventHandler(this.copyObjectPathToolStripMenuItem_Click);
          // 
          // treeSplitContainer
          // 
          this.treeSplitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
          this.treeSplitContainer.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
          this.treeSplitContainer.Location = new System.Drawing.Point(0, 0);
          this.treeSplitContainer.Name = "treeSplitContainer";
          this.treeSplitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
          // 
          // treeSplitContainer.Panel1
          // 
          this.treeSplitContainer.Panel1.Controls.Add(this.objSelComboBox);
          this.treeSplitContainer.Panel1MinSize = 21;
          // 
          // treeSplitContainer.Panel2
          // 
          this.treeSplitContainer.Panel2.Controls.Add(this.grtGlobalsTreeView);
          this.treeSplitContainer.Size = new System.Drawing.Size(199, 392);
          this.treeSplitContainer.SplitterDistance = 21;
          this.treeSplitContainer.TabIndex = 5;
          // 
          // grtGlobalsTreeView
          // 
          this.grtGlobalsTreeView.BackColor = System.Drawing.SystemColors.Window;
          this.grtGlobalsTreeView.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
          this.grtGlobalsTreeView.ContextMenuStrip = this.treeMenuStrip;
          this.grtGlobalsTreeView.Cursor = System.Windows.Forms.Cursors.Default;
          this.grtGlobalsTreeView.DefaultToolTipProvider = null;
          this.grtGlobalsTreeView.DisplayDraggingNodes = true;
          this.grtGlobalsTreeView.Dock = System.Windows.Forms.DockStyle.Fill;
          this.grtGlobalsTreeView.DragDropMarkColor = System.Drawing.Color.Black;
          this.grtGlobalsTreeView.GridLineStyle = Aga.Controls.Tree.GridLineStyle.Horizontal;
          this.grtGlobalsTreeView.Indent = 12;
          this.grtGlobalsTreeView.LineColor = System.Drawing.SystemColors.ControlDark;
          this.grtGlobalsTreeView.LoadOnDemand = true;
          this.grtGlobalsTreeView.Location = new System.Drawing.Point(0, 0);
          this.grtGlobalsTreeView.Model = null;
          this.grtGlobalsTreeView.Name = "grtGlobalsTreeView";
          this.grtGlobalsTreeView.NodeControls.Add(this.nodeStateIcon);
          this.grtGlobalsTreeView.NodeControls.Add(this.valueTreeNodeTextBox);
          this.grtGlobalsTreeView.SelectedNode = null;
          this.grtGlobalsTreeView.ShowLines = false;
          this.grtGlobalsTreeView.Size = new System.Drawing.Size(199, 367);
          this.grtGlobalsTreeView.TabIndex = 4;
          this.grtGlobalsTreeView.Text = "grtGlobalsTreeView";
          this.grtGlobalsTreeView.SelectionChanged += new System.EventHandler(this.grtGlobalsTreeView_SelectionChanged);
          this.grtGlobalsTreeView.MouseMove += new System.Windows.Forms.MouseEventHandler(this.grtGlobalsTreeView_MouseMove);
          this.grtGlobalsTreeView.MouseDown += new System.Windows.Forms.MouseEventHandler(this.grtGlobalsTreeView_MouseDown);
          this.grtGlobalsTreeView.ItemDrag += new System.Windows.Forms.ItemDragEventHandler(this.grtGlobalsTreeView_ItemDrag);
          // 
          // nodeStateIcon
          // 
          this.nodeStateIcon.LeftMargin = 1;
          this.nodeStateIcon.ParentColumn = null;
          this.nodeStateIcon.VirtualMode = true;
          // 
          // valueTreeNodeTextBox
          // 
          this.valueTreeNodeTextBox.DataPropertyName = "Text";
          this.valueTreeNodeTextBox.IncrementalSearchEnabled = true;
          this.valueTreeNodeTextBox.LeftMargin = 3;
          this.valueTreeNodeTextBox.ParentColumn = null;
          // 
          // mainSplitContainer
          // 
          this.mainSplitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
          this.mainSplitContainer.Location = new System.Drawing.Point(4, 3);
          this.mainSplitContainer.Name = "mainSplitContainer";
          // 
          // mainSplitContainer.Panel1
          // 
          this.mainSplitContainer.Panel1.Controls.Add(this.treeSplitContainer);
          // 
          // mainSplitContainer.Panel2
          // 
          this.mainSplitContainer.Panel2.Controls.Add(this.valueSplitContainer);
          this.mainSplitContainer.Size = new System.Drawing.Size(399, 392);
          this.mainSplitContainer.SplitterDistance = 199;
          this.mainSplitContainer.TabIndex = 0;
          // 
          // valueSplitContainer
          // 
          this.valueSplitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
          this.valueSplitContainer.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
          this.valueSplitContainer.Location = new System.Drawing.Point(0, 0);
          this.valueSplitContainer.Name = "valueSplitContainer";
          this.valueSplitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
          // 
          // valueSplitContainer.Panel1
          // 
          this.valueSplitContainer.Panel1.Controls.Add(this.valueComboBox);
          this.valueSplitContainer.Panel1MinSize = 21;
          // 
          // valueSplitContainer.Panel2
          // 
          this.valueSplitContainer.Panel2.Controls.Add(this.grtInspectorTreeView);
          this.valueSplitContainer.Size = new System.Drawing.Size(196, 392);
          this.valueSplitContainer.SplitterDistance = 21;
          this.valueSplitContainer.TabIndex = 0;
          // 
          // valueComboBox
          // 
          this.valueComboBox.Dock = System.Windows.Forms.DockStyle.Top;
          this.valueComboBox.FormattingEnabled = true;
          this.valueComboBox.Location = new System.Drawing.Point(0, 0);
          this.valueComboBox.Name = "valueComboBox";
          this.valueComboBox.Size = new System.Drawing.Size(196, 21);
          this.valueComboBox.TabIndex = 1;
          // 
          // grtInspectorTreeView
          // 
          this.grtInspectorTreeView.BackColor = System.Drawing.SystemColors.Window;
          this.grtInspectorTreeView.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
          this.grtInspectorTreeView.Columns.Add(this.memberTreeColumn);
          this.grtInspectorTreeView.Columns.Add(this.valueTreeColumn);
          this.grtInspectorTreeView.Cursor = System.Windows.Forms.Cursors.Default;
          this.grtInspectorTreeView.DefaultToolTipProvider = null;
          this.grtInspectorTreeView.Dock = System.Windows.Forms.DockStyle.Fill;
          this.grtInspectorTreeView.DragDropMarkColor = System.Drawing.Color.Black;
          this.grtInspectorTreeView.FullRowSelect = true;
          this.grtInspectorTreeView.Indent = 8;
          this.grtInspectorTreeView.LineColor = System.Drawing.SystemColors.ControlDark;
          this.grtInspectorTreeView.LoadOnDemand = true;
          this.grtInspectorTreeView.Location = new System.Drawing.Point(0, 0);
          this.grtInspectorTreeView.Margin = new System.Windows.Forms.Padding(0, 3, 3, 3);
          this.grtInspectorTreeView.Model = null;
          this.grtInspectorTreeView.Name = "grtInspectorTreeView";
          this.grtInspectorTreeView.NodeControls.Add(this.nodeStateIconMembers);
          this.grtInspectorTreeView.NodeControls.Add(this.captionNodeTextBox);
          this.grtInspectorTreeView.NodeControls.Add(this.valueNodeExpandingIcon);
          this.grtInspectorTreeView.SelectedNode = null;
          this.grtInspectorTreeView.SelectionMode = Aga.Controls.Tree.TreeSelectionMode.Multi;
          this.grtInspectorTreeView.ShowLines = false;
          this.grtInspectorTreeView.ShowNodeToolTips = true;
          this.grtInspectorTreeView.ShowPlusMinus = false;
          this.grtInspectorTreeView.Size = new System.Drawing.Size(196, 367);
          this.grtInspectorTreeView.TabIndex = 5;
          this.grtInspectorTreeView.Text = "grtInspectorTreeView";
          this.grtInspectorTreeView.UseColumns = true;
          this.grtInspectorTreeView.KeyDown += new System.Windows.Forms.KeyEventHandler(this.grtInspectorTreeView_KeyDown);
          // 
          // memberTreeColumn
          // 
          this.memberTreeColumn.Header = "Member";
          this.memberTreeColumn.SortOrder = System.Windows.Forms.SortOrder.None;
          this.memberTreeColumn.TooltipText = null;
          this.memberTreeColumn.Width = 95;
          // 
          // valueTreeColumn
          // 
          this.valueTreeColumn.Header = "Value";
          this.valueTreeColumn.SortOrder = System.Windows.Forms.SortOrder.None;
          this.valueTreeColumn.TooltipText = null;
          this.valueTreeColumn.Width = 85;
          // 
          // nodeStateIconMembers
          // 
          this.nodeStateIconMembers.LeftMargin = 1;
          this.nodeStateIconMembers.ParentColumn = this.memberTreeColumn;
          this.nodeStateIconMembers.VirtualMode = true;
          // 
          // captionNodeTextBox
          // 
          this.captionNodeTextBox.DataPropertyName = "Text";
          this.captionNodeTextBox.EditEnabled = false;
          this.captionNodeTextBox.IncrementalSearchEnabled = true;
          this.captionNodeTextBox.LeftMargin = 3;
          this.captionNodeTextBox.ParentColumn = this.memberTreeColumn;
          // 
          // valueNodeExpandingIcon
          // 
          this.valueNodeExpandingIcon.LeftMargin = 3;
          this.valueNodeExpandingIcon.ParentColumn = this.valueTreeColumn;
          // 
          // GrtValuesForm
          // 
          this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
          this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
          this.BackColor = System.Drawing.SystemColors.Window;
          this.ClientSize = new System.Drawing.Size(407, 398);
          this.CloseButton = false;
          this.Controls.Add(this.mainSplitContainer);
          this.HideOnClose = true;
          this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
          this.KeyPreview = true;
          this.Name = "GrtValuesForm";
          this.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
          this.TabText = "GRT Tree";
          this.Text = "GRT Tree";
          this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.GrtValuesForm_KeyDown);
          this.treeMenuStrip.ResumeLayout(false);
          this.treeSplitContainer.Panel1.ResumeLayout(false);
          this.treeSplitContainer.Panel2.ResumeLayout(false);
          this.treeSplitContainer.ResumeLayout(false);
          this.mainSplitContainer.Panel1.ResumeLayout(false);
          this.mainSplitContainer.Panel2.ResumeLayout(false);
          this.mainSplitContainer.ResumeLayout(false);
          this.valueSplitContainer.Panel1.ResumeLayout(false);
          this.valueSplitContainer.Panel2.ResumeLayout(false);
          this.valueSplitContainer.ResumeLayout(false);
          this.ResumeLayout(false);

        }

        #endregion

				private System.Windows.Forms.ComboBox objSelComboBox;
			private System.Windows.Forms.ImageList grtImageList;
			private Aga.Controls.Tree.TreeViewAdv grtGlobalsTreeView;
			private System.Windows.Forms.ContextMenuStrip treeMenuStrip;
			private System.Windows.Forms.ToolStripMenuItem refreshTreeMenuItem;
			private Aga.Controls.Tree.TreeViewAdv grtInspectorTreeView;
			private Aga.Controls.Tree.TreeColumn memberTreeColumn;
			private Aga.Controls.Tree.TreeColumn valueTreeColumn;
			private Aga.Controls.Tree.NodeControls.NodeTextBox valueTreeNodeTextBox;
      private Aga.Controls.Tree.NodeControls.NodeTextBox captionNodeTextBox;
			private Aga.Controls.Tree.NodeControls.NodeStateIcon nodeStateIcon;
			private Aga.Controls.Tree.NodeControls.NodeStateIcon nodeStateIconMembers;
			private System.Windows.Forms.ToolStripMenuItem copyObjectPathToolStripMenuItem;
			private System.Windows.Forms.SplitContainer treeSplitContainer;
			private System.Windows.Forms.SplitContainer mainSplitContainer;
			private System.Windows.Forms.SplitContainer valueSplitContainer;
      private System.Windows.Forms.ComboBox valueComboBox;
      private Aga.Controls.Tree.NodeControls.ExpandingIcon valueNodeExpandingIcon;
    }
}