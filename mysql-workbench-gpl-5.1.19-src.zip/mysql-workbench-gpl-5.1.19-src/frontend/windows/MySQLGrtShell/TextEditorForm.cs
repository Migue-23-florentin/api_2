using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;

namespace MySQL.GUI.Workbench
{
	public partial class TextEditorForm : DockContent
	{
    bool _cancelled = false;

		public TextEditorForm()
		{
			InitializeComponent();
		}

		public RichTextBox RichTextBox
		{
			get { return richTextBox; }
		}

    private void TextEditorForm_KeyDown(object sender, KeyEventArgs e)
    {
      switch (e.KeyCode)
      {
        case Keys.Escape:
          _cancelled = true;
          Close();
          e.Handled = true;
          break;
        case Keys.Enter:
          if (e.Control)
          {
            Close();
            e.Handled = true;
          }
          break;
      }
    }

    private void TextEditorForm_FormClosed(object sender, FormClosedEventArgs e)
    {
      if (_cancelled)
        DialogResult = DialogResult.Cancel;
      else
        DialogResult = DialogResult.OK;
    }
	}
}