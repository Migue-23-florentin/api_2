namespace MySQL.GUI.Shell
{
  partial class GrtNewFileForm
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GrtNewFileForm));
      this.groupBox1 = new System.Windows.Forms.GroupBox();
      this.label5 = new System.Windows.Forms.Label();
      this.templateComboBox = new System.Windows.Forms.ComboBox();
      this.label4 = new System.Windows.Forms.Label();
      this.libraryRadioButton = new System.Windows.Forms.RadioButton();
      this.label3 = new System.Windows.Forms.Label();
      this.moduleRadioButton = new System.Windows.Forms.RadioButton();
      this.label2 = new System.Windows.Forms.Label();
      this.scriptRadioButton = new System.Windows.Forms.RadioButton();
      this.label1 = new System.Windows.Forms.Label();
      this.cancelButton = new System.Windows.Forms.Button();
      this.label6 = new System.Windows.Forms.Label();
      this.nameTextBox = new System.Windows.Forms.TextBox();
      this.addButton = new System.Windows.Forms.Button();
      this.groupBox1.SuspendLayout();
      this.SuspendLayout();
      // 
      // groupBox1
      // 
      this.groupBox1.Controls.Add(this.label5);
      this.groupBox1.Controls.Add(this.templateComboBox);
      this.groupBox1.Controls.Add(this.label4);
      this.groupBox1.Controls.Add(this.libraryRadioButton);
      this.groupBox1.Controls.Add(this.label3);
      this.groupBox1.Controls.Add(this.moduleRadioButton);
      this.groupBox1.Controls.Add(this.label2);
      this.groupBox1.Controls.Add(this.scriptRadioButton);
      this.groupBox1.Controls.Add(this.label1);
      this.groupBox1.Location = new System.Drawing.Point(12, 12);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new System.Drawing.Size(630, 221);
      this.groupBox1.TabIndex = 0;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "File Type";
      // 
      // label5
      // 
      this.label5.AutoSize = true;
      this.label5.Location = new System.Drawing.Point(243, 172);
      this.label5.Name = "label5";
      this.label5.Size = new System.Drawing.Size(54, 13);
      this.label5.TabIndex = 8;
      this.label5.Text = "Template:";
      // 
      // templateComboBox
      // 
      this.templateComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.templateComboBox.Enabled = false;
      this.templateComboBox.FormattingEnabled = true;
      this.templateComboBox.Items.AddRange(new object[] {
            "Empty File"});
      this.templateComboBox.Location = new System.Drawing.Point(314, 168);
      this.templateComboBox.Name = "templateComboBox";
      this.templateComboBox.Size = new System.Drawing.Size(265, 21);
      this.templateComboBox.TabIndex = 7;
      // 
      // label4
      // 
      this.label4.Location = new System.Drawing.Point(239, 93);
      this.label4.Name = "label4";
      this.label4.Size = new System.Drawing.Size(340, 36);
      this.label4.TabIndex = 6;
      this.label4.Text = "A GRT Lua library that is executed during startup. All code should be encapsulate" +
          "d in functions.";
      // 
      // libraryRadioButton
      // 
      this.libraryRadioButton.AutoSize = true;
      this.libraryRadioButton.Location = new System.Drawing.Point(48, 91);
      this.libraryRadioButton.Name = "libraryRadioButton";
      this.libraryRadioButton.Size = new System.Drawing.Size(122, 17);
      this.libraryRadioButton.TabIndex = 5;
      this.libraryRadioButton.Text = "Lua GRT Library File";
      this.libraryRadioButton.UseVisualStyleBackColor = true;
      this.libraryRadioButton.Click += new System.EventHandler(this.scriptTypeChanged);
      // 
      // label3
      // 
      this.label3.Location = new System.Drawing.Point(239, 129);
      this.label3.Name = "label3";
      this.label3.Size = new System.Drawing.Size(340, 36);
      this.label3.TabIndex = 4;
      this.label3.Text = "A module that is automatically loaded at Workbench startup. It must contain a reg" +
          "istration functions.";
      // 
      // moduleRadioButton
      // 
      this.moduleRadioButton.AutoSize = true;
      this.moduleRadioButton.Location = new System.Drawing.Point(48, 127);
      this.moduleRadioButton.Name = "moduleRadioButton";
      this.moduleRadioButton.Size = new System.Drawing.Size(126, 17);
      this.moduleRadioButton.TabIndex = 3;
      this.moduleRadioButton.Text = "Lua GRT Module File";
      this.moduleRadioButton.UseVisualStyleBackColor = true;
      this.moduleRadioButton.Click += new System.EventHandler(this.scriptTypeChanged);
      // 
      // label2
      // 
      this.label2.Location = new System.Drawing.Point(239, 57);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(340, 36);
      this.label2.TabIndex = 2;
      this.label2.Text = "Script that can be manually executed in the GRT IDE by the user. Scripts are not " +
          "loaded automatically.";
      // 
      // scriptRadioButton
      // 
      this.scriptRadioButton.AutoSize = true;
      this.scriptRadioButton.Checked = true;
      this.scriptRadioButton.Location = new System.Drawing.Point(48, 55);
      this.scriptRadioButton.Name = "scriptRadioButton";
      this.scriptRadioButton.Size = new System.Drawing.Size(92, 17);
      this.scriptRadioButton.TabIndex = 1;
      this.scriptRadioButton.TabStop = true;
      this.scriptRadioButton.Text = "Lua Script File";
      this.scriptRadioButton.UseVisualStyleBackColor = true;
      this.scriptRadioButton.Click += new System.EventHandler(this.scriptTypeChanged);
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Location = new System.Drawing.Point(22, 28);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(233, 13);
      this.label1.TabIndex = 0;
      this.label1.Text = "Please select the type of file you want to create.";
      // 
      // cancelButton
      // 
      this.cancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
      this.cancelButton.Location = new System.Drawing.Point(567, 287);
      this.cancelButton.Name = "cancelButton";
      this.cancelButton.Size = new System.Drawing.Size(75, 23);
      this.cancelButton.TabIndex = 1;
      this.cancelButton.Text = "Cancel";
      this.cancelButton.UseVisualStyleBackColor = true;
      // 
      // label6
      // 
      this.label6.AutoSize = true;
      this.label6.Location = new System.Drawing.Point(9, 253);
      this.label6.Name = "label6";
      this.label6.Size = new System.Drawing.Size(38, 13);
      this.label6.TabIndex = 2;
      this.label6.Text = "Name:";
      // 
      // nameTextBox
      // 
      this.nameTextBox.Location = new System.Drawing.Point(52, 250);
      this.nameTextBox.Name = "nameTextBox";
      this.nameTextBox.Size = new System.Drawing.Size(590, 20);
      this.nameTextBox.TabIndex = 3;
      this.nameTextBox.TextChanged += new System.EventHandler(this.nameTextBox_TextChanged);
      // 
      // addButton
      // 
      this.addButton.DialogResult = System.Windows.Forms.DialogResult.OK;
      this.addButton.Enabled = false;
      this.addButton.Location = new System.Drawing.Point(486, 287);
      this.addButton.Name = "addButton";
      this.addButton.Size = new System.Drawing.Size(75, 23);
      this.addButton.TabIndex = 4;
      this.addButton.Text = "Add";
      this.addButton.UseVisualStyleBackColor = true;
      // 
      // GrtNewFileForm
      // 
      this.AcceptButton = this.addButton;
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.CancelButton = this.cancelButton;
      this.ClientSize = new System.Drawing.Size(654, 323);
      this.ControlBox = false;
      this.Controls.Add(this.addButton);
      this.Controls.Add(this.nameTextBox);
      this.Controls.Add(this.label6);
      this.Controls.Add(this.cancelButton);
      this.Controls.Add(this.groupBox1);
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "GrtNewFileForm";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
      this.Text = "New GRT File ...";
      this.groupBox1.ResumeLayout(false);
      this.groupBox1.PerformLayout();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.RadioButton scriptRadioButton;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.Label label3;
    private System.Windows.Forms.RadioButton moduleRadioButton;
    private System.Windows.Forms.Label label4;
    private System.Windows.Forms.RadioButton libraryRadioButton;
    private System.Windows.Forms.Label label5;
    private System.Windows.Forms.ComboBox templateComboBox;
    private System.Windows.Forms.Button cancelButton;
    private System.Windows.Forms.Label label6;
    private System.Windows.Forms.TextBox nameTextBox;
    private System.Windows.Forms.Button addButton;
  }
}