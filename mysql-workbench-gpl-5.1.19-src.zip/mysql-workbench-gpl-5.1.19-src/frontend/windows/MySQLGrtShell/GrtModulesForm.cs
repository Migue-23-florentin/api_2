using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;
using Aga.Controls.Tree.NodeControls;
using Aga.Controls.Tree;
using MySQL.Grt;

namespace MySQL.GUI.Shell
{
	public partial class GrtModulesForm : DockContent
	{
		private GrtManager grtManager;
		private GrtModulesTreeModel grtModulesTreeModel;
		private GrtShellForm grtShellForm = null;

		private GrtModulesForm()
		{
			InitializeComponent();
		}

		public GrtModulesForm(GrtManager GrtManager)
			: this()
		{
			grtManager = GrtManager;

			AutoHidePortion = 0.30;

			// Grt tree
			grtModulesTreeModel = new GrtModulesTreeModel(grtModulesTreeView, grtManager.get_shared_modules_tree(), nodeStateIcon);
			grtModulesTreeView.Model = grtModulesTreeModel;

      grtModulesTreeModel.EnableTooltips();
		}

		public GrtModulesForm(GrtShellForm GrtShellForm, GrtManager GrtManager)
			: this(GrtManager)
		{
			grtShellForm = GrtShellForm;
		}

		public void RefreshTree()
		{
			grtModulesTreeModel.RefreshModel();
		}

		private void refreshMenuItem_Click(object sender, EventArgs e)
		{
			RefreshTree();
		}

		private void grtModulesTreeView_MouseDoubleClick(object sender, MouseEventArgs e)
		{
			if (grtShellForm != null)
			{
				grtShellForm.SetCurrentSelectionText(grtModulesTreeModel.GetNodeIdentifier(grtModulesTreeView.SelectedNode));
			}
		}
	}
}