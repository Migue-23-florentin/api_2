namespace MySQL.GUI.Shell
{
    partial class GrtPromptForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
          this.shellTabControl = new MySQL.Utilities.FlatTabControl.FlatTabControl();
          this.promptTabPage = new System.Windows.Forms.TabPage();
          this.promptSplitContainer = new System.Windows.Forms.SplitContainer();
          this.outputTextBox = new System.Windows.Forms.RichTextBox();
          this.inputTextBox = new System.Windows.Forms.TextBox();
          this.promptLabel = new System.Windows.Forms.Label();
          this.snippetsTabPage = new System.Windows.Forms.TabPage();
          this.snippetsTextBox = new System.Windows.Forms.RichTextBox();
          this.shellTabControl.SuspendLayout();
          this.promptTabPage.SuspendLayout();
          this.promptSplitContainer.Panel1.SuspendLayout();
          this.promptSplitContainer.Panel2.SuspendLayout();
          this.promptSplitContainer.SuspendLayout();
          this.snippetsTabPage.SuspendLayout();
          this.SuspendLayout();
          // 
          // shellTabControl
          // 
          this.shellTabControl.Alignment = System.Windows.Forms.TabAlignment.Bottom;
          this.shellTabControl.Controls.Add(this.promptTabPage);
          this.shellTabControl.Controls.Add(this.snippetsTabPage);
          this.shellTabControl.Dock = System.Windows.Forms.DockStyle.Fill;
          this.shellTabControl.ItemSize = new System.Drawing.Size(50, 16);
          this.shellTabControl.Location = new System.Drawing.Point(0, 0);
          this.shellTabControl.Margin = new System.Windows.Forms.Padding(0);
          this.shellTabControl.myBackColor = System.Drawing.SystemColors.Control;
          this.shellTabControl.Name = "shellTabControl";
          this.shellTabControl.Padding = new System.Drawing.Point(0, 0);
          this.shellTabControl.SelectedIndex = 0;
          this.shellTabControl.Size = new System.Drawing.Size(607, 266);
          this.shellTabControl.TabIndex = 1;
          this.shellTabControl.SelectedIndexChanged += new System.EventHandler(this.shellTabControl_SelectedIndexChanged);
          // 
          // promptTabPage
          // 
          this.promptTabPage.BackColor = System.Drawing.Color.Black;
          this.promptTabPage.Controls.Add(this.promptSplitContainer);
          this.promptTabPage.ForeColor = System.Drawing.Color.Silver;
          this.promptTabPage.Location = new System.Drawing.Point(4, 4);
          this.promptTabPage.Margin = new System.Windows.Forms.Padding(0);
          this.promptTabPage.Name = "promptTabPage";
          this.promptTabPage.Size = new System.Drawing.Size(599, 242);
          this.promptTabPage.TabIndex = 0;
          this.promptTabPage.Text = "Console";
          // 
          // promptSplitContainer
          // 
          this.promptSplitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
          this.promptSplitContainer.FixedPanel = System.Windows.Forms.FixedPanel.Panel2;
          this.promptSplitContainer.IsSplitterFixed = true;
          this.promptSplitContainer.Location = new System.Drawing.Point(0, 0);
          this.promptSplitContainer.Name = "promptSplitContainer";
          this.promptSplitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
          // 
          // promptSplitContainer.Panel1
          // 
          this.promptSplitContainer.Panel1.Controls.Add(this.outputTextBox);
          this.promptSplitContainer.Panel1MinSize = 50;
          // 
          // promptSplitContainer.Panel2
          // 
          this.promptSplitContainer.Panel2.Controls.Add(this.inputTextBox);
          this.promptSplitContainer.Panel2.Controls.Add(this.promptLabel);
          this.promptSplitContainer.Panel2MinSize = 21;
          this.promptSplitContainer.Size = new System.Drawing.Size(599, 242);
          this.promptSplitContainer.SplitterDistance = 216;
          this.promptSplitContainer.TabIndex = 2;
          // 
          // outputTextBox
          // 
          this.outputTextBox.AcceptsTab = true;
          this.outputTextBox.BackColor = System.Drawing.Color.Black;
          this.outputTextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
          this.outputTextBox.Cursor = System.Windows.Forms.Cursors.Arrow;
          this.outputTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
          this.outputTextBox.EnableAutoDragDrop = true;
          this.outputTextBox.Font = new System.Drawing.Font("Bitstream Vera Sans Mono", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
          this.outputTextBox.ForeColor = System.Drawing.Color.Silver;
          this.outputTextBox.Location = new System.Drawing.Point(0, 0);
          this.outputTextBox.MinimumSize = new System.Drawing.Size(0, 60);
          this.outputTextBox.Name = "outputTextBox";
          this.outputTextBox.ReadOnly = true;
          this.outputTextBox.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
          this.outputTextBox.Size = new System.Drawing.Size(599, 216);
          this.outputTextBox.TabIndex = 0;
          this.outputTextBox.Text = "";
          // 
          // inputTextBox
          // 
          this.inputTextBox.AcceptsReturn = true;
          this.inputTextBox.AcceptsTab = true;
          this.inputTextBox.AllowDrop = true;
          this.inputTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
          this.inputTextBox.Font = new System.Drawing.Font("Bitstream Vera Sans Mono", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
          this.inputTextBox.Location = new System.Drawing.Point(21, 0);
          this.inputTextBox.Name = "inputTextBox";
          this.inputTextBox.Size = new System.Drawing.Size(578, 20);
          this.inputTextBox.TabIndex = 1;
          this.inputTextBox.DragDrop += new System.Windows.Forms.DragEventHandler(this.inputTextBox_DragDrop);
          this.inputTextBox.DragEnter += new System.Windows.Forms.DragEventHandler(this.inputTextBox_DragEnter);
          this.inputTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.inputTextBox_KeyDown);
          // 
          // promptLabel
          // 
          this.promptLabel.AutoSize = true;
          this.promptLabel.Dock = System.Windows.Forms.DockStyle.Left;
          this.promptLabel.Font = new System.Drawing.Font("Bitstream Vera Sans Mono", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
          this.promptLabel.Location = new System.Drawing.Point(0, 0);
          this.promptLabel.Name = "promptLabel";
          this.promptLabel.Padding = new System.Windows.Forms.Padding(0, 3, 0, 0);
          this.promptLabel.Size = new System.Drawing.Size(21, 16);
          this.promptLabel.TabIndex = 0;
          this.promptLabel.Text = "/>";
          // 
          // snippetsTabPage
          // 
          this.snippetsTabPage.BackColor = System.Drawing.SystemColors.Window;
          this.snippetsTabPage.Controls.Add(this.snippetsTextBox);
          this.snippetsTabPage.ForeColor = System.Drawing.SystemColors.WindowText;
          this.snippetsTabPage.Location = new System.Drawing.Point(4, 4);
          this.snippetsTabPage.Margin = new System.Windows.Forms.Padding(0);
          this.snippetsTabPage.Name = "snippetsTabPage";
          this.snippetsTabPage.Size = new System.Drawing.Size(599, 242);
          this.snippetsTabPage.TabIndex = 1;
          this.snippetsTabPage.Text = "Snippets";
          // 
          // snippetsTextBox
          // 
          this.snippetsTextBox.AcceptsTab = true;
          this.snippetsTextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
          this.snippetsTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
          this.snippetsTextBox.Font = new System.Drawing.Font("Bitstream Vera Sans Mono", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
          this.snippetsTextBox.Location = new System.Drawing.Point(0, 0);
          this.snippetsTextBox.Name = "snippetsTextBox";
          this.snippetsTextBox.Size = new System.Drawing.Size(599, 242);
          this.snippetsTextBox.TabIndex = 0;
          this.snippetsTextBox.Text = "-- Set a global variable\nd= grtV.newDict();\nd.name= \"mike\";\nd.age= 21;\nd.subDict=" +
              " grtV.newDict();\nd.subDict.name= \"spike\";\ngrtV.setGlobal(\"/test\", d);";
          this.snippetsTextBox.WordWrap = false;
          // 
          // GrtPromptForm
          // 
          this.AllowEndUserDocking = false;
          this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
          this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
          this.BackColor = System.Drawing.SystemColors.Window;
          this.ClientSize = new System.Drawing.Size(607, 266);
          this.CloseButton = false;
          this.Controls.Add(this.shellTabControl);
          this.ForeColor = System.Drawing.SystemColors.GrayText;
          this.KeyPreview = true;
          this.Name = "GrtPromptForm";
          this.TabText = "Prompt";
          this.Text = "Prompt";
          this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.GrtPromptForm_KeyDown);
          this.shellTabControl.ResumeLayout(false);
          this.promptTabPage.ResumeLayout(false);
          this.promptSplitContainer.Panel1.ResumeLayout(false);
          this.promptSplitContainer.Panel2.ResumeLayout(false);
          this.promptSplitContainer.Panel2.PerformLayout();
          this.promptSplitContainer.ResumeLayout(false);
          this.snippetsTabPage.ResumeLayout(false);
          this.ResumeLayout(false);

        }

        #endregion

			private System.Windows.Forms.RichTextBox outputTextBox;
      private MySQL.Utilities.FlatTabControl.FlatTabControl shellTabControl;
			private System.Windows.Forms.TabPage promptTabPage;
			private System.Windows.Forms.TabPage snippetsTabPage;
      private System.Windows.Forms.RichTextBox snippetsTextBox;
      private System.Windows.Forms.TextBox inputTextBox;
      private System.Windows.Forms.Label promptLabel;
      private System.Windows.Forms.SplitContainer promptSplitContainer;







			}
}