using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MySQL.GUI.Shell
{
  public partial class GrtNewFileForm : Form
  {
    public GrtNewFileForm()
    {
      InitializeComponent();

      ActiveControl = nameTextBox;

      templateComboBox.SelectedIndex = 0;

      foreach (string templateFile in Directory.GetFiles(TemplateDirectory))
      {
        string fileName = new FileInfo(templateFile).Name;
        fileName = fileName.Substring(0, fileName.Length - 13);
        templateComboBox.Items.Add(fileName);
      }
    }

    private void nameTextBox_TextChanged(object sender, EventArgs e)
    {
      addButton.Enabled = !nameTextBox.Text.Equals("");
    }

    public string FileType
    {
      get
      {
        if (scriptRadioButton.Checked)
          return "scripts";
        else if (libraryRadioButton.Checked)
          return "libraries";
        else if (moduleRadioButton.Checked)
          return "modules";
        else
          return "scripts";
      }
    }

    public string FileName
    {
      get { return nameTextBox.Text; }
    }

    public string TemplateFileName
    {
      get 
      {
        if (templateComboBox.SelectedIndex > 0)
          return templateComboBox.SelectedItem.ToString();
        else
          return "";
      }
    }

    public string TemplateDirectory
    {
      get 
      {
        System.Reflection.Assembly asm = System.Reflection.Assembly.GetEntryAssembly();
        string baseDir = System.IO.Path.GetDirectoryName(asm.Location);

        return System.IO.Path.Combine(System.IO.Path.Combine(baseDir, "modules"), "templates");
      }
    }

    private void scriptTypeChanged(object sender, EventArgs e)
    {
      templateComboBox.Enabled = (sender == moduleRadioButton);

    }

  }
}