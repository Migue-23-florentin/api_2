using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;
using MySQL.Grt;
using ScintillaNet;

namespace MySQL.GUI.Shell
{
  public partial class GrtCodeEditor : DockContent
  {
    private string filePath;
    private GrtShellForm grtShellForm;

    private GrtCodeEditor()
    {
      InitializeComponent();
    }

    public GrtCodeEditor(GrtShellForm GrtShellForm)
			: this()
		{
			grtShellForm = GrtShellForm;
		}

    private void GrtCodeEditor_Load(object sender, EventArgs e)
    {
      Document.Margins.Margin0.Width = 35;
    }

    private void zoomInButton_Click(object sender, EventArgs e)
    {
      Document.Zoom++;
    }

    private void zoomOutButton_Click(object sender, EventArgs e)
    {
      Document.Zoom--;
    }

    private void zoomResetButton_Click(object sender, EventArgs e)
    {
      Document.Zoom = 0;
    }

    private void eofButton_Click(object sender, EventArgs e)
    {
      Document.EndOfLine.IsVisible = eofButton.Checked;
    }

    private void whitespaceButton_Click(object sender, EventArgs e)
    {
      if (whitespaceButton.Checked)
      {
        Document.WhiteSpace.Mode = WhiteSpaceMode.VisibleAlways;
      }
      else
      {
        Document.WhiteSpace.Mode = WhiteSpaceMode.Invisible;
      }
    }

    private void loadButton_Click(object sender, EventArgs e)
    {
      FileDialog dialog = new OpenFileDialog();

      dialog.Filter = String.Format("{0} (*.lua)|*.lua", "Lua files") + "|" 
        + String.Format("{0} (*.*)|*.*", "All files");

      dialog.RestoreDirectory = true;
      dialog.Title = "Open Script ...";
      dialog.DefaultExt = "lua";
      dialog.InitialDirectory = new FileInfo(filePath).Directory.FullName;

      if (dialog.ShowDialog() == DialogResult.OK)
      {
        Open(dialog.FileName);
      }
    }

    private void saveButton_Click(object sender, EventArgs e)
    {
      Save();
    }

    private void saveAsButton_Click(object sender, EventArgs e)
    {
      SaveAs();
    }

    public string FilePath
    {
      get { return filePath; }
      set 
      {
        filePath = value;
        TabText = new FileInfo(filePath).Name;
        Text = TabText;
      }
    }

    public void Open(string fileName)
    {
      byte[] data = null;
      using (FileStream fs = File.Open(fileName, FileMode.Open))
      {
        data = new byte[fs.Length];
        fs.Read(data, 0, (int)fs.Length);
      }

      Document.RawText = data;
      FilePath = fileName;
    }

    public bool Save()
    {
      if (String.IsNullOrEmpty(filePath) || new FileInfo(filePath).Name.Equals(GrtShellForm.newScriptName))
        return SaveAs();

      return save(filePath);
    }

    public bool SaveAs()
    {
      FileDialog dialog = new SaveFileDialog();

      dialog.Filter = String.Format("{0} (*.lua)|*.lua", "Lua files") + "|"
        + String.Format("{0} (*.*)|*.*", "All files");

      dialog.RestoreDirectory = true;
      dialog.Title = "Save Script ...";
      dialog.DefaultExt = "lua";
      dialog.InitialDirectory = new FileInfo(filePath).Directory.FullName;

      if (dialog.ShowDialog() == DialogResult.OK)
      {
        FilePath = dialog.FileName;

        return save(filePath);
      }
      else
      {
        return false;
      }
    }

    private bool save(string path)
    {
      using (FileStream fs = File.Create(path))
      using (BinaryWriter bw = new BinaryWriter(fs))
        bw.Write(Document.RawText, 0, Document.RawText.Length - 1); // Omit trailing NULL

      //sciDocument.IsDirty = false;

      if (grtShellForm != null)
        grtShellForm.RefreshGrtFileExplorer();

      return true;
    }

    private void executeButton_Click(object sender, EventArgs e)
    {
      grtShellForm.PrintShellOutput(String.Format("[Executing {0}]" + Environment.NewLine, TabText));

      grtShellForm.ExecuteShellCommand(Document.Text);
    }

    private void executeSelectionButton_Click(object sender, EventArgs e)
    {
      grtShellForm.PrintShellOutput(String.Format("[Executing Selection From {0}]" + Environment.NewLine, TabText));

      grtShellForm.ExecuteShellCommand(Document.Selection.Text);
    }

  }
}