namespace MySQL.GUI.Shell
{
    partial class GrtModulesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
          this.components = new System.ComponentModel.Container();
          System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GrtModulesForm));
          this.grtModulesTreeView = new Aga.Controls.Tree.TreeViewAdv();
          this.modulesTreeMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
          this.refreshMenuItem = new System.Windows.Forms.ToolStripMenuItem();
          this.nodeStateIcon = new Aga.Controls.Tree.NodeControls.NodeStateIcon();
          this.textNodeTextBox = new Aga.Controls.Tree.NodeControls.NodeTextBox();
          this.modulesTreeToolTip = new System.Windows.Forms.ToolTip(this.components);
          this.modulesTreeMenuStrip.SuspendLayout();
          this.SuspendLayout();
          // 
          // grtModulesTreeView
          // 
          this.grtModulesTreeView.BackColor = System.Drawing.SystemColors.Window;
          this.grtModulesTreeView.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
          this.grtModulesTreeView.ContextMenuStrip = this.modulesTreeMenuStrip;
          this.grtModulesTreeView.DefaultToolTipProvider = null;
          this.grtModulesTreeView.Dock = System.Windows.Forms.DockStyle.Fill;
          this.grtModulesTreeView.DragDropMarkColor = System.Drawing.Color.Black;
          this.grtModulesTreeView.Indent = 8;
          this.grtModulesTreeView.LineColor = System.Drawing.SystemColors.ControlDark;
          this.grtModulesTreeView.LoadOnDemand = true;
          this.grtModulesTreeView.Location = new System.Drawing.Point(0, 0);
          this.grtModulesTreeView.Model = null;
          this.grtModulesTreeView.Name = "grtModulesTreeView";
          this.grtModulesTreeView.NodeControls.Add(this.nodeStateIcon);
          this.grtModulesTreeView.NodeControls.Add(this.textNodeTextBox);
          this.grtModulesTreeView.SelectedNode = null;
          this.grtModulesTreeView.ShowLines = false;
          this.grtModulesTreeView.Size = new System.Drawing.Size(292, 266);
          this.grtModulesTreeView.TabIndex = 0;
          this.grtModulesTreeView.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.grtModulesTreeView_MouseDoubleClick);
          // 
          // modulesTreeMenuStrip
          // 
          this.modulesTreeMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.refreshMenuItem});
          this.modulesTreeMenuStrip.Name = "contextMenuStrip1";
          this.modulesTreeMenuStrip.Size = new System.Drawing.Size(113, 26);
          // 
          // refreshMenuItem
          // 
          this.refreshMenuItem.Name = "refreshMenuItem";
          this.refreshMenuItem.Size = new System.Drawing.Size(112, 22);
          this.refreshMenuItem.Text = "Refresh";
          this.refreshMenuItem.Click += new System.EventHandler(this.refreshMenuItem_Click);
          // 
          // nodeStateIcon
          // 
          this.nodeStateIcon.LeftMargin = 1;
          this.nodeStateIcon.ParentColumn = null;
          this.nodeStateIcon.VirtualMode = true;
          // 
          // textNodeTextBox
          // 
          this.textNodeTextBox.DataPropertyName = "Text";
          this.textNodeTextBox.IncrementalSearchEnabled = true;
          this.textNodeTextBox.LeftMargin = 3;
          this.textNodeTextBox.ParentColumn = null;
          // 
          // GrtModulesForm
          // 
          this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
          this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
          this.BackColor = System.Drawing.SystemColors.Window;
          this.ClientSize = new System.Drawing.Size(292, 266);
          this.CloseButton = false;
          this.Controls.Add(this.grtModulesTreeView);
          this.HideOnClose = true;
          this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
          this.Name = "GrtModulesForm";
          this.TabText = "Modules";
          this.Text = "GrtModulesForm";
          this.modulesTreeMenuStrip.ResumeLayout(false);
          this.ResumeLayout(false);

        }

        #endregion

			private Aga.Controls.Tree.TreeViewAdv grtModulesTreeView;
			private System.Windows.Forms.ContextMenuStrip modulesTreeMenuStrip;
			private System.Windows.Forms.ToolStripMenuItem refreshMenuItem;
			private Aga.Controls.Tree.NodeControls.NodeTextBox textNodeTextBox;
			private Aga.Controls.Tree.NodeControls.NodeStateIcon nodeStateIcon;
      private System.Windows.Forms.ToolTip modulesTreeToolTip;
    }
}