using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;
using Aga.Controls.Tree.NodeControls;
using Aga.Controls.Tree;
using MySQL.Grt;

namespace MySQL.GUI.Shell
{
	public partial class GrtStructsForm : DockContent
	{
		private GrtManager grtManager;
		private GrtStructsTreeModel grtStructsTreeModel;

		private GrtStructsForm()
		{
			InitializeComponent();
		}

		public GrtStructsForm(GrtManager GrtManager)
			: this()
		{
			grtManager = GrtManager;

			AutoHidePortion = 0.25;

			// Grt tree
			grtStructsTreeModel = new GrtStructsTreeModel(grtStructsTreeView, grtManager.get_shared_structs_tree(), nodeStateIcon);
			grtStructsTreeView.Model = grtStructsTreeModel;
		}

		public void RefreshTree()
		{
			grtStructsTreeModel.RefreshModel();
		}

		private void refreshMenuItem_Click(object sender, EventArgs e)
		{
			RefreshTree();
		}

		private void orderByNameMenuItem_Click(object sender, EventArgs e)
		{
			orderByNameMenuItem.Checked = false;
			orderByHierarchyMenuItem.Checked = false;
			orderByPackageMenuItem.Checked = false;


			if (sender == orderByNameMenuItem)
			{
				grtStructsTreeModel.SetDisplayMode(GrtStructsTreeModel.DisplayMode.ByName);
				orderByNameMenuItem.Checked = true;
			}
			else if (sender == orderByHierarchyMenuItem)
			{
				grtStructsTreeModel.SetDisplayMode(GrtStructsTreeModel.DisplayMode.ByHierarchy);
				orderByHierarchyMenuItem.Checked = true;
			}
			else if (sender == orderByPackageMenuItem)
			{
				grtStructsTreeModel.SetDisplayMode(GrtStructsTreeModel.DisplayMode.ByPackage);
				orderByPackageMenuItem.Checked = true;
			}
		}

    private void copyStructNameToolStripMenuItem_Click(object sender, EventArgs e)
    {
      Clipboard.Clear();
      Clipboard.SetDataObject(grtStructsTreeModel.GetNodeIdentifier(grtStructsTreeView.SelectedNode), true);
    }
	}
}