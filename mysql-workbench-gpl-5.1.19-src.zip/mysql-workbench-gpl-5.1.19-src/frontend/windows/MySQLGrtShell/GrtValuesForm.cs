using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;
using Aga.Controls.Tree.NodeControls;
using Aga.Controls.Tree;
using MySQL.Grt;

namespace MySQL.GUI.Shell
{
	public partial class GrtValuesForm : DockContent
	{
		private GrtManager grtManager;
		private GrtValueTreeModel grtValueTreeModel;
		private GrtInspectorTreeModel grtInspectorTreeModel = null;
		// private Point dragStart; // Unused
    private NodeMultiTypeBox _valueNodeControl;

    private GrtValuesForm()
		{
			InitializeComponent();

      // 
      // _valueNodeControl
      // 
      _valueNodeControl = new NodeMultiTypeBox();
      grtInspectorTreeView.NodeControls.Add(_valueNodeControl);
      _valueNodeControl.IncrementalSearchEnabled = true;
      _valueNodeControl.LeftMargin = 3;
      _valueNodeControl.ParentColumn = valueTreeColumn;
      _valueNodeControl.VirtualMode = true;
      _valueNodeControl.EditOnClick = true;
      _valueNodeControl.ValueColumn = (int)GrtValueInspector.Columns.Value;
      _valueNodeControl.IsReadonlyColumn = (int)GrtValueInspector.Columns.IsReadonly;
      _valueNodeControl.EditMethodColumn = (int)GrtValueInspector.Columns.EditMethod;
    }

		public GrtValuesForm(GrtManager GrtManager)
			: this()
		{
			grtManager = GrtManager;

			AutoHidePortion = 0.45;

			// Grt tree
			grtValueTreeModel = new GrtValueTreeModel(grtGlobalsTreeView, GrtManager.get_shared_value_tree("/"), nodeStateIcon);
			grtGlobalsTreeView.Model = grtValueTreeModel;

      objSelComboBox.Items.Clear();
      objSelComboBox.Items.AddRange(grtManager.get_shell().get_grt_tree_bookmarks().ToArray());
		}

		protected override void OnPaint(PaintEventArgs e)
		{
			base.OnPaint(e);

			Graphics g = e.Graphics;
			Brush solid = System.Drawing.SystemBrushes.Window;
			Pen pen = SystemPens.ControlDark;

			g.FillRectangle(solid, 0, 0, Width, Height);
			g.DrawRectangle(pen, 0, -1, Width - 1, Height + 1);
		}

		public void RefreshTree()
		{
			grtValueTreeModel.RefreshModel();
		}

		public void SetInspectorLayout(Orientation Mode)
		{
			//mainSplitContainer.Orientation = Mode;
		}

		private void refreshTreeMenuItem_Click(object sender, EventArgs e)
		{
			RefreshTree();
		}

		private void grtGlobalsTreeView_SelectionChanged(object sender, EventArgs e)
		{
			// remove old virtual value events
			if (grtInspectorTreeView.Model != null)
				grtInspectorTreeModel.DetachEvents();

			// if a new node was selected, create an inspector for it
			if (grtGlobalsTreeView.SelectedNode != null)
			{
				// create new inspector model for the selected value, pass valueNodeTextBox so virtual value events can be attached
				grtInspectorTreeModel = new GrtInspectorTreeModel(grtInspectorTreeView,
          grtManager.get_new_value_inspector(grtValueTreeModel.GetNodeGrtValue(grtGlobalsTreeView.SelectedNode), false),
          nodeStateIconMembers, _valueNodeControl);

        // set up muti-type value column
        _valueNodeControl.GrtTreeModel = grtInspectorTreeModel.GrtTree;

        {
          TreeModelTooltipProvider tp = new TreeModelTooltipProvider();
          tp.Model = grtInspectorTreeModel.GrtTree;
          tp.TooltipColumn = (int)GrtValueInspector.Columns.Description;
          captionNodeTextBox.ToolTipProvider = tp;
          _valueNodeControl.ToolTipProvider = tp;
        }
        
        // assign model to treeview
				grtInspectorTreeView.Model = grtInspectorTreeModel;
			}
			else
				grtInspectorTreeView.Model = null;
		}

		private void GrtValuesForm_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.F5)
			{
				RefreshTree();
			}
		}

		private void grtInspectorTreeView_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.F2)
			{
        _valueNodeControl.BeginEdit();
				e.Handled = true;
			}
		}

    private void objSelComboBox_DropDownClosed(object sender, EventArgs e)
		{
			if (objSelComboBox.SelectedIndex <= 0)
				grtManager.get_shared_value_tree("/");
			else
				grtManager.get_shared_value_tree((string)objSelComboBox.Items[objSelComboBox.SelectedIndex]);

			RefreshTree();
		}

		private void objSelComboBox_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.Return || e.KeyCode == Keys.Enter)
			{
				if (objSelComboBox.SelectedIndex == 0)
					grtManager.get_shared_value_tree("/");
				else
					grtManager.get_shared_value_tree(objSelComboBox.Text);

				objSelComboBox.Items.Add(objSelComboBox.Text);

				RefreshTree();

				e.Handled = true;
			}
		}

		private void copyObjectPathToolStripMenuItem_Click(object sender, EventArgs e)
		{
      String path = grtValueTreeModel.GetNodePath(grtGlobalsTreeView.SelectedNode);

      if (path != null)
      {
        Clipboard.Clear();
        Clipboard.SetDataObject(path, true);
      }
		}

		public bool GrtInspectorVisible
		{
			get { return mainSplitContainer.Visible; }
			set 
			{
				if (value && !mainSplitContainer.Visible)
				{
					SuspendLayout();
					try
					{
						treeSplitContainer.Dock = DockStyle.None;
						mainSplitContainer.Visible = true;
						mainSplitContainer.Dock = DockStyle.Fill;
						mainSplitContainer.Panel1.Controls.Add(treeSplitContainer);
						treeSplitContainer.Dock = DockStyle.Fill;
					}
					finally
					{
						ResumeLayout();
					}
				}
				else if (!value && mainSplitContainer.Visible)
				{
					SuspendLayout();
					try
					{
						mainSplitContainer.Dock = DockStyle.None;
						Controls.Add(treeSplitContainer);
						mainSplitContainer.Visible = false;
						treeSplitContainer.Dock = DockStyle.Fill;
					}
					finally
					{
						ResumeLayout();
					}
				}
			}
		}

		public SplitContainer GrtInspectorSplitContainer
		{
			get { return valueSplitContainer; }
		}

    public SplitContainer GrtTreeSplitContainer
    {
      get { return treeSplitContainer; }
    }

		private void grtGlobalsTreeView_MouseDown(object sender, MouseEventArgs e)
		{
			//dragStart = new Point(e.X, e.Y);
		}

		private void grtGlobalsTreeView_MouseMove(object sender, MouseEventArgs e)
		{
			/*if (e.Button == MouseButtons.Left)
			{
				if (Math.Abs(dragStart.X - e.X) > 3 || Math.Abs(dragStart.Y - e.Y) > 3)
				{
					GrtValue val = grtValueTreeModel.GetNodeGrtValue(grtGlobalsTreeView.SelectedNode);

					if (val != null)
						DoDragDrop(val, DragDropEffects.Copy);
				}
			}*/
		}

    private void grtGlobalsTreeView_ItemDrag(object sender, ItemDragEventArgs e)
    {
      DoDragDrop(grtValueTreeModel.GetNodePath(grtGlobalsTreeView.SelectedNode), DragDropEffects.Copy);
    }
	}
}