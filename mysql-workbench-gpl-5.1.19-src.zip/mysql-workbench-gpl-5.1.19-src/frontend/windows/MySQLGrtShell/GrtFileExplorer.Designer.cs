namespace MySQL.GUI.Shell
{
  partial class GrtFileExplorerForm
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      this.grtFilesTreeView = new Aga.Controls.Tree.TreeViewAdv();
      this.filesContextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
      this.openFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.deleteFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.filenameTextBox = new Aga.Controls.Tree.NodeControls.NodeTextBox();
      this.toolStrip = new System.Windows.Forms.ToolStrip();
      this.newToolStripButton = new System.Windows.Forms.ToolStripButton();
      this.refreshButton = new System.Windows.Forms.ToolStripButton();
      this.reloadScriptsButton = new System.Windows.Forms.ToolStripButton();
      this.fileExplorerPanel = new System.Windows.Forms.Panel();
      this.filesContextMenuStrip.SuspendLayout();
      this.toolStrip.SuspendLayout();
      this.fileExplorerPanel.SuspendLayout();
      this.SuspendLayout();
      // 
      // grtFilesTreeView
      // 
      this.grtFilesTreeView.BackColor = System.Drawing.SystemColors.Window;
      this.grtFilesTreeView.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.grtFilesTreeView.ContextMenuStrip = this.filesContextMenuStrip;
      this.grtFilesTreeView.DefaultToolTipProvider = null;
      this.grtFilesTreeView.Dock = System.Windows.Forms.DockStyle.Fill;
      this.grtFilesTreeView.DragDropMarkColor = System.Drawing.Color.Black;
      this.grtFilesTreeView.Indent = 14;
      this.grtFilesTreeView.LineColor = System.Drawing.SystemColors.ControlDark;
      this.grtFilesTreeView.LoadOnDemand = true;
      this.grtFilesTreeView.Location = new System.Drawing.Point(0, 25);
      this.grtFilesTreeView.Model = null;
      this.grtFilesTreeView.Name = "grtFilesTreeView";
      this.grtFilesTreeView.NodeControls.Add(this.filenameTextBox);
      this.grtFilesTreeView.SelectedNode = null;
      this.grtFilesTreeView.ShowLines = false;
      this.grtFilesTreeView.Size = new System.Drawing.Size(292, 241);
      this.grtFilesTreeView.TabIndex = 1;
      this.grtFilesTreeView.DoubleClick += new System.EventHandler(this.grtFilesTreeView_DoubleClick);
      // 
      // filesContextMenuStrip
      // 
      this.filesContextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openFileToolStripMenuItem,
            this.deleteFileToolStripMenuItem});
      this.filesContextMenuStrip.Name = "filesContextMenuStrip";
      this.filesContextMenuStrip.Size = new System.Drawing.Size(136, 48);
      // 
      // openFileToolStripMenuItem
      // 
      this.openFileToolStripMenuItem.Name = "openFileToolStripMenuItem";
      this.openFileToolStripMenuItem.Size = new System.Drawing.Size(135, 22);
      this.openFileToolStripMenuItem.Text = "Open File";
      this.openFileToolStripMenuItem.Click += new System.EventHandler(this.grtFilesTreeView_DoubleClick);
      // 
      // deleteFileToolStripMenuItem
      // 
      this.deleteFileToolStripMenuItem.Name = "deleteFileToolStripMenuItem";
      this.deleteFileToolStripMenuItem.Size = new System.Drawing.Size(135, 22);
      this.deleteFileToolStripMenuItem.Text = "Delete File";
      this.deleteFileToolStripMenuItem.Click += new System.EventHandler(this.deleteFileToolStripMenuItem_Click);
      // 
      // filenameTextBox
      // 
      this.filenameTextBox.DataPropertyName = "Text";
      this.filenameTextBox.EditEnabled = false;
      this.filenameTextBox.IncrementalSearchEnabled = true;
      this.filenameTextBox.LeftMargin = 3;
      this.filenameTextBox.ParentColumn = null;
      // 
      // toolStrip
      // 
      this.toolStrip.BackColor = System.Drawing.SystemColors.ButtonFace;
      this.toolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripButton,
            this.refreshButton,
            this.reloadScriptsButton});
      this.toolStrip.Location = new System.Drawing.Point(0, 0);
      this.toolStrip.Name = "toolStrip";
      this.toolStrip.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
      this.toolStrip.Size = new System.Drawing.Size(292, 25);
      this.toolStrip.TabIndex = 2;
      this.toolStrip.Text = "toolStrip";
      // 
      // newToolStripButton
      // 
      this.newToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
      this.newToolStripButton.Image = global::MySQL.GUI.Shell.Properties.Resources.tiny_new_doc;
      this.newToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.newToolStripButton.Name = "newToolStripButton";
      this.newToolStripButton.Size = new System.Drawing.Size(23, 22);
      this.newToolStripButton.Text = "New";
      this.newToolStripButton.Click += new System.EventHandler(this.newToolStripButton_Click);
      // 
      // refreshButton
      // 
      this.refreshButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
      this.refreshButton.Image = global::MySQL.GUI.Shell.Properties.Resources.tiny_refresh;
      this.refreshButton.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.refreshButton.Name = "refreshButton";
      this.refreshButton.Size = new System.Drawing.Size(23, 22);
      this.refreshButton.Text = "Refresh";
      this.refreshButton.Click += new System.EventHandler(this.refreshButton_Click);
      // 
      // reloadScriptsButton
      // 
      this.reloadScriptsButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
      this.reloadScriptsButton.Image = global::MySQL.GUI.Shell.Properties.Resources.tiny_refresh_plugins;
      this.reloadScriptsButton.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.reloadScriptsButton.Name = "reloadScriptsButton";
      this.reloadScriptsButton.Size = new System.Drawing.Size(23, 22);
      this.reloadScriptsButton.Text = "Reload GRT Plugins";
      this.reloadScriptsButton.Click += new System.EventHandler(this.reloadScriptsButton_Click);
      // 
      // fileExplorerPanel
      // 
      this.fileExplorerPanel.Controls.Add(this.grtFilesTreeView);
      this.fileExplorerPanel.Controls.Add(this.toolStrip);
      this.fileExplorerPanel.Dock = System.Windows.Forms.DockStyle.Fill;
      this.fileExplorerPanel.Location = new System.Drawing.Point(0, 0);
      this.fileExplorerPanel.Name = "fileExplorerPanel";
      this.fileExplorerPanel.Size = new System.Drawing.Size(292, 266);
      this.fileExplorerPanel.TabIndex = 3;
      // 
      // GrtFileExplorerForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(292, 266);
      this.Controls.Add(this.fileExplorerPanel);
      this.Name = "GrtFileExplorerForm";
      this.TabText = "Explorer";
      this.Text = "Explorer";
      this.filesContextMenuStrip.ResumeLayout(false);
      this.toolStrip.ResumeLayout(false);
      this.toolStrip.PerformLayout();
      this.fileExplorerPanel.ResumeLayout(false);
      this.fileExplorerPanel.PerformLayout();
      this.ResumeLayout(false);

    }

    #endregion

    private Aga.Controls.Tree.TreeViewAdv grtFilesTreeView;
    private System.Windows.Forms.ToolStrip toolStrip;
    private System.Windows.Forms.ToolStripButton newToolStripButton;
    private System.Windows.Forms.Panel fileExplorerPanel;
    private Aga.Controls.Tree.NodeControls.NodeTextBox filenameTextBox;
    private System.Windows.Forms.ToolStripButton refreshButton;
    private System.Windows.Forms.ContextMenuStrip filesContextMenuStrip;
    private System.Windows.Forms.ToolStripMenuItem openFileToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem deleteFileToolStripMenuItem;
    private System.Windows.Forms.ToolStripButton reloadScriptsButton;
  }
}