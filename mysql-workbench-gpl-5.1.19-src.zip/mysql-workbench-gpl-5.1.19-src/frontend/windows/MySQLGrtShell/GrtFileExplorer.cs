using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.IO;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;
using Aga.Controls.Tree.NodeControls;
using Aga.Controls.Tree;
using MySQL.Grt;

namespace MySQL.GUI.Shell
{
  public partial class GrtFileExplorerForm : DockContent
  {
    private GrtManager grtManager;
    private GrtFilesTreeModel grtFilesTreeModel;
    private GrtShellForm grtShellForm = null;

    private GrtFileExplorerForm()
    {
      InitializeComponent();
    }

		private GrtFileExplorerForm(GrtManager GrtManager)
			: this()
		{
			grtManager = GrtManager;

			AutoHidePortion = 0.30;

			// Grt tree
      grtFilesTreeModel = new GrtFilesTreeModel(grtFilesTreeView);
      grtFilesTreeView.Model = grtFilesTreeModel;

      RefreshTree();
		}

    public GrtFileExplorerForm(GrtShellForm GrtShellForm, GrtManager GrtManager)
			: this(GrtManager)
		{
			grtShellForm = GrtShellForm;
		}

		public void RefreshTree()
		{
			grtFilesTreeModel.RefreshModel();
      grtFilesTreeView.Refresh();

      grtFilesTreeView.Root.Children[0].Expand();
      grtFilesTreeView.Root.Children[1].Expand();
      grtFilesTreeView.Root.Children[2].Expand();
      grtFilesTreeView.Root.Children[3].Expand();
		}

		private void refreshMenuItem_Click(object sender, EventArgs e)
		{
			RefreshTree();
		}

    private void newToolStripButton_Click(object sender, EventArgs e)
    {
      GrtNewFileForm newFileForm = new GrtNewFileForm();

      if (newFileForm.ShowDialog() == DialogResult.OK)
      {
        GrtCodeEditor codeEditor = new GrtCodeEditor(grtShellForm);

        grtShellForm.NewDocumentForm(codeEditor);

        // open template file
        if (newFileForm.FileType.Equals("modules") && !newFileForm.TemplateFileName.Equals(""))
          codeEditor.Open(System.IO.Path.Combine(newFileForm.TemplateDirectory, 
            newFileForm.TemplateFileName + "_template.lua"));

        string path = System.IO.Path.Combine(System.IO.Path.Combine(
          System.IO.Path.Combine(System.IO.Path.Combine(
          Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
          "MySQL"), "Workbench"), newFileForm.FileType), newFileForm.FileName);

        if(!System.IO.Path.HasExtension(path))
          if (newFileForm.FileType.Equals("modules"))
            path += ".grt.lua";
          else
            path += ".lua";

        codeEditor.FilePath = path;
      }
    }

    public Panel GrtFileExplorerContainer
		{
      get { return fileExplorerPanel; }
		}

    private void grtFilesTreeView_DoubleClick(object sender, EventArgs e)
    {
      if (grtFilesTreeView.SelectedNode != null)
      {
        Node node = grtFilesTreeView.SelectedNode.Tag as Node;
        if (node != null)
        {
          if ((new FileInfo(node.Tag as string).Attributes & FileAttributes.Directory) == 0)
          {
            GrtCodeEditor codeEditor = new GrtCodeEditor(grtShellForm);
            
            grtShellForm.NewDocumentForm(codeEditor);

            codeEditor.Open(node.Tag as string);
          }
        }
      }
    }

    private void refreshButton_Click(object sender, EventArgs e)
    {
      RefreshTree();
    }

    private void deleteFileToolStripMenuItem_Click(object sender, EventArgs e)
    {
      if (grtFilesTreeView.SelectedNode != null)
      {
        Node node = grtFilesTreeView.SelectedNode.Tag as Node;
        if (node != null)
        {
          if ((new FileInfo(node.Tag as string).Attributes & FileAttributes.Directory) == 0)
          {
            if (MessageBox.Show(String.Format("Are you sure you want to delete the file {0}?",
                  new FileInfo(node.Tag as string).Name),
                "Confirm File Deletion", MessageBoxButtons.YesNo,
                MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.Yes)
            {
              File.Delete(node.Tag as string);

              RefreshTree();
            }
          }
        }
      }
    }

    private void reloadScriptsButton_Click(object sender, EventArgs e)
    {
      grtManager.rescan_modules();
    }

  }
}