namespace MySQL.GUI.Shell
{
  partial class GrtCodeEditor
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.Document = new ScintillaNet.Scintilla();
      this.toolStrip = new System.Windows.Forms.ToolStrip();
      this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
      this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
      this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
      this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
      this.loadButton = new System.Windows.Forms.ToolStripButton();
      this.saveButton = new System.Windows.Forms.ToolStripButton();
      this.zoomInButton = new System.Windows.Forms.ToolStripButton();
      this.zoomOutButton = new System.Windows.Forms.ToolStripButton();
      this.zoomResetButton = new System.Windows.Forms.ToolStripButton();
      this.eofButton = new System.Windows.Forms.ToolStripButton();
      this.whitespaceButton = new System.Windows.Forms.ToolStripButton();
      this.executeButton = new System.Windows.Forms.ToolStripButton();
      this.executeSelectionButton = new System.Windows.Forms.ToolStripButton();
      this.saveAsButton = new System.Windows.Forms.ToolStripButton();
      ((System.ComponentModel.ISupportInitialize)(this.Document)).BeginInit();
      this.toolStrip.SuspendLayout();
      this.SuspendLayout();
      // 
      // Document
      // 
      this.Document.ConfigurationManager.Language = "lua";
      this.Document.ConfigurationManager.UseXmlReader = true;
      this.Document.CurrentPos = 0;
      this.Document.Dock = System.Windows.Forms.DockStyle.Fill;
      this.Document.EndOfLine.Mode = ScintillaNet.EndOfLineMode.LF;
      this.Document.Indentation.BackspaceUnindents = true;
      this.Document.Indentation.ShowGuides = true;
      this.Document.Indentation.SmartIndentType = ScintillaNet.SmartIndent.Simple;
      this.Document.Location = new System.Drawing.Point(0, 33);
      this.Document.Name = "Document";
      this.Document.Size = new System.Drawing.Size(736, 392);
      this.Document.TabIndex = 0;
      // 
      // toolStrip
      // 
      this.toolStrip.BackColor = System.Drawing.SystemColors.ButtonFace;
      this.toolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.loadButton,
            this.saveButton,
            this.saveAsButton,
            this.toolStripSeparator2,
            this.zoomInButton,
            this.zoomOutButton,
            this.zoomResetButton,
            this.toolStripSeparator1,
            this.eofButton,
            this.whitespaceButton,
            this.toolStripSeparator3,
            this.executeButton,
            this.executeSelectionButton,
            this.toolStripSeparator4});
      this.toolStrip.Location = new System.Drawing.Point(0, 0);
      this.toolStrip.Name = "toolStrip";
      this.toolStrip.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
      this.toolStrip.Size = new System.Drawing.Size(736, 33);
      this.toolStrip.TabIndex = 1;
      this.toolStrip.Text = "toolStrip";
      // 
      // toolStripSeparator2
      // 
      this.toolStripSeparator2.Name = "toolStripSeparator2";
      this.toolStripSeparator2.Size = new System.Drawing.Size(6, 33);
      // 
      // toolStripSeparator1
      // 
      this.toolStripSeparator1.Name = "toolStripSeparator1";
      this.toolStripSeparator1.Size = new System.Drawing.Size(6, 33);
      // 
      // toolStripSeparator3
      // 
      this.toolStripSeparator3.Name = "toolStripSeparator3";
      this.toolStripSeparator3.Size = new System.Drawing.Size(6, 33);
      // 
      // toolStripSeparator4
      // 
      this.toolStripSeparator4.Name = "toolStripSeparator4";
      this.toolStripSeparator4.Size = new System.Drawing.Size(6, 33);
      // 
      // loadButton
      // 
      this.loadButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
      this.loadButton.Image = global::MySQL.GUI.Shell.Properties.Resources.script_load;
      this.loadButton.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.loadButton.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.loadButton.Name = "loadButton";
      this.loadButton.Size = new System.Drawing.Size(28, 30);
      this.loadButton.Text = "Load";
      this.loadButton.Click += new System.EventHandler(this.loadButton_Click);
      // 
      // saveButton
      // 
      this.saveButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
      this.saveButton.Image = global::MySQL.GUI.Shell.Properties.Resources.script_save;
      this.saveButton.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.saveButton.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.saveButton.Name = "saveButton";
      this.saveButton.Size = new System.Drawing.Size(28, 30);
      this.saveButton.Text = "Save";
      this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
      // 
      // zoomInButton
      // 
      this.zoomInButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
      this.zoomInButton.Image = global::MySQL.GUI.Shell.Properties.Resources.zoom_in;
      this.zoomInButton.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.zoomInButton.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.zoomInButton.Name = "zoomInButton";
      this.zoomInButton.Size = new System.Drawing.Size(28, 30);
      this.zoomInButton.Click += new System.EventHandler(this.zoomInButton_Click);
      // 
      // zoomOutButton
      // 
      this.zoomOutButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
      this.zoomOutButton.Image = global::MySQL.GUI.Shell.Properties.Resources.zoom_out;
      this.zoomOutButton.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.zoomOutButton.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.zoomOutButton.Name = "zoomOutButton";
      this.zoomOutButton.Size = new System.Drawing.Size(28, 30);
      this.zoomOutButton.Click += new System.EventHandler(this.zoomOutButton_Click);
      // 
      // zoomResetButton
      // 
      this.zoomResetButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
      this.zoomResetButton.Image = global::MySQL.GUI.Shell.Properties.Resources.zoom_reset;
      this.zoomResetButton.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.zoomResetButton.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.zoomResetButton.Name = "zoomResetButton";
      this.zoomResetButton.Size = new System.Drawing.Size(28, 30);
      this.zoomResetButton.ToolTipText = "Reset Document Zoom";
      this.zoomResetButton.Click += new System.EventHandler(this.zoomResetButton_Click);
      // 
      // eofButton
      // 
      this.eofButton.CheckOnClick = true;
      this.eofButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
      this.eofButton.Image = global::MySQL.GUI.Shell.Properties.Resources.show_eof;
      this.eofButton.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.eofButton.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.eofButton.Name = "eofButton";
      this.eofButton.Size = new System.Drawing.Size(28, 30);
      this.eofButton.ToolTipText = "Toggle EOF Indicator";
      this.eofButton.Click += new System.EventHandler(this.eofButton_Click);
      // 
      // whitespaceButton
      // 
      this.whitespaceButton.CheckOnClick = true;
      this.whitespaceButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
      this.whitespaceButton.Image = global::MySQL.GUI.Shell.Properties.Resources.show_whitespace;
      this.whitespaceButton.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.whitespaceButton.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.whitespaceButton.Name = "whitespaceButton";
      this.whitespaceButton.Size = new System.Drawing.Size(28, 30);
      this.whitespaceButton.ToolTipText = "Display Whitespace Character";
      this.whitespaceButton.Click += new System.EventHandler(this.whitespaceButton_Click);
      // 
      // executeButton
      // 
      this.executeButton.Image = global::MySQL.GUI.Shell.Properties.Resources.execute_script;
      this.executeButton.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.executeButton.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.executeButton.Name = "executeButton";
      this.executeButton.Size = new System.Drawing.Size(74, 30);
      this.executeButton.Text = "Execute";
      this.executeButton.Click += new System.EventHandler(this.executeButton_Click);
      // 
      // executeSelectionButton
      // 
      this.executeSelectionButton.Image = global::MySQL.GUI.Shell.Properties.Resources.execute_selection;
      this.executeSelectionButton.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.executeSelectionButton.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.executeSelectionButton.Name = "executeSelectionButton";
      this.executeSelectionButton.Size = new System.Drawing.Size(120, 30);
      this.executeSelectionButton.Text = "Execute Selection";
      this.executeSelectionButton.Click += new System.EventHandler(this.executeSelectionButton_Click);
      // 
      // saveAsButton
      // 
      this.saveAsButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
      this.saveAsButton.Image = global::MySQL.GUI.Shell.Properties.Resources.script_save_as;
      this.saveAsButton.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.saveAsButton.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.saveAsButton.Name = "saveAsButton";
      this.saveAsButton.Size = new System.Drawing.Size(28, 30);
      this.saveAsButton.Text = "Save As ...";
      this.saveAsButton.Click += new System.EventHandler(this.saveAsButton_Click);
      // 
      // GrtCodeEditor
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(736, 425);
      this.Controls.Add(this.Document);
      this.Controls.Add(this.toolStrip);
      this.Name = "GrtCodeEditor";
      this.TabText = "GrtCodeEditor";
      this.Text = "GrtCodeEditor";
      this.Load += new System.EventHandler(this.GrtCodeEditor_Load);
      ((System.ComponentModel.ISupportInitialize)(this.Document)).EndInit();
      this.toolStrip.ResumeLayout(false);
      this.toolStrip.PerformLayout();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private ScintillaNet.Scintilla Document;
    private System.Windows.Forms.ToolStrip toolStrip;
    private System.Windows.Forms.ToolStripButton zoomInButton;
    private System.Windows.Forms.ToolStripButton zoomOutButton;
    private System.Windows.Forms.ToolStripButton zoomResetButton;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
    private System.Windows.Forms.ToolStripButton eofButton;
    private System.Windows.Forms.ToolStripButton whitespaceButton;
    private System.Windows.Forms.ToolStripButton loadButton;
    private System.Windows.Forms.ToolStripButton saveButton;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
    private System.Windows.Forms.ToolStripButton executeButton;
    private System.Windows.Forms.ToolStripButton executeSelectionButton;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
    private System.Windows.Forms.ToolStripButton saveAsButton;
  }
}