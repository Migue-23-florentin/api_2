using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;
using System.ComponentModel;
using MySQL.Grt;

namespace MySQL.GUI.Workbench.Plugins
{
	public delegate void WorkbenchDocumentClosing(Object sender, FormClosingEventArgs e);

	public interface IWorkbenchDocument
	{
    // Event that should be called from document when it is closing
		WorkbenchDocumentClosing OnWorkbenchDocumentClosing { get; set; }

    // Function that returns a pointer to the backend used
    UIForm BackendClass { get; }
	}
}
