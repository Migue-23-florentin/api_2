//
//  WBPluginBase.m
//  MySQLWorkbench
//
//  Created by Alfredo Kojima on 30/Jan/09.
//  Copyright 2009 Sun Microsystems Inc. All rights reserved.
//

#import "WBPluginBase.h"
#include "grt/grt_manager.h"
#include "grt/plugin_manager.h"

@implementation WBPluginBase

- (id)initWithModule:(grt::Module*)module GRTManager:(bec::GRTManager*)grtm arguments:(const grt::BaseListRef&)args
{
  self= [super init];
  if (self)
  {
    _module= module;
    _grtm= grtm;
  }
  return self;
}


- (bec::GRTManager*)grtManager
{
  return _grtm;
}


- (void)dealloc
{
  // handle is the wrapping Panel, not the editor object
  //_grtm->get_plugin_manager()->forget_gui_plugin_handle(self);

  [[NSNotificationCenter defaultCenter] removeObserver: self];
  
  [super dealloc];
}


@end
