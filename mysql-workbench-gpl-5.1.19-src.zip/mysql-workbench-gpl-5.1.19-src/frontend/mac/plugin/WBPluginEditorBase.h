//
//  WBPluginEditorBase.h
//  MySQLWorkbench
//
//  Created by Alfredo Kojima on 30/Jan/09.
//  Copyright 2009 Sun Microsystems Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>

#import "ScintillaView.h"
#import "InfoBar.h"

#import "WBPluginBase.h"
#import "sql_editor_be.h"

//! Base class for editor plugins. Must return the view to be docked in the main window
//! in dockableView.
@interface WBPluginEditorBase : WBPluginBase {
  NSSize mMinumumSize;
}

- (id)identifier;
- (NSString*)title;
- (NSImage*)titleIcon;
- (void)updateTitle:(NSString*)title;

- (void)reinitWithArguments:(const grt::BaseListRef&)args;

- (void)refresh;

- (NSView*)dockableView;

- (void)setMinimumSize:(NSSize)size;
- (NSSize)minimumSize;

- (BOOL)matchesIdentifierForClosingEditor:(NSString*)identifier;

- (void)pluginWillClose:(id)sender;

+ (void) setupCodeEditor: (ScintillaView*) editor backend: (Sql_editor*) backend withStatus: (BOOL) withStatus;

@end
