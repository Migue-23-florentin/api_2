//
//  WBPluginWindowBase.mm
//  MySQLWorkbench
//
//  Created by Alfredo Kojima on 3/Jun/09.
//  Copyright 2009 Sun Microsystems Inc. All rights reserved.
//

#import "WBPluginWindowBase.h"


@implementation WBPluginWindowBase

- (void)show
{
}

@end
