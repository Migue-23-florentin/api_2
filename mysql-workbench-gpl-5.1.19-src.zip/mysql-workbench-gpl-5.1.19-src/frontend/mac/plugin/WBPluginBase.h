//
//  WBPluginBase.h
//  MySQLWorkbench
//
//  Created by Alfredo Kojima on 30/Jan/09.
//  Copyright 2009 Sun Microsystems Inc. All rights reserved.
//

#include "sigobjc++.h"
#import <Cocoa/Cocoa.h>

namespace grt
{
  class BaseListRef;
  class Module;
}
namespace bec
{
  class GRTManager;
}


//! Base class for Workbench plugins in general. GUI Plugins must descend from this.
@interface WBPluginBase : NSObject
{
  grt::Module *_module;
@protected
  bec::GRTManager *_grtm;
}

- (id)initWithModule:(grt::Module*)module GRTManager:(bec::GRTManager*)grtm arguments:(const grt::BaseListRef&)args;
- (bec::GRTManager*) grtManager;

@end
